export const environment = {
  production: true
};

export const SERVER_URL = 'https://alhaj.nazadv.com/public';
