(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!-- <ion-header [translucent]=\"true\">\n  <ion-toolbar>\n    <ion-title>\n      Blank\n    </ion-title>\n  </ion-toolbar>\n        // \"launchShowDuration\": 0\n\n</ion-header> -->\n\n<ion-content >\n<div class=\"login-page\">\n  <ion-segment dir=\"ltr\" (ionChange)=\"changeLang()\" [(ngModel)]=\"selectedLang\">\n    <ion-segment-button value=\"en\">\n      <ion-label>EN</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"ar\">\n      <ion-label>AR</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n<div id=\"svg\">\n  \n<svg  viewBox=\"0 0 214 260\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n  <path d=\"M100.892 189.372C100.892 192.386 100.892 195.114 100.892 197.755C100.289 198.272 99.6574 198.1 99.083 198.1C77.0273 198.1 54.9715 198.1 32.9158 198.128C31.4799 198.128 30.9055 197.726 30.9055 196.205C30.9342 172.95 30.9342 149.725 30.9342 126.47C30.9342 126.183 30.963 125.867 30.9917 125.58C31.7958 124.862 32.7435 124.862 33.6912 124.891C38.3436 125.035 42.996 124.604 47.6484 125.121C48.5961 125.236 49.5151 124.949 50.5776 124.518C47.2463 120.24 45.7242 115.503 46.4422 110.249C46.9591 106.431 48.395 102.842 51.0658 99.9715C56.2064 94.4594 64.0466 91.6172 71.3698 95.0048C85.3269 101.436 86.9926 112.058 79.7268 125.121C86.9064 125.121 93.7988 125.121 100.95 125.121C100.95 128.02 100.978 130.69 100.921 133.36C100.892 134.279 100.117 134.222 99.4277 134.164C89.7208 133.561 81.9669 137.38 75.936 144.815C71.9728 149.811 69.9913 155.61 70.1923 161.926C70.5369 173.18 75.8498 181.477 85.9587 186.587C89.8644 188.568 94.0286 189.458 98.3938 189.372C99.1405 189.343 99.9159 189.372 100.892 189.372Z\" fill=\"#B2D67C\"/>\n  <path d=\"M111.805 195.401C111.805 189.114 111.805 182.798 111.805 176.08C101.266 182.884 91.7598 182.367 84.0346 172.778C79.1812 166.749 78.5494 158.567 83.6612 151.562C91.1567 141.284 100.864 140.825 111.173 147.112C112.15 146.538 111.891 145.82 111.891 145.189C111.92 139.447 111.949 133.705 111.891 127.992C111.863 126.441 112.351 125.81 113.93 125.925C115.424 126.039 116.917 126.011 118.411 125.925C120.105 125.839 120.823 126.47 120.708 128.221C120.392 132.844 121.34 137.236 123.436 141.37C127.428 149.122 133.545 154.318 142.132 156.155C154.136 158.711 163.843 154.576 171.051 144.959C174.871 139.906 176.393 133.82 175.991 127.389C175.962 127.044 175.962 126.7 175.933 125.982C178.604 125.982 181.218 125.953 183.802 126.011C184.492 126.011 184.807 126.614 184.865 127.245C184.922 127.647 184.894 128.078 184.894 128.508C184.894 150.069 184.894 171.63 184.865 193.219C184.865 195.831 184.836 195.831 182.309 195.831C159.708 195.831 137.135 195.831 114.534 195.831C113.816 195.774 113.011 195.918 111.805 195.401Z\" fill=\"#CE2028\"/>\n  <path d=\"M213.296 84.7272C210.252 88.4881 207.294 92.1342 204.336 95.809C202.498 95.1774 201.349 93.7706 200.028 92.7371C191.269 85.8469 182.654 78.8131 173.952 71.8655C168.869 67.8175 163.728 63.8843 158.645 59.8363C151.006 53.75 143.424 47.6062 135.785 41.5199C130.214 37.07 124.585 32.6488 119.014 28.1988C115.912 25.7011 112.753 23.2609 109.738 20.6483C108.56 19.6148 107.699 19.5 106.521 20.4474C102.472 23.6054 98.4225 26.7347 94.3445 29.8353C87.4521 35.0603 80.5596 40.228 73.6672 45.3956C68.2107 49.501 62.7542 53.6352 57.3264 57.7406C49.113 63.9418 40.8708 70.1429 32.6573 76.3728C26.4829 81.0524 20.3658 85.7607 14.2201 90.4403C12.6693 91.6174 11.0611 92.7371 9.25182 94.0577C6.32255 90.2968 3.42199 86.5933 0.463989 82.775C2.12966 80.9376 4.16866 79.7031 6.00664 78.2676C11.0036 74.3058 16.1442 70.5736 21.2274 66.7266C25.1618 63.7408 29.125 60.7838 33.0594 57.798C36.4194 55.2429 39.7795 52.6878 43.1683 50.1327C48.7971 45.855 54.4546 41.5773 60.0834 37.2996C71.2262 28.8304 82.3115 20.3325 93.4829 11.892C98.0491 8.44692 102.673 5.08795 107.009 1.38446C107.986 0.551896 108.675 0.896406 109.508 1.58543C115.022 6.06406 120.536 10.4853 126.05 14.9352C132.167 19.8445 138.312 24.7537 144.458 29.6917C152.183 35.8642 159.88 42.0367 167.605 48.2091C174.928 54.0371 182.309 59.7502 189.546 65.6356C197.156 71.8081 204.824 77.9231 212.549 83.9521C212.808 84.0956 212.98 84.354 213.296 84.7272Z\" fill=\"url(#paint0_linear)\"/>\n  <path d=\"M37.9415 117.771C34.8686 117.771 32.0829 117.771 29.3547 117.771C28.8952 116.996 29.0388 116.25 29.0388 115.561C29.0101 108.326 29.0388 101.091 29.0101 93.8852C29.0101 92.4497 29.4983 91.5023 30.6757 90.5836C40.5836 83.1192 50.4053 75.5687 60.2557 68.0469C70.8241 60.0083 81.4499 51.9985 92.047 43.9599C94.7465 41.8928 97.4173 39.7971 100.146 37.7587C100.634 37.3855 101.065 36.7826 102.156 37.041C102.156 47.0318 102.156 57.0513 102.156 67.5876C108.244 63.3099 114.39 61.817 121.053 64.2573C124.642 65.5779 127.658 67.7311 129.898 70.9178C135.125 78.4396 134.464 87.1385 129.323 93.6555C126.136 97.7322 121.828 99.9141 116.659 100.546C111.461 101.177 106.981 99.3973 102.414 96.469C101.984 100.23 102.271 103.704 102.213 107.149C102.185 110.623 102.213 114.068 102.213 117.743C99.1117 118.058 96.125 117.972 93.0521 117.829C93.8275 108.125 90.6972 100.029 83.5463 93.7416C78.5493 89.3491 72.5759 86.9663 65.8845 86.9375C57.6423 86.8801 50.6063 90.0381 45.0637 96.0671C39.521 102.067 37.3097 109.417 37.9415 117.771Z\" fill=\"#5EC4B6\"/>\n  <path d=\"M182.797 114.872C182.826 116.652 182.165 117.14 180.5 117.111C175.531 117.025 170.592 117.082 165.624 117.082C165.135 117.082 164.647 116.996 164.13 117.111C163.9 117.168 163.671 117.254 163.441 117.427C170.19 129.197 168.926 139.418 156.577 146.423C150.288 150.012 141.988 149.093 135.469 142.806C131.994 139.447 130.214 135.112 129.984 130.317C129.754 125.609 131.506 121.36 134.522 117.053H126.251C122.489 117.053 118.726 116.996 114.964 117.082C113.327 117.111 112.523 116.68 112.667 114.843C112.81 112.718 112.696 110.594 112.696 108.24C122.804 108.757 131.133 105.455 137.508 97.9045C141.529 93.1387 143.711 87.4543 143.798 81.167C143.912 72.8127 140.84 65.6354 134.694 59.9796C128.606 54.3814 121.167 52.2856 112.839 52.6588V36.5817C114.936 37.2994 116.257 38.821 117.75 39.9981C125.073 45.7112 132.368 51.4817 139.633 57.2523C147.474 63.4822 155.256 69.7408 163.068 75.9707C169.213 80.8799 175.33 85.7892 181.534 90.6123C182.453 91.3301 182.797 92.0478 182.768 93.1675C182.74 100.402 182.711 107.637 182.797 114.872Z\" fill=\"#199DCD\"/>\n  <path d=\"M38.4297 215.928H30.0726V211.449H46.4996L46.0114 215.928H43.1395V230.512L38.401 230.828V215.928H38.4297Z\" fill=\"url(#paint1_linear)\"/>\n  <path d=\"M56.7233 215.985L53.3058 215.239L54.1961 210.933L56.9531 211.478H64.7932C66.9758 211.478 68.6702 212.11 69.8764 213.344C71.0826 214.579 71.6856 216.33 71.6856 218.569V230.684H62.2947V226.206H66.9471V219C66.9471 218.024 66.6886 217.249 66.1717 216.703C65.6548 216.158 64.9368 215.871 64.0178 215.871H61.548L58.5613 230.771H53.6218L56.7233 215.985Z\" fill=\"url(#paint2_linear)\"/>\n  <path d=\"M80.2437 211.449H90.8982C92.7075 211.449 94.1434 211.995 95.1486 213.057C96.1824 214.119 96.6707 215.612 96.6707 217.536V230.512L91.9321 230.828V218.225C91.9321 217.507 91.7598 216.961 91.3865 216.531C91.0131 216.129 90.5249 215.928 89.8644 215.928H84.9248V230.512L80.1863 230.828V211.449H80.2437Z\" fill=\"url(#paint3_linear)\"/>\n  <path d=\"M111.461 221.842C110.886 222.187 110.455 222.588 110.197 223.077C109.91 223.565 109.738 224.254 109.651 225.086C109.594 225.488 109.565 226.235 109.508 227.297C109.45 228.359 109.422 229.163 109.393 229.708L109.364 230.713C108.158 230.771 106.952 230.828 105.717 230.828H104.511C104.539 228.761 104.597 227.01 104.712 225.574C104.827 224.053 105.143 222.761 105.688 221.756C106.234 220.751 107.067 219.919 108.187 219.258C106.693 217.105 105.43 215.067 104.396 213.086C105.659 212.282 107.124 211.449 108.79 210.645C110.771 214.062 112.466 216.789 113.902 218.856C114.648 218.655 115.165 218.397 115.51 218.081C115.855 217.737 116.056 217.22 116.142 216.531C116.257 215.756 116.4 214.062 116.601 211.363C117.635 211.306 118.64 211.248 119.645 211.248L121.598 211.277L121.282 215.583C121.167 217.191 120.765 218.454 120.076 219.373C119.387 220.292 118.353 221.038 116.975 221.555L121.627 229.192C119.875 230.139 118.41 230.857 117.176 231.316L111.461 221.842Z\" fill=\"url(#paint4_linear)\"/>\n  <path d=\"M142.505 215.928H138.944V211.449H147.301V223.45L142.505 223.766V215.928Z\" fill=\"url(#paint5_linear)\"/>\n  <path d=\"M154.366 226.177H159.621V215.928H155.658V211.449H164.36V230.656H154.395V226.177H154.366Z\" fill=\"url(#paint6_linear)\"/>\n  <path d=\"M171.855 226.177H181.189V218.167C181.189 217.478 181.017 216.933 180.643 216.531C180.299 216.129 179.81 215.928 179.179 215.928H172.66V211.449H180.098C181.907 211.449 183.343 211.995 184.348 213.057C185.382 214.119 185.87 215.612 185.87 217.536V226.177H188.627L188.139 230.656H171.798V226.177H171.855Z\" fill=\"url(#paint7_linear)\"/>\n  <path d=\"M41.8185 243.001C42.8523 241.709 43.5416 240.589 43.8862 239.642L41.9046 236.685C41.9046 236.168 42.0482 235.651 42.3354 235.134C42.6226 234.618 43.0247 234.216 43.5416 233.9C44.0585 233.584 44.6616 233.412 45.3221 233.412C46.2986 233.412 47.1314 233.756 47.8206 234.445C48.5099 235.134 48.8545 236.024 48.8545 237.087C48.8545 238.321 48.3663 239.757 47.3611 241.336C46.356 242.915 44.8052 244.465 42.6513 245.958L41.8185 243.001Z\" fill=\"url(#paint8_linear)\"/>\n  <path d=\"M49.5725 253.02C52.0423 251.987 54.1961 250.982 56.0341 249.948L55.2874 242.8H51.0946V238.551H59.3655L61.1747 256.035C59.7962 256.609 58.4177 257.039 57.0967 257.327L56.7234 254.082C54.8854 255.116 52.5592 256.236 49.7448 257.499H49.3715C49.4289 255.977 49.4863 254.484 49.5725 253.02Z\" fill=\"url(#paint9_linear)\"/>\n  <path d=\"M70.3359 248.427C69.7615 248.743 69.3594 249.144 69.0723 249.604C68.8138 250.063 68.6128 250.723 68.5266 251.527C68.4692 251.901 68.4405 252.618 68.383 253.623C68.3256 254.628 68.2969 255.403 68.2681 255.92L68.2394 256.867C67.062 256.925 65.8558 256.982 64.6209 256.982H63.4435C63.4722 255.03 63.5296 253.365 63.6445 251.987C63.7594 250.522 64.0753 249.317 64.6209 248.369C65.1666 247.393 65.9707 246.618 67.0907 246.015C65.6261 243.977 64.3624 242.025 63.3573 240.158C64.5922 239.383 66.0568 238.608 67.6938 237.833C69.6466 241.077 71.3123 243.69 72.7195 245.613C73.4375 245.441 73.9831 245.183 74.299 244.867C74.6149 244.551 74.8447 244.063 74.9308 243.403C75.0457 242.685 75.1893 241.048 75.3616 238.493C76.3955 238.436 77.3719 238.378 78.3483 238.378L80.3012 238.407L79.9853 242.484C79.8704 244.005 79.4683 245.211 78.8078 246.101C78.1186 246.991 77.1134 247.68 75.7349 248.168L80.3299 255.432C78.6068 256.35 77.1421 257.011 75.936 257.441L70.3359 248.427Z\" fill=\"url(#paint10_linear)\"/>\n  <path d=\"M83.374 238.551H93.885C95.6655 238.551 97.0727 239.068 98.0779 240.072C99.083 241.106 99.5999 242.513 99.5999 244.321V256.666L94.9476 256.982V245.01C94.9476 244.321 94.7752 243.805 94.4019 243.403C94.0286 243.029 93.5403 242.828 92.9085 242.828H88.0264V256.666L83.374 256.982V238.551Z\" fill=\"url(#paint11_linear)\"/>\n  <path d=\"M103.534 254.025C104.281 253.307 105.143 252.503 106.09 251.642C107.325 250.494 108.244 249.604 108.819 249.001C109.393 248.398 109.852 247.795 110.168 247.192C110.484 246.589 110.657 245.9 110.657 245.183V242.828H101.984V233.814H106.636V238.579H115.309V244.494C115.309 246.159 115.022 247.594 114.419 248.857C113.816 250.121 113.04 251.269 112.006 252.36C111.001 253.422 109.45 254.886 107.383 256.724L106.148 257.815C105.344 256.781 104.453 255.518 103.534 254.025Z\" fill=\"url(#paint12_linear)\"/>\n  <path d=\"M124.671 248.427C124.097 248.743 123.695 249.144 123.408 249.604C123.149 250.063 122.948 250.723 122.862 251.527C122.804 251.901 122.776 252.618 122.718 253.623C122.661 254.628 122.632 255.403 122.603 255.92L122.575 256.867C121.397 256.925 120.191 256.982 118.956 256.982H117.779C117.807 255.03 117.865 253.365 117.98 251.987C118.095 250.522 118.411 249.317 118.956 248.369C119.502 247.393 120.306 246.618 121.426 246.015C119.961 243.977 118.698 242.025 117.693 240.158C118.927 239.383 120.392 238.608 122.029 237.833C123.982 241.077 125.648 243.69 127.055 245.613C127.773 245.441 128.318 245.183 128.634 244.867C128.95 244.551 129.18 244.063 129.266 243.403C129.381 242.685 129.525 241.048 129.697 238.493C130.731 238.436 131.707 238.378 132.684 238.378L134.636 238.407L134.321 242.484C134.206 244.005 133.804 245.211 133.143 246.101C132.454 246.991 131.449 247.68 130.07 248.168L134.665 255.432C132.942 256.35 131.477 257.011 130.271 257.441L124.671 248.427Z\" fill=\"url(#paint13_linear)\"/>\n  <path d=\"M145.808 242.828H142.477V238.579H150.489V256.666L145.837 256.982V242.828H145.808Z\" fill=\"url(#paint14_linear)\"/>\n  <path d=\"M153.246 252.561H162.465V244.924C162.465 244.264 162.292 243.747 161.948 243.374C161.603 243.001 161.115 242.8 160.512 242.8H154.079V238.551H161.431C163.211 238.551 164.618 239.068 165.624 240.072C166.629 241.106 167.146 242.513 167.146 244.321V252.532H169.874L169.386 256.781H153.246V252.561Z\" fill=\"url(#paint15_linear)\"/>\n  <path d=\"M178.432 248.427C177.858 248.743 177.456 249.144 177.168 249.604C176.91 250.063 176.709 250.723 176.623 251.527C176.565 251.901 176.537 252.618 176.479 253.623C176.422 254.628 176.393 255.403 176.364 255.92L176.336 256.867C175.158 256.925 173.952 256.982 172.717 256.982H171.54C171.568 255.03 171.626 253.365 171.741 251.987C171.855 250.522 172.171 249.317 172.717 248.369C173.263 247.393 174.067 246.618 175.187 246.015C173.722 243.977 172.459 242.025 171.453 240.158C172.688 239.383 174.153 238.608 175.79 237.833C177.743 241.077 179.408 243.69 180.816 245.613C181.534 245.441 182.079 245.183 182.395 244.867C182.711 244.551 182.941 244.063 183.027 243.403C183.142 242.685 183.285 241.048 183.458 238.493C184.492 238.436 185.468 238.378 186.444 238.378L188.397 238.407L188.081 242.484C187.966 244.005 187.564 245.211 186.904 246.101C186.215 246.991 185.21 247.68 183.831 248.168L188.426 255.432C186.703 256.35 185.238 257.011 184.032 257.441L178.432 248.427Z\" fill=\"url(#paint16_linear)\"/>\n  <path d=\"M32.5999 239.556H35.8451V238.723C35.8451 238.493 35.8451 238.292 35.8451 238.12C35.8164 237.833 35.8164 237.603 35.759 237.46C35.7302 237.316 35.6441 237.201 35.5292 237.087C35.4143 237 35.242 236.943 34.9836 236.943H33.5476C33.4328 236.943 33.1456 236.886 32.6861 236.742C32.7435 236.024 32.8584 235.307 33.002 234.675L33.8061 234.531L34.0071 234.761C34.0646 234.847 34.1507 234.905 34.2082 234.933C34.2656 234.962 34.3805 234.962 34.5241 234.962H35.3282C35.8451 234.962 36.2472 235.048 36.5344 235.192C36.8215 235.335 37.0226 235.594 37.1374 235.938C37.2523 236.283 37.3098 236.8 37.3098 237.431C37.3098 237.919 37.281 238.637 37.2236 239.556H38.0564L37.9416 241.536H32.4276L32.5999 239.556Z\" fill=\"url(#paint17_linear)\"/>\n  <path d=\"M38.0277 244.293C38.2 244.522 38.2574 244.867 38.2574 245.269C38.2574 245.671 38.1713 246.274 37.9702 247.106C37.7979 247.939 37.5969 248.599 37.4246 249.03C37.0225 249.374 36.3907 249.776 35.5292 250.178C34.6676 250.58 33.7486 250.924 32.8009 251.183H32.3414V249.288C33.0881 249.058 33.6912 248.886 34.1507 248.714L33.3753 246.13C33.3179 245.929 33.2604 245.814 33.203 245.728C33.1455 245.642 32.9732 245.527 32.7148 245.384L32.3701 245.154C32.5712 244.551 32.7722 244.006 33.0307 243.517L33.3753 243.431C33.605 243.517 33.7773 243.604 33.9209 243.69C34.2656 243.862 34.524 244.063 34.6963 244.321C34.8399 244.551 34.9835 244.924 35.0697 245.441C35.1845 245.958 35.3281 246.876 35.5579 248.197C36.0174 247.996 36.3046 247.766 36.4482 247.479C36.5917 247.192 36.6779 246.733 36.7066 246.159C36.7066 245.958 36.6779 245.814 36.6492 245.757C36.6205 245.699 36.5343 245.613 36.3907 245.556L35.7015 245.211C35.9312 244.522 36.161 243.948 36.3333 243.489H36.5917C36.8215 243.575 37.0225 243.632 37.1948 243.718C37.5682 243.862 37.8554 244.063 38.0277 244.293Z\" fill=\"url(#paint18_linear)\"/>\n  <path d=\"M32.6287 258.676C32.6861 258.188 32.8584 257.24 33.1169 255.834C33.1743 255.518 33.2317 255.288 33.2605 255.059C33.2892 254.915 33.2892 254.8 33.2892 254.743C33.2892 254.685 33.2605 254.628 33.2317 254.599C33.203 254.57 33.1169 254.513 33.002 254.427L32.5712 254.169C32.6287 253.48 32.7435 252.877 32.9158 252.302L33.203 252.216L33.7487 252.417C34.0646 252.532 34.2656 252.618 34.3805 252.647C34.4954 252.676 34.6102 252.676 34.7251 252.676C34.84 252.676 35.1272 252.647 35.5867 252.59C35.6728 252.59 35.8451 252.561 36.0749 252.532C36.3333 252.503 36.5344 252.475 36.6492 252.475C37.1087 252.475 37.4821 252.561 37.798 252.733C38.1139 252.905 38.3149 253.164 38.4585 253.48C38.5734 253.738 38.6308 254.054 38.6595 254.398C38.6882 254.743 38.717 255.231 38.717 255.776C38.717 256.465 38.717 257.068 38.6882 257.614L38.5447 259.135H35.2995L35.3856 257.154H37.281C37.281 256.752 37.2523 256.207 37.1949 255.547C37.1662 255.231 37.1375 255.001 37.08 254.858C37.0226 254.714 36.9364 254.599 36.7928 254.542C36.6492 254.484 36.4769 254.456 36.1897 254.456C35.8164 254.456 35.3569 254.484 34.8113 254.542C34.7538 255.001 34.7251 255.432 34.6964 255.862C34.6677 256.293 34.639 256.638 34.5815 256.953L34.3805 259.078C33.921 259.193 33.5189 259.279 33.1743 259.308H32.5999L32.6287 258.676Z\" fill=\"url(#paint19_linear)\"/>\n  <defs>\n  <linearGradient id=\"paint0_linear\" x1=\"106.368\" y1=\"-32.2903\" x2=\"107.026\" y2=\"115.11\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.802083\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint1_linear\" x1=\"38.2134\" y1=\"205.123\" x2=\"38.8589\" y2=\"265.823\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint2_linear\" x1=\"62.3719\" y1=\"204.866\" x2=\"63.0174\" y2=\"265.566\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint3_linear\" x1=\"88.2626\" y1=\"204.591\" x2=\"88.9081\" y2=\"265.29\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint4_linear\" x1=\"112.816\" y1=\"204.33\" x2=\"113.461\" y2=\"265.029\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint5_linear\" x1=\"143.018\" y1=\"204.009\" x2=\"143.664\" y2=\"264.708\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint6_linear\" x1=\"159.166\" y1=\"203.837\" x2=\"159.811\" y2=\"264.536\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint7_linear\" x1=\"180.004\" y1=\"203.615\" x2=\"180.649\" y2=\"264.315\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint8_linear\" x1=\"44.9457\" y1=\"205.052\" x2=\"45.5912\" y2=\"265.751\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint9_linear\" x1=\"54.7246\" y1=\"204.948\" x2=\"55.3701\" y2=\"265.647\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint10_linear\" x1=\"71.3993\" y1=\"204.77\" x2=\"72.0449\" y2=\"265.47\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint11_linear\" x1=\"91.0098\" y1=\"204.562\" x2=\"91.6553\" y2=\"265.261\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint12_linear\" x1=\"108.256\" y1=\"204.378\" x2=\"108.901\" y2=\"265.078\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint13_linear\" x1=\"125.73\" y1=\"204.193\" x2=\"126.375\" y2=\"264.892\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint14_linear\" x1=\"146.092\" y1=\"203.976\" x2=\"146.738\" y2=\"264.675\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint15_linear\" x1=\"161.007\" y1=\"203.817\" x2=\"161.652\" y2=\"264.517\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint16_linear\" x1=\"179.48\" y1=\"203.621\" x2=\"180.126\" y2=\"264.32\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint17_linear\" x1=\"32.4901\" y1=\"238.046\" x2=\"38.1034\" y2=\"238.046\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint18_linear\" x1=\"32.3352\" y1=\"247.317\" x2=\"38.2582\" y2=\"247.317\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  <linearGradient id=\"paint19_linear\" x1=\"32.6095\" y1=\"255.717\" x2=\"38.7483\" y2=\"255.717\" gradientUnits=\"userSpaceOnUse\">\n  <stop offset=\"3.92689e-07\" stop-color=\"#FDE48D\"/>\n  <stop offset=\"0.5139\" stop-color=\"#CFA44A\"/>\n  <stop offset=\"1\" stop-color=\"#ECD484\"/>\n  </linearGradient>\n  </defs>\n  </svg>\n  \n</div>\n\n<div class=\"login-form\">\n\n  <ion-text color=\"medium\" class=\"text\">\n    <h6>{{'LOGIN.welcome' | translate}}</h6>\n  </ion-text>\n<form action=\"\">\n\n  <ion-item>\n    <ion-label position=\"fixed\">{{'LOGIN.loginId' | translate}}</ion-label>\n    <ion-input [(ngModel)]=\"loginId\" name=\"loginId\" placeholder=\"{{'LOGIN.placeholder' | translate}}\"></ion-input>\n    <span class=\"error\" *ngIf=\"errors.length!=0\">{{errors.login_id[0]}}</span>\n    <span class=\"error\" *ngIf=\"message\">{{message}}</span>\n\n  </ion-item>\n\n  <div class=\"submit-btn\">\n    <ion-button \n   (click)=\"login($event)\"\n    color=\"primary\" \n    expand=\"block\" \n   >{{'LOGIN.btn' | translate}}</ion-button>\n  \n  </div>\n\n</form>\n\n\n</div>\n\n\n\n</div>\n  <!-- <div id=\"container\">\n    <strong>Ready to create an app?</strong>\n    <p>Start with Ionic <a target=\"_blank\" rel=\"noopener noreferrer\" href=\"https://ionicframework.com/docs/components\">UI Components</a></p>\n  </div> -->\n</ion-content>\n");

/***/ }),

/***/ "./src/app/login/login-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/login/login-routing.module.ts ***!
  \***********************************************/
/*! exports provided: LoginPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function() { return LoginPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"],
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })
], LoginPageRoutingModule);



/***/ }),

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login-routing.module */ "./src/app/login/login-routing.module.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");







 // add this
let LoginPageModule = class LoginPageModule {
};
LoginPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _login_routing_module__WEBPACK_IMPORTED_MODULE_6__["LoginPageRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_5__["LoginPage"]]
    })
], LoginPageModule);



/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("#svg {\n  margin: 0 auto;\n  width: 65vw;\n  -webkit-animation: svgAnimation 1s ease-in-out;\n          animation: svgAnimation 1s ease-in-out;\n  -webkit-animation-fill-mode: forwards;\n          animation-fill-mode: forwards;\n  transform: scale(1) translateY(0%);\n}\n\n@-webkit-keyframes svgAnimation {\n  from {\n    transform: scale(1) translateY(50%);\n  }\n  to {\n    transform: scale(0.5) translateY(0%);\n  }\n}\n\n@keyframes svgAnimation {\n  from {\n    transform: scale(1) translateY(50%);\n  }\n  to {\n    transform: scale(0.5) translateY(0%);\n  }\n}\n\nion-segment {\n  max-width: 40%;\n  margin: 0 auto;\n  margin-top: 3rem;\n  opacity: 0;\n  -webkit-animation: fadeIn 0.3s ease-in;\n          animation: fadeIn 0.3s ease-in;\n  -webkit-animation-fill-mode: forwards;\n          animation-fill-mode: forwards;\n  -webkit-animation-delay: 1s;\n          animation-delay: 1s;\n}\n\n.login-form {\n  opacity: 0;\n  -webkit-animation: fadeIn 0.3s ease-in;\n          animation: fadeIn 0.3s ease-in;\n  -webkit-animation-fill-mode: forwards;\n          animation-fill-mode: forwards;\n  -webkit-animation-delay: 0.8s;\n          animation-delay: 0.8s;\n  padding-top: 0%;\n}\n\n.login-form ion-text {\n  text-transform: uppercase;\n  text-align: center;\n}\n\n.login-form ion-text h4 {\n  text-transform: uppercase;\n}\n\n.login-form form {\n  padding-top: 0%;\n}\n\n.login-form form ion-item {\n  border-top: 1px solid var(--ion-color-light-shade);\n  border-top-color: var(--ion-item-border-color, var(--ion-border-color, var(--ion-color-step-250, #c8c7cc)));\n  --padding-start: 0;\n}\n\n.login-form form ion-item ion-label {\n  padding-left: 1rem;\n}\n\n.login-form form ion-item ion-input {\n  width: 90%;\n  margin-left: 1rem;\n  --margin-start:1rem;\n}\n\n.login-form form .submit-btn {\n  max-width: 92%;\n  margin: 0 auto;\n  margin-top: 2.8rem;\n}\n\n@-webkit-keyframes fadeIn {\n  from {\n    opacity: 0;\n  }\n  to {\n    opacity: 1;\n  }\n}\n\n@keyframes fadeIn {\n  from {\n    opacity: 0;\n  }\n  to {\n    opacity: 1;\n  }\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\n.error {\n  color: var(--ion-color-danger);\n  font-weight: 500;\n  margin: 0.5rem 0;\n  font-size: 0.87rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0UsY0FBQTtFQUNBLFdBQUE7RUFFQyw4Q0FBQTtVQUFBLHNDQUFBO0VBQ0EscUNBQUE7VUFBQSw2QkFBQTtFQUVBLGtDQUFBO0FBRkg7O0FBS0E7RUFDRTtJQUNBLG1DQUFBO0VBRkE7RUFJQTtJQUNFLG9DQUFBO0VBRkY7QUFDRjs7QUFKQTtFQUNFO0lBQ0EsbUNBQUE7RUFGQTtFQUlBO0lBQ0Usb0NBQUE7RUFGRjtBQUNGOztBQU1BO0VBQ0UsY0FBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLFVBQUE7RUFDQSxzQ0FBQTtVQUFBLDhCQUFBO0VBQ0EscUNBQUE7VUFBQSw2QkFBQTtFQUNBLDJCQUFBO1VBQUEsbUJBQUE7QUFKRjs7QUFNQTtFQUNFLFVBQUE7RUFDQSxzQ0FBQTtVQUFBLDhCQUFBO0VBQ0EscUNBQUE7VUFBQSw2QkFBQTtFQUNBLDZCQUFBO1VBQUEscUJBQUE7RUFDQSxlQUFBO0FBSEY7O0FBSUU7RUFDRSx5QkFBQTtFQUVBLGtCQUFBO0FBSEo7O0FBSUk7RUFDRSx5QkFBQTtBQUZOOztBQUtFO0VBQ0UsZUFBQTtBQUhKOztBQUlHO0VBQ0Usa0RBQUE7RUFDQSwyR0FBQTtFQUVELGtCQUFBO0FBSEo7O0FBSUk7RUFDRSxrQkFBQTtBQUZOOztBQUlJO0VBQ0UsVUFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7QUFGTjs7QUFNRztFQUNFLGNBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFKTDs7QUFXQTtFQUNFO0lBQ0UsVUFBQTtFQVJGO0VBV0E7SUFFRSxVQUFBO0VBVkY7QUFDRjs7QUFFQTtFQUNFO0lBQ0UsVUFBQTtFQVJGO0VBV0E7SUFFRSxVQUFBO0VBVkY7QUFDRjs7QUFjQTtFQUNFLGtCQUFBO0VBRUEsa0JBQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFFBQUE7RUFDQSwyQkFBQTtBQWJGOztBQWdCQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtBQWJGOztBQWdCQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUVBLGNBQUE7RUFFQSxTQUFBO0FBZkY7O0FBa0JBO0VBQ0UscUJBQUE7QUFmRjs7QUFpQkE7RUFDRSw4QkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQWRGIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4jc3Zne1xuICBtYXJnaW46IDAgYXV0bztcbiAgd2lkdGg6IDY1dnc7XG4gIC8vIHRyYW5zZm9ybTogc2NhbGUoMSkgdHJhbnNsYXRlWSg1MCUpO1xuICAgYW5pbWF0aW9uOiBzdmdBbmltYXRpb24gMXMgZWFzZS1pbi1vdXQ7XG4gICBhbmltYXRpb24tZmlsbC1tb2RlOiBmb3J3YXJkczsgIFxuICAvLyAgYW5pbWF0aW9uLWRlbGF5OiAycztcbiAgIHRyYW5zZm9ybTogc2NhbGUoMSkgdHJhbnNsYXRlWSgwJSk7XG5cbn1cbkBrZXlmcmFtZXMgc3ZnQW5pbWF0aW9ue1xuICBmcm9te1xuICB0cmFuc2Zvcm06IHNjYWxlKDEpIHRyYW5zbGF0ZVkoNTAlKTtcbiAgfVxuICB0b3tcbiAgICB0cmFuc2Zvcm06IHNjYWxlKC41KSB0cmFuc2xhdGVZKDAlKTtcblxuICB9XG4gIFxufVxuaW9uLXNlZ21lbnR7XG4gIG1heC13aWR0aDogNDAlO1xuICBtYXJnaW46IDAgYXV0bztcbiAgbWFyZ2luLXRvcDozcmVtO1xuICBvcGFjaXR5OiAwO1xuICBhbmltYXRpb246IGZhZGVJbiAuM3MgZWFzZS1pbjtcbiAgYW5pbWF0aW9uLWZpbGwtbW9kZTogZm9yd2FyZHM7XG4gIGFuaW1hdGlvbi1kZWxheTogMXM7XG59XG4ubG9naW4tZm9ybXtcbiAgb3BhY2l0eTogMDtcbiAgYW5pbWF0aW9uOiBmYWRlSW4gLjNzIGVhc2UtaW47XG4gIGFuaW1hdGlvbi1maWxsLW1vZGU6IGZvcndhcmRzO1xuICBhbmltYXRpb24tZGVsYXk6IC44cztcbiAgcGFkZGluZy10b3A6MCU7XG4gIGlvbi10ZXh0e1xuICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG5cbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgaDR7XG4gICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICAgIH1cbiAgfVxuICBmb3Jte1xuICAgIHBhZGRpbmctdG9wOjAlO1xuICAgaW9uLWl0ZW17XG4gICAgIGJvcmRlci10b3A6MXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1saWdodC1zaGFkZSk7XG4gICAgIGJvcmRlci10b3AtY29sb3I6IHZhcigtLWlvbi1pdGVtLWJvcmRlci1jb2xvciwgdmFyKC0taW9uLWJvcmRlci1jb2xvciwgdmFyKC0taW9uLWNvbG9yLXN0ZXAtMjUwLCAjYzhjN2NjKSkpO1xuICAgIC8vICBib3JkZXItY29sb3I6dmFyKC0taW9uLWl0ZW0tYm9yZGVyLWNvbG9yLCB2YXIoLS1pb24tYm9yZGVyLWNvbG9yLCB2YXIoLS1pb24tY29sb3Itc3RlcC0yNTAsICNjOGM3Y2MpKSk7XG4gICAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xuICAgIGlvbi1sYWJlbHtcbiAgICAgIHBhZGRpbmctbGVmdDoxcmVtO1xuICAgIH1cbiAgICBpb24taW5wdXR7XG4gICAgICB3aWR0aDo5MCU7XG4gICAgICBtYXJnaW4tbGVmdDoxcmVtO1xuICAgICAgLS1tYXJnaW4tc3RhcnQ6MXJlbTtcbiAgICB9XG4gICB9XG4gICBcbiAgIC5zdWJtaXQtYnRue1xuICAgICBtYXgtd2lkdGg6OTIlO1xuICAgICBtYXJnaW46MCBhdXRvO1xuICAgICBtYXJnaW4tdG9wOjIuOHJlbTtcbiAgIH1cblxuXG4gIH1cbn1cblxuQGtleWZyYW1lcyBmYWRlSW57XG4gIGZyb217XG4gICAgb3BhY2l0eTowO1xuXG4gIH1cbiAgdG97XG5cbiAgICBvcGFjaXR5OjE7XG4gIH1cbiAgXG59XG5cbiNjb250YWluZXIge1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG5cbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAwO1xuICByaWdodDogMDtcbiAgdG9wOiA1MCU7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtNTAlKTtcbn1cblxuI2NvbnRhaW5lciBzdHJvbmcge1xuICBmb250LXNpemU6IDIwcHg7XG4gIGxpbmUtaGVpZ2h0OiAyNnB4O1xufVxuXG4jY29udGFpbmVyIHAge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAyMnB4O1xuXG4gIGNvbG9yOiAjOGM4YzhjO1xuXG4gIG1hcmdpbjogMDtcbn1cblxuI2NvbnRhaW5lciBhIHtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xufVxuLmVycm9ye1xuICBjb2xvcjp2YXIoLS1pb24tY29sb3ItZGFuZ2VyKTtcbiAgZm9udC13ZWlnaHQ6NTAwO1xuICBtYXJnaW46LjVyZW0gMDtcbiAgZm9udC1zaXplOi44N3JlbTtcbn0iXX0= */");

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _capacitor_community_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor-community/http */ "./node_modules/@capacitor-community/http/dist/esm/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _services_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/storage.service */ "./src/app/services/storage.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");
/* harmony import */ var _services_language_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../services/language.service */ "./src/app/services/language.service.ts");
/* harmony import */ var _services_fcm_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../services/fcm.service */ "./src/app/services/fcm.service.ts");


// Must import the package once to make sure the web support initializes








const { Http } = _capacitor_core__WEBPACK_IMPORTED_MODULE_8__["Plugins"];

let LoginPage = class LoginPage {
    constructor(fcm, translate, languageService, route, store, storage) {
        this.fcm = fcm;
        this.translate = translate;
        this.languageService = languageService;
        this.route = route;
        this.store = store;
        this.storage = storage;
        this.loginId = "";
        this.message = "";
        this.errors = [];
    }
    ionViewWillEnter() {
        this.selectedLang = localStorage.getItem('SELECTED_LANGUAGE');
    }
    login(e) {
        e.target.innerHTML = '<ion-spinner></ion-spinner>';
        e.target.setAttribute('disabled', 'disabled');
        // Example of a POST request. Note: data
        // can be passed as a raw JS Object (must be JSON serializable)
        const doPost = () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.errors = [];
            this.message = '';
            const ret = yield Http.request({
                method: 'POST',
                url: `${_environments_environment__WEBPACK_IMPORTED_MODULE_3__["SERVER_URL"]}/api/token`,
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                },
                data: {
                    login_id: this.loginId,
                }
            });
            return ret;
        });
        doPost().then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            e.target.innerHTML = this.translate.instant('LOGIN.btn');
            e.target.removeAttribute('disabled');
            if (res['status'] == 200) {
                this.fcm.initPush(this.loginId);
                if (res['data'].user.role == 'Manager') {
                    this.store.login(res['data']);
                    this.route.navigateByUrl('/home');
                }
                else if (res['data'].user.role == 'Pilot') {
                    this.store.login(res['data']);
                    const ret = yield Http.request({
                        method: 'POST',
                        url: `${_environments_environment__WEBPACK_IMPORTED_MODULE_3__["SERVER_URL"]}/api/users/status`,
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + res['data'].token
                        },
                        data: {
                            status: "Available"
                        }
                    });
                    return ret;
                    this.route.navigateByUrl('/order');
                }
                this.loginId = "";
                // this.store.setObject(res['data']);
                console.log(res['data']);
                // this.roue.push
            }
            else if (res['status'] == 422) {
                this.errors = res['data'].errors;
            }
            else if (res['status'] == 404) {
                this.message = res['data'].message;
            }
        }));
    }
    changeLang() {
        this.languageService.setLanguage(this.selectedLang);
        // window.location.reload();
    }
};
LoginPage.ctorParameters = () => [
    { type: _services_fcm_service__WEBPACK_IMPORTED_MODULE_10__["FcmService"] },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateService"] },
    { type: _services_language_service__WEBPACK_IMPORTED_MODULE_9__["LanguageService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _services_storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"] }
];
LoginPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-login',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./login.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")).default]
    })
], LoginPage);



/***/ })

}]);
//# sourceMappingURL=login-login-module-es2015.js.map