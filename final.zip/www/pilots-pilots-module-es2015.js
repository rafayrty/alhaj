(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pilots-pilots-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/pilots/pilots.page.html":
/*!****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/settings/pilots/pilots.page.html ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{'SETTINGS.PILOTS.title' | translate}}</ion-title>\n    <!-- <ion-buttons slot=\"end\">\n      <ion-button (click)=\"settings()\">Settings</ion-button>\n    </ion-buttons> -->\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\" pullFactor=\"0.5\" pullMin=\"100\" pullMax=\"200\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n<ion-text class=\"swipe\"><h6>{{'SETTINGS.PILOTS.swipe' | translate}}</h6></ion-text>\n\n\n<div class=\"pilots\" *ngIf=\"!loading\">\n\n<!-- List of Sliding Items -->\n<ion-list  lines=\"full\">\n\n\n    <!-- Sliding item with icon bottom options on end side -->\n    <ion-item-sliding *ngFor=\"let pilot of pilots; let i = index\">\n      <ion-item>\n        <ion-thumbnail slot=\"start\">\n          <img src=\"{{pilot.image}}\">\n        </ion-thumbnail>\n        <ion-label>\n          <h2>{{pilot.name}}</h2>\n        </ion-label>\n\n      </ion-item>\n      <ion-item-options>\n        <ion-item-option color=\"primary\" (click)=\"edit(pilot.id)\">\n          <ion-icon slot=\"bottom\"  name=\"create-outline\"></ion-icon>\n          {{'edit' | translate}}\n        </ion-item-option>\n        <ion-item-option (click)=\"delete(pilot.id,i)\" color=\"danger\">\n          <ion-icon slot=\"bottom\" name=\"trash-outline\"></ion-icon>\n          {{'delete' | translate}}\n\n        </ion-item-option>\n      </ion-item-options>\n    </ion-item-sliding>\n</ion-list>\n</div>\n\n<div class=\"pilots\" *ngIf=\"loading\">\n\n  <ion-list  lines=\"full\">\n\n\n    <!-- Sliding item with icon bottom options on end side -->\n      <ion-item>\n        <ion-thumbnail slot=\"start\">\n          <ion-skeleton-text animated style=\"border-radius:40px;width: 100%\"></ion-skeleton-text>\n\n          <!-- <ion-skeleton-text style=\"height:100px;\"></ion-skeleton-text> -->\n        </ion-thumbnail>\n        <ion-label>\n          <ion-skeleton-text animated style=\"width: 60%\"></ion-skeleton-text>\n\n        </ion-label>\n\n      </ion-item>\n\n      <ion-item>\n        <ion-thumbnail slot=\"start\">\n          <ion-skeleton-text animated style=\"border-radius:40px;width: 100%\"></ion-skeleton-text>\n\n          <!-- <ion-skeleton-text style=\"height:100px;\"></ion-skeleton-text> -->\n        </ion-thumbnail>\n        <ion-label>\n          <ion-skeleton-text animated style=\"width: 60%\"></ion-skeleton-text>\n\n        </ion-label>\n\n      </ion-item>\n\n\n      <ion-item>\n        <ion-thumbnail slot=\"start\">\n          <ion-skeleton-text animated style=\"border-radius:40px;width: 100%\"></ion-skeleton-text>\n\n          <!-- <ion-skeleton-text style=\"height:100px;\"></ion-skeleton-text> -->\n        </ion-thumbnail>\n        <ion-label>\n          <ion-skeleton-text animated style=\"width: 60%\"></ion-skeleton-text>\n\n        </ion-label>\n\n      </ion-item>\n\n      <ion-item>\n        <ion-thumbnail slot=\"start\">\n          <ion-skeleton-text animated style=\"border-radius:40px;width: 100%\"></ion-skeleton-text>\n\n          <!-- <ion-skeleton-text style=\"height:100px;\"></ion-skeleton-text> -->\n        </ion-thumbnail>\n        <ion-label>\n          <ion-skeleton-text animated style=\"width: 60%\"></ion-skeleton-text>\n\n        </ion-label>\n\n      </ion-item>\n\n      <ion-item>\n        <ion-thumbnail slot=\"start\">\n          <ion-skeleton-text animated style=\"border-radius:40px;width: 100%\"></ion-skeleton-text>\n\n          <!-- <ion-skeleton-text style=\"height:100px;\"></ion-skeleton-text> -->\n        </ion-thumbnail>\n        <ion-label>\n          <ion-skeleton-text animated style=\"width: 60%\"></ion-skeleton-text>\n\n        </ion-label>\n\n      </ion-item>\n  \n  \n</ion-list>\n\n</div>\n\n\n</ion-content>\n\n<ion-footer>\n  <ion-button  expand=\"block\" routerLink=\"/settings/pilots/create\"> <ion-icon name=\"add-outline\" ></ion-icon> {{'SETTINGS.PILOTS.new' | translate}}</ion-button>\n</ion-footer>");

/***/ }),

/***/ "./src/app/settings/pilots/pilots-routing.module.ts":
/*!**********************************************************!*\
  !*** ./src/app/settings/pilots/pilots-routing.module.ts ***!
  \**********************************************************/
/*! exports provided: PilotsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PilotsPageRoutingModule", function() { return PilotsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _pilots_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pilots.page */ "./src/app/settings/pilots/pilots.page.ts");




const routes = [
    {
        path: '',
        component: _pilots_page__WEBPACK_IMPORTED_MODULE_3__["PilotsPage"]
    },
    {
        path: 'create',
        loadChildren: () => Promise.all(/*! import() | create-create-module */[__webpack_require__.e("common"), __webpack_require__.e("create-create-module")]).then(__webpack_require__.bind(null, /*! ./create/create.module */ "./src/app/settings/pilots/create/create.module.ts")).then(m => m.CreatePageModule)
    },
    {
        path: 'edit/:id',
        loadChildren: () => Promise.all(/*! import() | edit-edit-module */[__webpack_require__.e("common"), __webpack_require__.e("edit-edit-module")]).then(__webpack_require__.bind(null, /*! ./edit/edit.module */ "./src/app/settings/pilots/edit/edit.module.ts")).then(m => m.EditPageModule)
    }
];
let PilotsPageRoutingModule = class PilotsPageRoutingModule {
};
PilotsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PilotsPageRoutingModule);



/***/ }),

/***/ "./src/app/settings/pilots/pilots.module.ts":
/*!**************************************************!*\
  !*** ./src/app/settings/pilots/pilots.module.ts ***!
  \**************************************************/
/*! exports provided: PilotsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PilotsPageModule", function() { return PilotsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _pilots_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pilots-routing.module */ "./src/app/settings/pilots/pilots-routing.module.ts");
/* harmony import */ var _pilots_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pilots.page */ "./src/app/settings/pilots/pilots.page.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");







 // add this
let PilotsPageModule = class PilotsPageModule {
};
PilotsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _pilots_routing_module__WEBPACK_IMPORTED_MODULE_5__["PilotsPageRoutingModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"]
        ],
        declarations: [_pilots_page__WEBPACK_IMPORTED_MODULE_6__["PilotsPage"]]
    })
], PilotsPageModule);



/***/ }),

/***/ "./src/app/settings/pilots/pilots.page.scss":
/*!**************************************************!*\
  !*** ./src/app/settings/pilots/pilots.page.scss ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".swipe {\n  text-align: center;\n  color: var(--ion-color-medium);\n  font-size: 0.8125rem;\n}\n.swipe h6 {\n  font-weight: 400;\n  margin-top: 0.6rem;\n}\nion-thumbnail img {\n  border-radius: 40px;\n}\nion-list ion-item {\n  --padding-top:.5rem;\n  --padding-bottom:.5rem;\n}\nion-footer {\n  max-width: 92%;\n  margin: 0 auto;\n  margin-bottom: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2V0dGluZ3MvcGlsb3RzL3BpbG90cy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0E7RUFDRyxrQkFBQTtFQUNBLDhCQUFBO0VBQ0Esb0JBQUE7QUFGSDtBQUdHO0VBQ0MsZ0JBQUE7RUFDQSxrQkFBQTtBQURKO0FBTUk7RUFDSSxtQkFBQTtBQUhSO0FBUUk7RUFDSSxtQkFBQTtFQUNBLHNCQUFBO0FBTFI7QUFRQTtFQUNJLGNBQUE7RUFDQSxjQUFBO0VBQ0EsbUJBQUE7QUFMSiIsImZpbGUiOiJzcmMvYXBwL3NldHRpbmdzL3BpbG90cy9waWxvdHMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGZ1bmN0aW9uIHJlbSgkc2l6ZSkge1xyXG4gICAgQHJldHVybiAkc2l6ZSAvIDE2cHggKiAxcmVtO1xyXG4gIH1cclxuLnN3aXBle1xyXG4gICB0ZXh0LWFsaWduOmNlbnRlcjsgXHJcbiAgIGNvbG9yOnZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICBmb250LXNpemU6cmVtKDEzcHgpO1xyXG4gICBoNntcclxuICAgIGZvbnQtd2VpZ2h0OjQwMDtcclxuICAgIG1hcmdpbi10b3A6LjZyZW07XHJcbiAgIH1cclxuXHJcbn1cclxuaW9uLXRodW1ibmFpbHtcclxuICAgIGltZ3tcclxuICAgICAgICBib3JkZXItcmFkaXVzOjQwcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbmlvbi1saXN0e1xyXG4gICAgaW9uLWl0ZW17XHJcbiAgICAgICAgLS1wYWRkaW5nLXRvcDouNXJlbTtcclxuICAgICAgICAtLXBhZGRpbmctYm90dG9tOi41cmVtO1xyXG4gICAgfVxyXG59XHJcbmlvbi1mb290ZXJ7XHJcbiAgICBtYXgtd2lkdGg6OTIlO1xyXG4gICAgbWFyZ2luOjAgYXV0bztcclxuICAgIG1hcmdpbi1ib3R0b206MXJlbTtcclxufSJdfQ== */");

/***/ }),

/***/ "./src/app/settings/pilots/pilots.page.ts":
/*!************************************************!*\
  !*** ./src/app/settings/pilots/pilots.page.ts ***!
  \************************************************/
/*! exports provided: PilotsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PilotsPage", function() { return PilotsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _capacitor_community_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor-community/http */ "./node_modules/@capacitor-community/http/dist/esm/index.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");








const { Haptics, Http } = _capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Plugins"];
let PilotsPage = class PilotsPage {
    constructor(router, activated, alertController, storage) {
        this.router = router;
        this.activated = activated;
        this.alertController = alertController;
        this.storage = storage;
        this.pilots = [];
        this.loading = true;
        this.activated.queryParams.subscribe(params => {
            if (params && params.reload) {
                this.fetchPilots();
            }
        });
    }
    ngOnInit() {
        this.fetchPilots();
    }
    hapticsImpact(style = _capacitor_core__WEBPACK_IMPORTED_MODULE_7__["HapticsImpactStyle"].Heavy) {
        // Native StatusBar available
        if (_capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Capacitor"].getPlatform() != 'web') {
            Haptics.impact({
                style: style
            });
        }
    }
    hapticsImpactLight() {
        this.hapticsImpact(_capacitor_core__WEBPACK_IMPORTED_MODULE_7__["HapticsImpactStyle"].Light);
    }
    hapticsImpactHeavy() {
        this.hapticsImpact(_capacitor_core__WEBPACK_IMPORTED_MODULE_7__["HapticsImpactStyle"].Heavy);
    }
    doRefresh(event) {
        this.fetchPilots();
        setTimeout(() => {
            event.target.complete();
        }, 2000);
    }
    fetchPilots() {
        this.storage.get('USER_INFO').then(res => {
            console.log(res.token);
            const doGet = () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                const ret = yield Http.request({
                    method: 'GET',
                    url: `${_environments_environment__WEBPACK_IMPORTED_MODULE_3__["SERVER_URL"]}/api/users`,
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res.token
                    }
                });
                return ret;
            });
            doGet().then(res => {
                this.pilots = res['data'];
                this.loading = false;
            });
        });
    }
    deleteConfirm(id, index) {
        this.hapticsImpactHeavy();
        this.pilots.splice(index);
        this.storage.get('USER_INFO').then((res) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const ret = yield Http.request({
                method: 'GET',
                url: `${_environments_environment__WEBPACK_IMPORTED_MODULE_3__["SERVER_URL"]}/api/users/delete/${id}`,
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + res.token
                }
            });
            return ret;
        }));
    }
    edit(id) {
        this.router.navigateByUrl('/settings/pilots/edit/' + id);
    }
    delete(id, index) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.hapticsImpactLight();
            const alert = yield this.alertController.create({
                cssClass: 'my-custom-class',
                header: 'Confirmation!',
                message: 'Are You Sure You Want To Delete This <strong>Pilot</strong>!',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            console.log('Confirm Cancel: blah');
                        }
                    }, {
                        text: 'Confirm',
                        handler: () => {
                            this.deleteConfirm(id, index);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
PilotsPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"] }
];
PilotsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-pilots',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./pilots.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/pilots/pilots.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./pilots.page.scss */ "./src/app/settings/pilots/pilots.page.scss")).default]
    })
], PilotsPage);



/***/ })

}]);
//# sourceMappingURL=pilots-pilots-module-es2015.js.map