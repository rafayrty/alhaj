(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["orders-create-create-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/create/create.page.html":
    /*!**************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/orders/create/create.page.html ***!
      \**************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppOrdersCreateCreatePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-menu [title]=\"title\"></app-menu>\n\n<ion-content>\n\n\n\n\n  <div class=\"create\">\n    <div class=\"step1\" *ngIf=\"step1\"   [@enterAnimation]>\n\n\n      <form action=\"\">\n\n        <div class=\"form\">\n          <ion-item lines=\"none\">\n            <ion-label color=\"medium\" position=\"stacked\">{{'CREATE.name' | translate}}</ion-label>\n            <ion-input placeholder=\"{{'CREATE.name_placeholder' | translate}}\" [(ngModel)]=\"form.name\"  name=\"name\" autofocus=\"true\"></ion-input>\n            <span class=\"error\" *ngIf=\"errors.length!=0 && errors.name\">{{errors.name[0]}}</span>\n\n          </ion-item>\n\n\n          <ion-item lines=\"none\">\n            <ion-label color=\"medium\" position=\"stacked\">{{'CREATE.phone' | translate}}</ion-label>\n            <ion-input placeholder=\"{{'CREATE.phone_placeholder' | translate}}\" [(ngModel)]=\"form.phone\" name=\"phone\" autofocus=\"true\"></ion-input>\n            <span class=\"error\" *ngIf=\"errors.length!=0 && errors.phone\">{{errors.phone[0]}}</span>\n\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-label color=\"medium\" position=\"stacked\">{{'CREATE.address' | translate}}</ion-label>\n            <ion-input placeholder=\"{{'CREATE.address_placeholder' | translate}}\"  [(ngModel)]=\"form.address\" name=\"address\" autofocus=\"true\"></ion-input>\n            <span class=\"error\" *ngIf=\"errors.length!=0 && errors.address\">{{errors.address[0]}}</span>\n\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-label color=\"medium\" position=\"stacked\">{{'CREATE.price' | translate}}</ion-label>\n            <ion-input placeholder=\"{{'CREATE.price_placeholder' | translate}}\"  [(ngModel)]=\"form.price\" name=\"price\" autofocus=\"true\"></ion-input>\n            <span class=\"error\" *ngIf=\"errors.length!=0 && errors.price\">{{errors.price[0]}}</span>\n\n          </ion-item>\n          <ion-item lines=\"none\">\n            <ion-label color=\"medium\" position=\"stacked\">{{'CREATE.order' | translate}}</ion-label>\n            <ion-textarea autoGrow=\"true\" rows=\"4\" [(ngModel)]=\"form.order\" name=\"order\" placeholder=\"{{'CREATE.order_placeholder' | translate}}\"> </ion-textarea>\n            <span class=\"error\" *ngIf=\"errors.length!=0 && errors.order\">{{errors.order[0]}}</span>\n            <span class=\"error\" *ngIf=\"errors.length!=0 && errors.image\">{{errors.image[0]}}</span>\n          </ion-item>\n          <div class=\"images\">\n            <div class=\"image\" *ngIf=\"image\" >\n              <ion-thumbnail height=\"65\" width=\"65\">\n                <img [src]=\"image\">\n              </ion-thumbnail>\n            </div>\n            <div class=\"image-upload\">\n              <ion-button (click)=\"openCamera()\">\n                <ion-icon name=\"camera-sharp\"></ion-icon>\n              </ion-button>\n            </div>\n          </div>\n\n\n\n        </div>\n\n\n\n\n\n      </form>\n    </div>\n    <div class=\"step2\" *ngIf=\"step2\"   [@enterAnimation]    >\n\n\n      <div class=\"top\">\n        <div class=\"searchBar\">\n          <ion-searchbar animated  [(ngModel)]=\"searchPilots\"\n          (ionChange)=\"filterPilots()\" placeholder=\"{{'search' | translate}}\" name=\"searchPilots\"></ion-searchbar>\n\n        </div>\n        <ion-text>\n          {{'CREATE.PILOT.choose' | translate}}\n        </ion-text>\n      </div>\n\n\n\n      <div class=\"items\">\n\n\n\n        <!-- List of Input Items -->\n        <ion-list lines=\"full\">\n\n          <ion-radio-group value=\"pilot\"  name=\"pilot\" [(ngModel)]=\"form.pilot\" mode=\"md\">\n\n            <div class=\"item\" *ngFor=\"let pilot of pilots; let i = index\">\n              <div class=\"overlay\" *ngIf=\"pilot.status == 'Out For Delivery' || pilot.status == 'Logged Out'\"></div>\n\n              <ion-item >\n                <ion-thumbnail slot=\"start\">\n                  <img  src=\"{{pilot.image}}\">\n                </ion-thumbnail>\n                <ion-label>\n                  <h4>{{pilot.name}}</h4>\n                  <h6 class=\"warning\" *ngIf=\"pilot.status == 'Out For Delivery'\">{{'STATUS.out' | translate}}</h6>\n                  <h6 class=\"available\" *ngIf=\"pilot.status == 'Available'\">{{'STATUS.available' | translate}}</h6>\n                  <h6 class=\"danger\" *ngIf=\"pilot.status == 'Logged Out'\">{{'STATUS.logged' | translate}}</h6>\n\n                </ion-label>\n                <ion-radio slot=\"end\" value=\"{{pilot.id}}\"></ion-radio>\n\n\n              </ion-item>\n            </div>\n\n            <!-- <div class=\"item\">\n              <div class=\"overlay\"></div>\n\n              <ion-item>\n                <ion-thumbnail slot=\"start\">\n                  <img src=\"/assets/images/ricky.png\">\n                </ion-thumbnail>\n                <ion-label>\n                  <h4>Ricky Mclaughlin</h4>\n                  <h6 class=\"delivery\">Available</h6>\n                </ion-label>\n\n                <ion-radio slot=\"end\" value=\"1\"></ion-radio>\n\n              </ion-item>\n            </div> -->\n          </ion-radio-group>\n\n        </ion-list>\n      </div>\n\n      <!-- <div class=\"assignVehicle\">\n        <ion-button expand=\"block\" (click)=\"next()\" color=\"success\">Assign A Vehicle</ion-button>\n\n      </div> -->\n\n    </div>\n\n\n    <div class=\"step3\" *ngIf=\"step3\"   [@enterAnimation]>\n      <div class=\"top\">\n        <div class=\"searchBar\">\n          <ion-searchbar animated placeholder=\"{{'search' | translate}}\" [(ngModel)]=\"searchVehicles\"\n          (ionChange)=\"filterVehicles()\" name=\"searchVehicles\"></ion-searchbar>\n\n        </div>\n        <ion-text>\n          {{'CREATE.VEHICLE.choose' | translate}}\n        </ion-text>\n      </div>\n\n\n\n      <div class=\"items\">\n\n\n\n        <!-- List of Input Items -->\n        <ion-list lines=\"full\">\n          <ion-radio-group value=\"vehicle\" name=\"vehicle\" [(ngModel)]=\"form.vehicle\" [(ngModel)]=\"form.vehicle\" mode=\"md\">\n\n            <div class=\"item\" *ngFor=\"let vehicle of vehicles; let i = index\">\n              <div class=\"overlay\" *ngIf=\"vehicle.status == 'Out For Delivery'\"></div>\n\n              <ion-item >\n                <ion-thumbnail slot=\"start\">\n                  <img src=\"{{vehicle.image}}\">\n                </ion-thumbnail>\n                <ion-label>\n                  <h4>{{vehicle.name}}</h4>\n                  <h6 class=\"warning\" *ngIf=\"vehicle.status == 'Out For Delivery'\">{{'STATUS.out' | translate}}</h6>\n                  <h6 class=\"available\" *ngIf=\"vehicle.status == 'Available'\">{{'STATUS.available' | translate}}</h6>\n                                </ion-label>\n\n                <ion-radio slot=\"end\" value=\"{{vehicle.id}}\"></ion-radio>\n\n              </ion-item>\n            </div>\n<!-- \n            <div class=\"item\">\n              <div class=\"overlay\"></div>\n\n              <ion-item>\n                <ion-thumbnail slot=\"start\">\n                  <img src=\"/assets/images/ricky.png\">\n                </ion-thumbnail>\n                <ion-label>\n                  <h4>Ricky Mclaughlin</h4>\n                  <h6 class=\"delivery\">Available</h6>\n                </ion-label>\n\n                <ion-radio slot=\"end\" value=\"1\"></ion-radio>\n\n              </ion-item>\n            </div> -->\n          </ion-radio-group>\n\n\n        </ion-list>\n      </div>\n\n      <!-- <div class=\"assignVehicle\">\n        <ion-button expand=\"block\" (click)=\"send()\" color=\"success\">Send</ion-button>\n\n      </div> -->\n\n    </div>\n\n  </div>\n\n\n</ion-content>\n\n\n\n<ion-footer *ngIf=\"step1\">\n  <ion-button color=\"primary\" (click)=\"next($event,'proceed')\" expand=\"block\"> {{'CREATE.proceed' | translate}}</ion-button>\n</ion-footer>\n\n\n<ion-footer *ngIf=\"step2\">\n  <ion-button expand=\"block\" (click)=\"next($event,'pilot')\" color=\"success\">{{'CREATE.VEHICLE.title' | translate}}</ion-button>\n</ion-footer>\n\n<ion-footer *ngIf=\"step3\">\n  <ion-button expand=\"block\" (click)=\"send($event)\" color=\"success\">{{'CREATE.VEHICLE.send' | translate}}</ion-button>\n\n</ion-footer>\n";
      /***/
    },

    /***/
    "./src/app/orders/create/create-routing.module.ts":
    /*!********************************************************!*\
      !*** ./src/app/orders/create/create-routing.module.ts ***!
      \********************************************************/

    /*! exports provided: CreatePageRoutingModule */

    /***/
    function srcAppOrdersCreateCreateRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CreatePageRoutingModule", function () {
        return CreatePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _create_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./create.page */
      "./src/app/orders/create/create.page.ts");

      var routes = [{
        path: '',
        component: _create_page__WEBPACK_IMPORTED_MODULE_3__["CreatePage"]
      }];

      var CreatePageRoutingModule = function CreatePageRoutingModule() {
        _classCallCheck(this, CreatePageRoutingModule);
      };

      CreatePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], CreatePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/orders/create/create.module.ts":
    /*!************************************************!*\
      !*** ./src/app/orders/create/create.module.ts ***!
      \************************************************/

    /*! exports provided: CreatePageModule */

    /***/
    function srcAppOrdersCreateCreateModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CreatePageModule", function () {
        return CreatePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _create_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./create-routing.module */
      "./src/app/orders/create/create-routing.module.ts");
      /* harmony import */


      var _create_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./create.page */
      "./src/app/orders/create/create.page.ts");
      /* harmony import */


      var _components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../components.module */
      "./src/app/components.module.ts");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @ngx-translate/core */
      "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js"); // add this


      var CreatePageModule = function CreatePageModule() {
        _classCallCheck(this, CreatePageModule);
      };

      CreatePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _create_routing_module__WEBPACK_IMPORTED_MODULE_5__["CreatePageRoutingModule"], _components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"]],
        declarations: [_create_page__WEBPACK_IMPORTED_MODULE_6__["CreatePage"]]
      })], CreatePageModule);
      /***/
    },

    /***/
    "./src/app/orders/create/create.page.scss":
    /*!************************************************!*\
      !*** ./src/app/orders/create/create.page.scss ***!
      \************************************************/

    /*! exports provided: default */

    /***/
    function srcAppOrdersCreateCreatePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".create {\n  margin-top: 1rem;\n}\n.create form .form {\n  max-width: 90%;\n  margin: 0 auto;\n}\n.create form .form ion-item {\n  margin-top: 0.7rem;\n  --padding-start: 0;\n  --padding-end: 0;\n  --inner-padding-end: 0;\n}\n.create form .form ion-item ion-label {\n  text-transform: uppercase;\n  padding-left: 0.5rem;\n  font-weight: 400;\n  font-size: 0.8rem;\n}\n.create form .form ion-item ion-input, .create form .form ion-item ion-textarea {\n  --padding-end:.5rem;\n  --padding-start:.5rem;\n  border: 1px solid var(--ion-color-medium-shade);\n  border-radius: 6px;\n  --padding-top:.8rem;\n  --padding-bottom:.8rem;\n  background: var(--ion-color-medium-tint);\n  transition: 0.3s ease-in;\n}\n.create form .form ion-item ion-input:focus, .create form .form ion-item ion-textarea:focus {\n  border: 1px solid var(--ion-color-primary);\n}\n.create form .form .images {\n  display: flex;\n  margin: 1rem 0;\n}\n.create form .form .images .image {\n  margin-right: 0.5rem;\n  height: 65px;\n  width: 65px;\n}\n.create form .form .images .image ion-thumbnail {\n  height: 65px;\n  width: 65px;\n}\n.create form .form .images .image ion-thumbnail img {\n  display: block;\n  border: 1px solid var(--ion-color-primary);\n  border-radius: 40px;\n  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.06);\n  height: 65px;\n  width: 65px;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n.create form .form .images .image-upload ion-button {\n  height: auto;\n  --color:var(--ion-color-primary);\n  border: 1px solid var(--ion-color-primary);\n  border-radius: 6px;\n  height: 65px;\n  width: 65px;\n  font-size: 1.2rem;\n  --background-activated:var( --ion-color-medium-tint);\n  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.06);\n  --background:var(--ion-color-medium-contrast);\n  margin: 0;\n  --margin-top:0;\n  --margin-bottom:0;\n}\n.create .searchBar {\n  max-width: 86%;\n  margin: 0 auto;\n}\n.create ion-text {\n  color: var(--ion-color-medium);\n  max-width: 86%;\n  display: block;\n  margin: 1rem auto;\n  padding: 0rem 12px;\n  text-transform: uppercase;\n  font-size: 0.8125rem;\n}\n.create .items {\n  min-height: calc(73vh - 70px);\n}\n.create .items .item {\n  position: relative;\n}\n.create .items .item .overlay {\n  position: absolute;\n  background: rgba(255, 255, 255, 0.8);\n  width: 100%;\n  height: 100%;\n  z-index: 2;\n}\n.create .items ion-item {\n  --padding-top:.5rem;\n  --padding-bottom:.5rem;\n}\n.create .items ion-item ion-thumbnail img {\n  border-radius: 40px;\n}\n.create .items ion-item ion-label h4 {\n  color: var(--ion-color-dark);\n  font-size: 1.25rem;\n}\n.create .items ion-item ion-label h6.available {\n  color: var(--ion-color-success);\n}\n.create .items ion-item ion-label h6.delivery {\n  color: var(--ion-color-warning);\n}\n.create .items ion-item ion-label h6.danger {\n  color: var(--ion-color-danger);\n}\n.create .assignVehicle {\n  height: 50px;\n  max-width: 92%;\n  margin: 1.4rem auto;\n}\nion-footer {\n  max-width: 92%;\n  margin: 0 auto;\n  margin-bottom: 1rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvb3JkZXJzL2NyZWF0ZS9jcmVhdGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBO0VBQ0ksZ0JBQUE7QUFGSjtBQUlRO0VBQ0ksY0FBQTtFQUNBLGNBQUE7QUFGWjtBQUdZO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esc0JBQUE7QUFEaEI7QUFHVztFQUNJLHlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBRGY7QUFJVztFQUNDLG1CQUFBO0VBQ0EscUJBQUE7RUFFRywrQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLHdDQUFBO0VBQ0Esd0JBQUE7QUFIZjtBQUllO0VBQ0MsMENBQUE7QUFGaEI7QUFRWTtFQUNJLGFBQUE7RUFFQSxjQUFBO0FBUGhCO0FBUWdCO0VBRUksb0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBQVBwQjtBQVNvQjtFQUNJLFlBQUE7RUFDQSxXQUFBO0FBUHhCO0FBUXdCO0VBRUksY0FBQTtFQUNBLDBDQUFBO0VBQ0EsbUJBQUE7RUFDQSwyQ0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtBQVA1QjtBQWNvQjtFQUVJLFlBQUE7RUFFQSxnQ0FBQTtFQUNBLDBDQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBRUEsb0RBQUE7RUFDQSwyQ0FBQTtFQUNBLDZDQUFBO0VBQ0EsU0FBQTtFQUNBLGNBQUE7RUFDQSxpQkFBQTtBQWZ4QjtBQXlCQTtFQUNJLGNBQUE7RUFDQSxjQUFBO0FBdkJKO0FBeUJBO0VBQ0ksOEJBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLG9CQUFBO0FBdkJKO0FBMEJBO0VBQ0ksNkJBQUE7QUF4Qko7QUEwQkk7RUFDSSxrQkFBQTtBQXhCUjtBQXlCUTtFQUNJLGtCQUFBO0VBQ0Esb0NBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFVBQUE7QUF2Qlo7QUEwQkk7RUFDSSxtQkFBQTtFQUNBLHNCQUFBO0FBeEJSO0FBMEJZO0VBQ0ksbUJBQUE7QUF4QmhCO0FBNEJZO0VBQ0EsNEJBQUE7RUFDQSxrQkFBQTtBQTFCWjtBQTRCWTtFQUNJLCtCQUFBO0FBMUJoQjtBQTZCWTtFQUNJLCtCQUFBO0FBM0JoQjtBQThCWTtFQUNJLDhCQUFBO0FBNUJoQjtBQXFDQTtFQUNJLFlBQUE7RUFFQSxjQUFBO0VBQ0EsbUJBQUE7QUFwQ0o7QUE0Q0E7RUFDSSxjQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0FBekNKIiwiZmlsZSI6InNyYy9hcHAvb3JkZXJzL2NyZWF0ZS9jcmVhdGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGZ1bmN0aW9uIHJlbSgkc2l6ZSkge1xyXG4gICAgQHJldHVybiAkc2l6ZSAvIDE2cHggKiAxcmVtO1xyXG4gIH1cclxuLmNyZWF0ZXtcclxuICAgIG1hcmdpbi10b3A6MXJlbTtcclxuICAgIGZvcm17XHJcbiAgICAgICAgLmZvcm17XHJcbiAgICAgICAgICAgIG1heC13aWR0aDo5MCU7XHJcbiAgICAgICAgICAgIG1hcmdpbjowIGF1dG87XHJcbiAgICAgICAgICAgIGlvbi1pdGVte1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDouN3JlbTtcclxuICAgICAgICAgICAgICAgIC0tcGFkZGluZy1zdGFydDogMDtcclxuICAgICAgICAgICAgICAgIC0tcGFkZGluZy1lbmQ6IDA7XHJcbiAgICAgICAgICAgICAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xyXG5cclxuICAgICAgICAgICBpb24tbGFiZWx7XHJcbiAgICAgICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICAgICAgICAgICAgIHBhZGRpbmctbGVmdDouNXJlbTtcclxuICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6NDAwO1xyXG4gICAgICAgICAgICAgICBmb250LXNpemU6LjhyZW07XHJcblxyXG4gICAgICAgICAgIH1cclxuICAgICAgICAgICBpb24taW5wdXQsaW9uLXRleHRhcmVhe1xyXG4gICAgICAgICAgICAtLXBhZGRpbmctZW5kOi41cmVtO1xyXG4gICAgICAgICAgICAtLXBhZGRpbmctc3RhcnQ6LjVyZW07XHJcblxyXG4gICAgICAgICAgICAgICBib3JkZXI6MXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1tZWRpdW0tc2hhZGUpO1xyXG4gICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOjZweDtcclxuICAgICAgICAgICAgICAgLS1wYWRkaW5nLXRvcDouOHJlbTtcclxuICAgICAgICAgICAgICAgLS1wYWRkaW5nLWJvdHRvbTouOHJlbTtcclxuICAgICAgICAgICAgICAgYmFja2dyb3VuZDp2YXIoLS1pb24tY29sb3ItbWVkaXVtLXRpbnQpO1xyXG4gICAgICAgICAgICAgICB0cmFuc2l0aW9uOi4zcyBlYXNlLWluO1xyXG4gICAgICAgICAgICAgICAmOmZvY3Vze1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOjFweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcblxyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAuaW1hZ2Vze1xyXG4gICAgICAgICAgICAgICAgZGlzcGxheTpmbGV4O1xyXG5cclxuICAgICAgICAgICAgICAgIG1hcmdpbjoxcmVtIDA7XHJcbiAgICAgICAgICAgICAgICAuaW1hZ2V7XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbi1yaWdodDouNXJlbTtcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6NjVweDtcclxuICAgICAgICAgICAgICAgICAgICB3aWR0aDo2NXB4O1xyXG5cclxuICAgICAgICAgICAgICAgICAgICBpb24tdGh1bWJuYWlse1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6NjVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6NjVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaW1ne1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6YmxvY2s7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6MXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6NDBweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJveC1zaGFkb3c6IDBweCA0cHggNHB4IHJnYmEoMCwgMCwgMCwgMC4wNik7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6NjVweDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOjY1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLmltYWdlLXVwbG9hZHtcclxuICAgICAgICAgICAgICAgICAgICBpb24tYnV0dG9ue1xyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgICAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0tY29sb3I6dmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXI6MXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czo2cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDo2NXB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDo2NXB4O1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6MS4ycmVtO1xyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQtYWN0aXZhdGVkOnZhciggIC0taW9uLWNvbG9yLW1lZGl1bS10aW50KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm94LXNoYWRvdzogMHB4IDRweCA0cHggcmdiYSgwLCAwLCAwLCAwLjA2KTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOnZhcigtLWlvbi1jb2xvci1tZWRpdW0tY29udHJhc3QpO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46MDtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLS1tYXJnaW4tdG9wOjA7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC0tbWFyZ2luLWJvdHRvbTowO1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbi8vU3RlcDJcclxuXHJcblxyXG4uc2VhcmNoQmFye1xyXG4gICAgbWF4LXdpZHRoOjg2JTtcclxuICAgIG1hcmdpbjowIGF1dG87XHJcbn1cclxuaW9uLXRleHR7XHJcbiAgICBjb2xvcjp2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcclxuICAgIG1heC13aWR0aDo4NiU7XHJcbiAgICBkaXNwbGF5OmJsb2NrO1xyXG4gICAgbWFyZ2luOjFyZW0gYXV0bztcclxuICAgIHBhZGRpbmc6MHJlbSAxMnB4O1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgIGZvbnQtc2l6ZTpyZW0oMTNweCk7XHJcblxyXG59XHJcbi5pdGVtc3tcclxuICAgIG1pbi1oZWlnaHQ6IGNhbGMoNzN2aCAtIDcwcHgpO1xyXG5cclxuICAgIC5pdGVte1xyXG4gICAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgICAub3ZlcmxheXtcclxuICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOnJnYmEoMjU1LDI1NSwyNTUsLjgpO1xyXG4gICAgICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgICAgICBoZWlnaHQ6MTAwJTtcclxuICAgICAgICAgICAgei1pbmRleDoyO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIGlvbi1pdGVte1xyXG4gICAgICAgIC0tcGFkZGluZy10b3A6LjVyZW07XHJcbiAgICAgICAgLS1wYWRkaW5nLWJvdHRvbTouNXJlbTtcclxuICAgICAgICBpb24tdGh1bWJuYWlse1xyXG4gICAgICAgICAgICBpbWd7XHJcbiAgICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOjQwcHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICBoNHtcclxuICAgICAgICAgICAgY29sb3I6dmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gICAgICAgICAgICBmb250LXNpemU6cmVtKDIwcHgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGg2LmF2YWlsYWJsZXtcclxuICAgICAgICAgICAgICAgIGNvbG9yOnZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcclxuXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaDYuZGVsaXZlcnl7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjp2YXIoLS1pb24tY29sb3Itd2FybmluZyk7XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBoNi5kYW5nZXJ7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjp2YXIoLS1pb24tY29sb3ItZGFuZ2VyKTtcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgIFxyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgXHJcbiBcclxufVxyXG4uYXNzaWduVmVoaWNsZXtcclxuICAgIGhlaWdodDogNTBweDtcclxuXHJcbiAgICBtYXgtd2lkdGg6IDkyJTtcclxuICAgIG1hcmdpbjoxLjRyZW0gYXV0bztcclxufVxyXG5cclxuXHJcblxyXG5cclxuXHJcbn1cclxuaW9uLWZvb3RlcntcclxuICAgIG1heC13aWR0aDo5MiU7XHJcbiAgICBtYXJnaW46MCBhdXRvO1xyXG4gICAgbWFyZ2luLWJvdHRvbToxcmVtO1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/orders/create/create.page.ts":
    /*!**********************************************!*\
      !*** ./src/app/orders/create/create.page.ts ***!
      \**********************************************/

    /*! exports provided: CreatePage */

    /***/
    function srcAppOrdersCreateCreatePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CreatePage", function () {
        return CreatePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/platform-browser */
      "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
      /* harmony import */


      var _services_photo_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../../services/photo.service */
      "./src/app/services/photo.service.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_animations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/animations */
      "./node_modules/@angular/animations/__ivy_ngcc__/fesm2015/animations.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _capacitor_community_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @capacitor-community/http */
      "./node_modules/@capacitor-community/http/dist/esm/index.js");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ../../../environments/environment */
      "./src/environments/environment.ts");
      /* harmony import */


      var _services_data_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ../../services/data.service */
      "./src/app/services/data.service.ts");
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @capacitor/core */
      "./node_modules/@capacitor/core/dist/esm/index.js");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @ngx-translate/core */
      "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");

      var _capacitor_core__WEBP = _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["Plugins"],
          Haptics = _capacitor_core__WEBP.Haptics,
          Http = _capacitor_core__WEBP.Http;

      var CreatePage = /*#__PURE__*/function () {
        function CreatePage(translate, dataService, alertController, storage, platform, nav, router, sanitizer, photo) {
          var _this = this;

          _classCallCheck(this, CreatePage);

          this.translate = translate;
          this.dataService = dataService;
          this.alertController = alertController;
          this.storage = storage;
          this.platform = platform;
          this.nav = nav;
          this.router = router;
          this.sanitizer = sanitizer;
          this.photo = photo;
          this.searchPilots = "";
          this.searchVehicles = "";
          this.step1 = true;
          this.step2 = false;
          this.step3 = false;
          this.errors = [];
          this.form = {
            name: '',
            address: "",
            price: "",
            order: "",
            pilot: "",
            vehicle: ""
          };
          this.title = 'Create A New Order';
          this.platform.backButton.subscribeWithPriority(10, function () {
            _this.back();
          });
          this.title = this.translate.instant('CREATE.title');
        }

        _createClass(CreatePage, [{
          key: "hapticsImpact",
          value: function hapticsImpact() {
            var style = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _capacitor_core__WEBPACK_IMPORTED_MODULE_11__["HapticsImpactStyle"].Heavy;

            // Native StatusBar available
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_11__["Capacitor"].getPlatform() != 'web') {
              Haptics.impact({
                style: style
              });
            }
          }
        }, {
          key: "hapticsImpactLight",
          value: function hapticsImpactLight() {
            this.hapticsImpact(_capacitor_core__WEBPACK_IMPORTED_MODULE_11__["HapticsImpactStyle"].Light);
          }
        }, {
          key: "filterPilots",
          value: function filterPilots() {
            this.pilots = this.dataService.filterPilots(this.searchPilots);
          }
        }, {
          key: "filterVehicles",
          value: function filterVehicles() {
            this.vehicles = this.dataService.filterVehicles(this.searchVehicles);
          }
        }, {
          key: "doRefresh",
          value: function doRefresh(event) {
            this.ngOnInit();
            setTimeout(function () {
              event.target.complete();
            }, 2000);
          }
        }, {
          key: "fetchPilots",
          value: function fetchPilots() {
            var _this2 = this;

            this.storage.get('USER_INFO').then(function (res) {
              var doGet = function doGet() {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                  var ret;
                  return regeneratorRuntime.wrap(function _callee$(_context) {
                    while (1) {
                      switch (_context.prev = _context.next) {
                        case 0:
                          _context.next = 2;
                          return Http.request({
                            method: 'GET',
                            url: "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_9__["SERVER_URL"], "/api/users"),
                            headers: {
                              'Accept': 'application/json',
                              'Content-Type': 'application/json',
                              'Authorization': 'Bearer ' + res.token
                            }
                          });

                        case 2:
                          ret = _context.sent;
                          return _context.abrupt("return", ret);

                        case 4:
                        case "end":
                          return _context.stop();
                      }
                    }
                  }, _callee);
                }));
              };

              doGet().then(function (res) {
                console.log(res);
                _this2.pilots = res['data'];
                _this2.dataService.pilots = _this2.pilots;

                _this2.filterPilots();
              });
            });
          }
        }, {
          key: "fetchVehicles",
          value: function fetchVehicles() {
            var _this3 = this;

            this.storage.get('USER_INFO').then(function (res) {
              console.log(res.token);

              var doGet = function doGet() {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this3, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                  var ret;
                  return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                      switch (_context2.prev = _context2.next) {
                        case 0:
                          _context2.next = 2;
                          return Http.request({
                            method: 'GET',
                            url: "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_9__["SERVER_URL"], "/api/vehicles"),
                            headers: {
                              'Accept': 'application/json',
                              'Content-Type': 'application/json',
                              'Authorization': 'Bearer ' + res.token
                            }
                          });

                        case 2:
                          ret = _context2.sent;
                          return _context2.abrupt("return", ret);

                        case 4:
                        case "end":
                          return _context2.stop();
                      }
                    }
                  }, _callee2);
                }));
              };

              doGet().then(function (res) {
                _this3.vehicles = res['data'];
                _this3.dataService.vehicles = _this3.vehicles;

                _this3.filterVehicles();
              });
            });
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {
            this.fetchPilots();
            this.fetchVehicles();
          }
        }, {
          key: "openCamera",
          value: function openCamera() {
            var _this4 = this;

            this.photo.takePicture().then(function (res) {
              _this4.image = _this4.sanitizer.bypassSecurityTrustUrl("data:image/png;base64," + res.url);
              _this4.file = res.upload;
              _this4.format = res.format;
            });
          }
        }, {
          key: "presentAlert",
          value: function presentAlert(msg) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var alert;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.alertController.create({
                        cssClass: 'my-custom-class',
                        header: 'Warning',
                        message: msg,
                        buttons: ['OK']
                      });

                    case 2:
                      alert = _context3.sent;
                      _context3.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "next",
          value: function next(e, type) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              var _this5 = this;

              var data;
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      this.hapticsImpactLight();

                      if (this.image) {
                        data = {
                          name: this.form.name,
                          phone: this.form.phone,
                          image: this.file,
                          format: this.format,
                          address: this.form.address,
                          price: this.form.price
                        };
                      } else {
                        data = {
                          name: this.form.name,
                          phone: this.form.phone,
                          order: this.form.order,
                          address: this.form.address,
                          price: this.form.price
                        };
                      }

                      if (type == 'proceed') {
                        e.target.innerHTML = '<ion-spinner></ion-spinner>';
                        e.target.setAttribute('disabled', 'disabled');
                        this.storage.get('USER_INFO').then(function (res) {
                          var doPost = function doPost() {
                            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this5, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                              var ret;
                              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                                while (1) {
                                  switch (_context4.prev = _context4.next) {
                                    case 0:
                                      _context4.next = 2;
                                      return Http.request({
                                        method: 'POST',
                                        url: "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_9__["SERVER_URL"], "/api/orders/proceed"),
                                        headers: {
                                          'Accept': 'application/json',
                                          'Content-Type': 'application/json',
                                          'Authorization': 'Bearer ' + res.token
                                        },
                                        data: data
                                      });

                                    case 2:
                                      ret = _context4.sent;
                                      return _context4.abrupt("return", ret);

                                    case 4:
                                    case "end":
                                      return _context4.stop();
                                  }
                                }
                              }, _callee4);
                            }));
                          };

                          doPost().then(function (res) {
                            e.target.innerHTML = 'Proceed';
                            e.target.removeAttribute('disabled');

                            if (res['status'] == 200) {
                              _this5.title = _this5.translate.instant('CREATE.PILOT.title');
                              _this5.step1 = false;
                              _this5.step2 = true;
                              _this5.step3 = false; // this.router.navigate(["/settings/vehicles"], navigationExtras);
                            } else if (res['status'] == 422) {
                              _this5.errors = res['data'].errors;
                            } // this.vehicles = res['data'];
                            //   this.loading = false;

                          });
                        });
                      }

                      if (this.step2 == true) {
                        if (this.form.pilot == "") {
                          this.presentAlert("Please Select A Pilot");
                        } else {
                          this.title = this.translate.instant('CREATE.VEHICLE.title');
                          this.step1 = false;
                          this.step2 = false;
                          this.step3 = true;
                        }
                      }

                    case 4:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this);
            }));
          }
        }, {
          key: "back",
          value: function back() {
            if (this.step3 == true) {
              this.title = this.translate.instant('CREATE.PILOT.title');
              this.step1 = false;
              this.step2 = true;
              this.step3 = false;
            } else if (this.step2 == true) {
              this.title = this.translate.instant('CREATE.title');
              this.step1 = true;
              this.step2 = false;
              this.step3 = false;
            } else if (this.step1 == true) {
              this.nav.back();
              this.step2 = false;
              this.step3 = false;
            }
          }
        }, {
          key: "send",
          value: function send(e) {
            var _this6 = this;

            this.hapticsImpactLight();
            e.target.innerHTML = '<ion-spinner></ion-spinner>';
            e.target.setAttribute('disabled', 'disabled');
            var data;

            if (this.image) {
              data = {
                name: this.form.name,
                phone: this.form.phone,
                image: this.file,
                format: this.format,
                address: this.form.address,
                price: this.form.price,
                pilot: this.form.pilot,
                vehicle: this.form.vehicle
              };
            } else {
              data = {
                name: this.form.name,
                phone: this.form.phone,
                order: this.form.order,
                address: this.form.address,
                price: this.form.price,
                pilot: this.form.pilot,
                vehicle: this.form.vehicle
              };
            }

            this.storage.get('USER_INFO').then(function (res) {
              var doPost = function doPost() {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this6, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                  var ret;
                  return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                      switch (_context6.prev = _context6.next) {
                        case 0:
                          _context6.next = 2;
                          return Http.request({
                            method: 'POST',
                            url: "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_9__["SERVER_URL"], "/api/orders"),
                            headers: {
                              'Accept': 'application/json',
                              'Content-Type': 'application/json',
                              'Authorization': 'Bearer ' + res.token
                            },
                            data: data
                          });

                        case 2:
                          ret = _context6.sent;
                          return _context6.abrupt("return", ret);

                        case 4:
                        case "end":
                          return _context6.stop();
                      }
                    }
                  }, _callee6);
                }));
              };

              doPost().then(function (res) {
                e.target.innerHTML = _this6.translate.instant('CREATE.VEHICLE.send');
                e.target.removeAttribute('disabled');

                if (res['status'] == 200) {
                  _this6.router.navigateByUrl('/orders/confirm', {
                    replaceUrl: true
                  }); // this.router.navigate(["/settings/vehicles"], navigationExtras);

                } else if (res['status'] == 422) {
                  _this6.errors = res['data'].errors;
                } // this.vehicles = res['data'];
                //   this.loading = false;

              });
            }); // this.router.navigateByUrl('/orders/confirm', { replaceUrl: true }) 
          }
        }]);

        return CreatePage;
      }();

      CreatePage.ctorParameters = function () {
        return [{
          type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_12__["TranslateService"]
        }, {
          type: _services_data_service__WEBPACK_IMPORTED_MODULE_10__["DataService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_8__["Storage"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]
        }, {
          type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"]
        }, {
          type: _services_photo_service__WEBPACK_IMPORTED_MODULE_3__["PhotoService"]
        }];
      };

      CreatePage.propDecorators = {
        backButton: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"],
          args: [_ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonBackButtonDelegate"], {
            "static": false
          }]
        }]
      };
      CreatePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-create',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./create.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/create/create.page.html"))["default"],
        animations: [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["trigger"])("enterAnimation", [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["transition"])(":enter", [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["style"])({
          transform: "translateX(10px)",
          opacity: 0
        }), Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["animate"])(".4s ease", Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["style"])({
          transform: "translateX(0px)",
          opacity: 1
        }))]), Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["transition"])(":leave", [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["style"])({
          transform: "translateX(0px)",
          opacity: 1
        }), Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["animate"])(".4s ease-out", Object(_angular_animations__WEBPACK_IMPORTED_MODULE_5__["style"])({
          transform: "translateX(10px)",
          opacity: 0
        }))])])],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./create.page.scss */
        "./src/app/orders/create/create.page.scss"))["default"]]
      })], CreatePage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=orders-create-create-module-es5.js.map