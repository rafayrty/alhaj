(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
    /*!***************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
      \***************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n    <ion-toolbar>\n      <ion-title>{{'HOME.title' | translate}}</ion-title>\n      <ion-buttons slot=\"end\">\n        <ion-button routerLink=\"/settings\">{{'settings' | translate}}</ion-button>\n      </ion-buttons>\n  \n    </ion-toolbar>\n  </ion-header>\n  \n\n\n<ion-content>\n    <div class=\"home\">\n\n    <ion-grid>\n\n    <ion-row class=\"ion-align-items-center ion-justify-content-center\" >\n        <ion-col size=\"12\">\n\n            <div class=\"orderButton\"   (click)=\"orderBTN($event,'orders/create')\" >\n<div class=\"orderButtonCard\">\n              <img src=\"/assets/images/new.svg\" alt=\"\">\n                    \n                    <ion-text>\n                        <h3 color=\"dark\"> {{'HOME.new' | translate}}</h3>\n                    </ion-text>\n                </div>\n\n            </div>\n       \n\n\n\n            </ion-col>\n        <ion-col>\n<div class=\"orderButton\" (click)=\"orderBTN($event,'orders/manage')\">\n    <div class=\"orderButtonCard\">\n\n        <img src=\"/assets/images/manage.svg\" alt=\"\">\n\n                \n        <ion-text>\n            <h3 color=\"dark\"> {{'HOME.manage' | translate}}</h3>\n        </ion-text>\n    </div>\n        \n</div>\n\n\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n</div>\n<div class=\"logoutbtn\">\n    <ion-button color=\"danger\" expand=\"block\" (click)=\"logOut()\"><ion-icon name=\"log-out-outline\"></ion-icon>{{'HOME.logout' | translate}}</ion-button>\n</div>\n\n\n</ion-content>\n\n";
      /***/
    },

    /***/
    "./src/app/home/home-routing.module.ts":
    /*!*********************************************!*\
      !*** ./src/app/home/home-routing.module.ts ***!
      \*********************************************/

    /*! exports provided: HomePageRoutingModule */

    /***/
    function srcAppHomeHomeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function () {
        return HomePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/home/home.page.ts");

      var routes = [{
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
      }];

      var HomePageRoutingModule = function HomePageRoutingModule() {
        _classCallCheck(this, HomePageRoutingModule);
      };

      HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], HomePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/home/home.module.ts":
    /*!*************************************!*\
      !*** ./src/app/home/home.module.ts ***!
      \*************************************/

    /*! exports provided: HomePageModule */

    /***/
    function srcAppHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
        return HomePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _home_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./home-routing.module */
      "./src/app/home/home-routing.module.ts");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/home/home.page.ts");
      /* harmony import */


      var _components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../components.module */
      "./src/app/components.module.ts");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @ngx-translate/core */
      "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js"); // add this


      var HomePageModule = function HomePageModule() {
        _classCallCheck(this, HomePageModule);
      };

      HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomePageRoutingModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"]],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
      })], HomePageModule);
      /***/
    },

    /***/
    "./src/app/home/home.page.scss":
    /*!*************************************!*\
      !*** ./src/app/home/home.page.scss ***!
      \*************************************/

    /*! exports provided: default */

    /***/
    function srcAppHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".home {\n  max-width: 65%;\n  margin: 0 auto;\n}\n.home ion-grid ion-col {\n  margin-top: 2rem;\n}\n.home .orderButton .orderButtonCard {\n  box-shadow: 0px 10px 20px rgba(29, 98, 240, 0.06);\n  border: 2px solid var(--ion-color-secondary-tint);\n  padding: 2rem 2rem 0.8rem 2rem;\n  border-radius: 20px;\n  text-align: center;\n}\n.home .orderButton .orderButtonCard img {\n  width: 220px;\n  height: 140px;\n  margin: 0 auto;\n}\n.logoutbtn {\n  max-width: 92%;\n  margin: 0 auto;\n  margin-top: 1.5rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGNBQUE7RUFDQSxjQUFBO0FBQ0o7QUFDUTtFQUNJLGdCQUFBO0FBQ1o7QUFJQTtFQUNJLGlEQUFBO0VBQ0EsaURBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBRUEsa0JBQUE7QUFISjtBQUlJO0VBRUksWUFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0FBSFI7QUFTQTtFQUNJLGNBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFOSiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuaG9tZXtcclxuICAgIG1heC13aWR0aDo2NSU7XHJcbiAgICBtYXJnaW46MCBhdXRvO1xyXG4gICAgaW9uLWdyaWR7XHJcbiAgICAgICAgaW9uLWNvbHtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDoycmVtO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5vcmRlckJ1dHRvbntcclxuICAgICAgICBcclxuLm9yZGVyQnV0dG9uQ2FyZHtcclxuICAgIGJveC1zaGFkb3c6IDBweCAxMHB4IDIwcHggcmdiYSgyOSwgOTgsIDI0MCwgMC4wNik7XHJcbiAgICBib3JkZXI6MnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnktdGludCk7XHJcbiAgICBwYWRkaW5nOjJyZW0gMnJlbSAuOHJlbSAycmVtO1xyXG4gICAgYm9yZGVyLXJhZGl1czoyMHB4O1xyXG4gXHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBpbWd7XHJcbiAgICAgICAgXHJcbiAgICAgICAgd2lkdGg6MjIwcHg7XHJcbiAgICAgICAgaGVpZ2h0OjE0MHB4O1xyXG4gICAgICAgIG1hcmdpbjowIGF1dG87XHJcbiAgICB9XHJcbn1cclxufVxyXG4gICAgXHJcbn1cclxuLmxvZ291dGJ0bntcclxuICAgIG1heC13aWR0aDo5MiU7XHJcbiAgICBtYXJnaW46MCBhdXRvO1xyXG4gICAgbWFyZ2luLXRvcDoxLjVyZW07XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "./src/app/home/home.page.ts":
    /*!***********************************!*\
      !*** ./src/app/home/home.page.ts ***!
      \***********************************/

    /*! exports provided: HomePage */

    /***/
    function srcAppHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePage", function () {
        return HomePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _services_storage_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../services/storage.service */
      "./src/app/services/storage.service.ts");
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @capacitor/core */
      "./node_modules/@capacitor/core/dist/esm/index.js");

      var Haptics = _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"].Haptics;

      var HomePage = /*#__PURE__*/function () {
        function HomePage(store, route, animationCtrl) {
          _classCallCheck(this, HomePage);

          this.store = store;
          this.route = route;
          this.animationCtrl = animationCtrl;
        }

        _createClass(HomePage, [{
          key: "hapticsImpact",
          value: function hapticsImpact() {
            var style = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["HapticsImpactStyle"].Heavy;

            // Native StatusBar available
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Capacitor"].getPlatform() != 'web') {
              Haptics.impact({
                style: style
              });
            }
          }
        }, {
          key: "hapticsImpactLight",
          value: function hapticsImpactLight() {
            this.hapticsImpact(_capacitor_core__WEBPACK_IMPORTED_MODULE_5__["HapticsImpactStyle"].Light);
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "logOut",
          value: function logOut() {
            this.store.logout(); //  this.route.navigateByUrl('/login');
          }
        }, {
          key: "orderBTN",
          value: function orderBTN(e, route) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              var animation;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      animation = this.animationCtrl.create().addElement(e.target).duration(300).keyframes([{
                        offset: 0,
                        transform: 'scale(1)'
                      }, {
                        offset: 0.5,
                        transform: 'scale(0.8)'
                      }, {
                        offset: 1,
                        transform: 'scale(1)'
                      }]);
                      this.hapticsImpactLight();
                      _context.next = 4;
                      return animation.play().then(function (e) {
                        _this.route.navigate([route]);
                      });

                    case 4:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }]);

        return HomePage;
      }();

      HomePage.ctorParameters = function () {
        return [{
          type: _services_storage_service__WEBPACK_IMPORTED_MODULE_4__["StorageService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AnimationController"]
        }];
      };

      HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./home.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./home.page.scss */
        "./src/app/home/home.page.scss"))["default"]]
      })], HomePage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=home-home-module-es5.js.map