export const environment = {
  production: true
};

// export const SERVER_URL = 'http://localost:8080';
