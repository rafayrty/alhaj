(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["orders-manage-manage-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/manage/manage.page.html":
/*!**************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/orders/manage/manage.page.html ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<app-menu title=\"{{'MANAGE.title' | translate}}\"></app-menu>\n<ion-content>\n\n  <div class=\"manage-page\">\n    <div class=\"searchBar\">\n      <ion-searchbar animated placeholder=\"Search\" [(ngModel)]=\"searchOrders\"\n      (ionChange)=\"filterOrders()\" name=\"searchOrders\"></ion-searchbar>\n\n    </div>\n\n\n    <div class=\"orders-list\">\n\n      <ion-list lines=\"none\">\n        <ion-item *ngFor=\"let order of orders; let i = index\">\n          <div class=\"order\">\n            <div class=\"status warning\" [ngClass]=\"{'medium': order.status === 'Pending', 'warning':order.status === 'Shipped', 'success':order.status === 'Delivered' }\"            >\n              <div class=\"status-text\">\n                <h3> {{'MANAGE.status' | translate}} <span>{{order.status}}</span></h3>\n              </div>\n              <div class=\"status-total\">\n                <h3>{{'MANAGE.total' | translate}}<span>$ {{order.price}}</span></h3>\n              </div>\n            </div>\n\n            <div class=\"client\">\n              <div class=\"details\">\n                <h2>{{'MANAGE.client' | translate}} <span>{{order.client}}</span></h2>\n                <p>{{'MANAGE.created' | translate}}{{date(order.created_at)}}</p>\n              </div>\n              <ion-button color=\"success\" (click)=\"call(order.phone)\">Call</ion-button>\n\n            </div>\n\n            <div class=\"assigned\">\n              <ion-text color=\"medium\">\n                <p>{{'MANAGE.assigned' | translate}}</p>\n              </ion-text>\n              <div class=\"pilot\">\n                <div class=\"left\">\n                  <ion-thumbnail slot=\"start\">\n                    <img src=\"{{order.user.image}}\">\n                  </ion-thumbnail>\n                  <p>{{order.user.name}}</p>\n                </div>\n\n                <div class=\"right\">\n                  <ion-button color=\"primary\" (click)=\"call(order.user.phone)\" fill=\"outline\">{{'call' | translate}}</ion-button>\n\n                </div>\n\n              </div>\n              <div class=\"vehicle\">\n                <ion-thumbnail slot=\"start\">\n                  <img src=\"{{order.vehicle.image}}\">\n                </ion-thumbnail>\n                <p>{{order.vehicle.name}}</p>\n              </div>\n\n            </div>\n\n\n          </div>\n\n        </ion-item>\n\n        <!-- <ion-item>\n          <div class=\"order\">\n            <div class=\"status success\">\n              <div class=\"status-text\">\n                <h3>Status: <span>Delivered</span></h3>\n              </div>\n              <div class=\"status-total\">\n                <h3>Total Bill: <span>$ 568</span></h3>\n              </div>\n            </div>\n\n            <div class=\"client\">\n              <div class=\"details\">\n                <h2>Client: <span>John Doe</span></h2>\n                <p>Created on: Oct. 20, 14:25</p>\n              </div>\n              <ion-button color=\"success\">Call</ion-button>\n\n            </div>\n\n            <div class=\"assigned\">\n              <ion-text color=\"medium\">\n                <p>Assigned to:</p>\n              </ion-text>\n              <div class=\"pilot\">\n                <div class=\"left\">\n                  <ion-thumbnail slot=\"start\">\n                    <img src=\"/assets/images/ricky.png\">\n                  </ion-thumbnail>\n                  <p>Ricky Mclaughlin</p>\n                </div>\n\n                <div class=\"right\">\n                  <ion-button color=\"primary\" fill=\"outline\">Call</ion-button>\n\n                </div>\n\n              </div>\n              <div class=\"vehicle\">\n                <ion-thumbnail slot=\"start\">\n                  <img src=\"/assets/images/ricky.png\">\n                </ion-thumbnail>\n                <p>Ricky Mclaughlin</p>\n              </div>\n\n            </div>\n\n\n          </div>\n\n        </ion-item>\n\n        <ion-item>\n          <div class=\"order\">\n            <div class=\"status medium\">\n              <div class=\"status-text\">\n                <h3>Status: <span>Delivered</span></h3>\n              </div>\n              <div class=\"status-total\">\n                <h3>Total Bill: <span>$ 568</span></h3>\n              </div>\n            </div>\n\n            <div class=\"client\">\n              <div class=\"details\">\n                <h2>Client: <span>John Doe</span></h2>\n                <p>Created on: Oct. 20, 14:25</p>\n              </div>\n              <ion-button color=\"success\">Call</ion-button>\n\n            </div>\n\n            <div class=\"assigned\">\n              <ion-text color=\"medium\">\n                <p>Assigned to:</p>\n              </ion-text>\n              <div class=\"pilot\">\n                <div class=\"left\">\n                  <ion-thumbnail slot=\"start\">\n                    <img src=\"/assets/images/ricky.png\">\n                  </ion-thumbnail>\n                  <p>Ricky Mclaughlin</p>\n                </div>\n\n                <div class=\"right\">\n                  <ion-button color=\"primary\" fill=\"outline\">Call</ion-button>\n\n                </div>\n\n              </div>\n              <div class=\"vehicle\">\n                <ion-thumbnail slot=\"start\">\n                  <img src=\"/assets/images/ricky.png\">\n                </ion-thumbnail>\n                <p>Ricky Mclaughlin</p>\n              </div>\n\n            </div>\n\n\n          </div>\n\n        </ion-item>\n       -->\n\n      </ion-list>\n\n    </div>\n\n\n  </div>\n\n</ion-content>\n");

/***/ }),

/***/ "./src/app/orders/manage/manage-routing.module.ts":
/*!********************************************************!*\
  !*** ./src/app/orders/manage/manage-routing.module.ts ***!
  \********************************************************/
/*! exports provided: ManagePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManagePageRoutingModule", function() { return ManagePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _manage_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./manage.page */ "./src/app/orders/manage/manage.page.ts");




const routes = [
    {
        path: '',
        component: _manage_page__WEBPACK_IMPORTED_MODULE_3__["ManagePage"]
    }
];
let ManagePageRoutingModule = class ManagePageRoutingModule {
};
ManagePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ManagePageRoutingModule);



/***/ }),

/***/ "./src/app/orders/manage/manage.module.ts":
/*!************************************************!*\
  !*** ./src/app/orders/manage/manage.module.ts ***!
  \************************************************/
/*! exports provided: ManagePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManagePageModule", function() { return ManagePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _manage_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./manage-routing.module */ "./src/app/orders/manage/manage-routing.module.ts");
/* harmony import */ var _manage_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./manage.page */ "./src/app/orders/manage/manage.page.ts");
/* harmony import */ var _components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../components.module */ "./src/app/components.module.ts");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");








 // add this
let ManagePageModule = class ManagePageModule {
};
ManagePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"],
            _manage_routing_module__WEBPACK_IMPORTED_MODULE_5__["ManagePageRoutingModule"],
            _components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"]
        ],
        declarations: [_manage_page__WEBPACK_IMPORTED_MODULE_6__["ManagePage"]]
    })
], ManagePageModule);



/***/ }),

/***/ "./src/app/orders/manage/manage.page.scss":
/*!************************************************!*\
  !*** ./src/app/orders/manage/manage.page.scss ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("* {\n  margin: 0;\n  padding: 0;\n}\n\nion-thumbnail img {\n  border-radius: 40px;\n}\n\n.searchBar {\n  max-width: 86%;\n  margin: 0 auto;\n  margin-top: 1rem;\n}\n\n.orders-list {\n  max-width: 86%;\n  margin: 0 auto;\n  margin-bottom: 2rem;\n}\n\n.orders-list ion-item:not(:first-child) {\n  margin-top: 1rem;\n}\n\n.orders-list ion-item {\n  --padding-start:0;\n  --inner-padding-end:0;\n}\n\n.orders-list ion-item .order {\n  margin-top: 1rem;\n  width: 100%;\n  border-radius: 10px;\n  border: 1px solid var(--ion-color-medium-shade);\n}\n\n.orders-list ion-item .order .status.warning {\n  background: var(--ion-color-warning);\n}\n\n.orders-list ion-item .order .status.success {\n  background: var(--ion-color-success);\n}\n\n.orders-list ion-item .order .status.medium {\n  background: var(--ion-color-medium);\n}\n\n.orders-list ion-item .order .status {\n  display: flex;\n  justify-content: space-between;\n  color: var(--ion-color-medium-contrast);\n  font-size: 0.875rem;\n  border-radius: 10px;\n  border: 1px solid var(--ion-color-medium-shade);\n  border-top: none;\n  padding: 0.1rem 1rem;\n}\n\n.orders-list ion-item .order .status h3 {\n  margin: 0;\n  font-size: 0.875rem;\n  font-weight: 400;\n}\n\n.orders-list ion-item .order .status h3 span {\n  font-weight: 700;\n}\n\n.orders-list ion-item .order .client {\n  margin-top: 0.5rem;\n  display: flex;\n  justify-content: space-between;\n  padding: 0.3rem 1rem;\n}\n\n.orders-list ion-item .order .client .details h2 {\n  color: var(--ion-color-primary);\n  font-size: 1.125rem;\n  font-weight: 400;\n}\n\n.orders-list ion-item .order .client .details h2 span {\n  font-weight: 600;\n}\n\n.orders-list ion-item .order .client .details p {\n  font-size: 0.625rem;\n  color: var(--ion-color-primary);\n}\n\n.orders-list ion-item .order .client ion-button {\n  --border-radius:20px;\n  --padding-start:1.2rem;\n  --padding-end:1.2rem;\n}\n\n.orders-list ion-item .order .assigned {\n  padding: 0.3rem 1rem;\n  margin-top: 1.2rem;\n}\n\n.orders-list ion-item .order .assigned ion-text p {\n  font-size: 0.625rem;\n}\n\n.orders-list ion-item .order .assigned .pilot {\n  display: flex;\n  justify-content: space-between;\n  margin-top: 0.5rem;\n  align-items: center;\n}\n\n.orders-list ion-item .order .assigned .pilot .left {\n  display: flex;\n  align-items: center;\n}\n\n.orders-list ion-item .order .assigned .pilot .left p {\n  margin-left: 0.75rem;\n  font-size: 0.875rem;\n}\n\n.orders-list ion-item .order .assigned .pilot ion-button {\n  --border-radius:20px;\n  --padding-start:1.2rem;\n  --padding-end:1.2rem;\n}\n\n.orders-list ion-item .order .assigned .vehicle {\n  margin-top: 0.5rem;\n  margin-bottom: 0.5rem;\n  display: flex;\n  align-items: center;\n}\n\n.orders-list ion-item .order .assigned .vehicle p {\n  margin-left: 0.75rem;\n  font-size: 0.875rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvb3JkZXJzL21hbmFnZS9tYW5hZ2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdFO0VBQ0ksU0FBQTtFQUNBLFVBQUE7QUFGTjs7QUFLTTtFQUNJLG1CQUFBO0FBRlY7O0FBS0E7RUFDSSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBRko7O0FBS0E7RUFDSSxjQUFBO0VBQ0EsY0FBQTtFQUNBLG1CQUFBO0FBRko7O0FBR0k7RUFDSSxnQkFBQTtBQURSOztBQUdBO0VBQ0ksaUJBQUE7RUFDQSxxQkFBQTtBQURKOztBQUdJO0VBQ0ksZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDUSwrQ0FBQTtBQURoQjs7QUFFQTtFQUNJLG9DQUFBO0FBQUo7O0FBR0E7RUFDSSxvQ0FBQTtBQURKOztBQUlBO0VBQ0ksbUNBQUE7QUFGSjs7QUFLUTtFQUNJLGFBQUE7RUFDQSw4QkFBQTtFQUNBLHVDQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLCtDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxvQkFBQTtBQUhaOztBQUlZO0VBQ0ksU0FBQTtFQUNBLG1CQUFBO0VBQ0MsZ0JBQUE7QUFGakI7O0FBR2lCO0VBQ0ksZ0JBQUE7QUFEckI7O0FBS1E7RUFDSSxrQkFBQTtFQUNBLGFBQUE7RUFDQSw4QkFBQTtFQUNBLG9CQUFBO0FBSFo7O0FBS2U7RUFDSSwrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFIbkI7O0FBSW1CO0VBQ0MsZ0JBQUE7QUFGcEI7O0FBS2U7RUFDSSxtQkFBQTtFQUNBLCtCQUFBO0FBSG5COztBQU1XO0VBQ0ksb0JBQUE7RUFDQSxzQkFBQTtFQUNBLG9CQUFBO0FBSmY7O0FBT1E7RUFDSSxvQkFBQTtFQUNBLGtCQUFBO0FBTFo7O0FBT2dCO0VBQ0ksbUJBQUE7QUFMcEI7O0FBU1k7RUFDSSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBUGhCOztBQVFnQjtFQUNJLGFBQUE7RUFDQSxtQkFBQTtBQU5wQjs7QUFPb0I7RUFDSSxvQkFBQTtFQUNBLG1CQUFBO0FBTHhCOztBQVNnQjtFQUNJLG9CQUFBO0VBQ0Esc0JBQUE7RUFDQSxvQkFBQTtBQVBwQjs7QUFXWTtFQUNJLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFUaEI7O0FBVWdCO0VBQ0ksb0JBQUE7RUFDQSxtQkFBQTtBQVJwQiIsImZpbGUiOiJzcmMvYXBwL29yZGVycy9tYW5hZ2UvbWFuYWdlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBmdW5jdGlvbiByZW0oJHNpemUpIHtcclxuICAgIEByZXR1cm4gJHNpemUgLyAxNnB4ICogMXJlbTtcclxuICB9XHJcbiAgKntcclxuICAgICAgbWFyZ2luOjA7XHJcbiAgICAgIHBhZGRpbmc6MDtcclxuICB9XHJcbiAgaW9uLXRodW1ibmFpbHtcclxuICAgICAgaW1ne1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czo0MHB4O1xyXG4gICAgICB9XHJcbiAgfVxyXG4uc2VhcmNoQmFye1xyXG4gICAgbWF4LXdpZHRoOjg2JTtcclxuICAgIG1hcmdpbjowIGF1dG87XHJcbiAgICBtYXJnaW4tdG9wOjFyZW07XHJcbn1cclxuXHJcbi5vcmRlcnMtbGlzdHtcclxuICAgIG1heC13aWR0aDo4NiU7XHJcbiAgICBtYXJnaW46MCBhdXRvO1xyXG4gICAgbWFyZ2luLWJvdHRvbToycmVtO1xyXG4gICAgaW9uLWl0ZW06bm90KDpmaXJzdC1jaGlsZCl7XHJcbiAgICAgICAgbWFyZ2luLXRvcDoxcmVtO1xyXG4gICAgfVxyXG5pb24taXRlbXtcclxuICAgIC0tcGFkZGluZy1zdGFydDowO1xyXG4gICAgLS1pbm5lci1wYWRkaW5nLWVuZDowO1xyXG5cclxuICAgIC5vcmRlcntcclxuICAgICAgICBtYXJnaW4tdG9wOjFyZW07XHJcbiAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOjFweCBzb2xpZCB2YXIoIC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XHJcbi5zdGF0dXMud2FybmluZ3tcclxuICAgIGJhY2tncm91bmQ6dmFyKC0taW9uLWNvbG9yLXdhcm5pbmcpO1xyXG5cclxufVxyXG4uc3RhdHVzLnN1Y2Nlc3N7XHJcbiAgICBiYWNrZ3JvdW5kOnZhcigtLWlvbi1jb2xvci1zdWNjZXNzKTtcclxuXHJcbn1cclxuLnN0YXR1cy5tZWRpdW17XHJcbiAgICBiYWNrZ3JvdW5kOnZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG5cclxufVxyXG4gICAgICAgIC5zdGF0dXN7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ZmxleDtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICBjb2xvcjp2YXIoLS1pb24tY29sb3ItbWVkaXVtLWNvbnRyYXN0KTtcclxuICAgICAgICAgICAgZm9udC1zaXplOnJlbSgxNHB4KTtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgICAgICAgYm9yZGVyOjFweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXNoYWRlKTtcclxuICAgICAgICAgICAgYm9yZGVyLXRvcDpub25lO1xyXG4gICAgICAgICAgICBwYWRkaW5nOi4xcmVtIDFyZW07XHJcbiAgICAgICAgICAgIGgze1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOjA7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6cmVtKDE0cHgpO1xyXG4gICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OjQwMDtcclxuICAgICAgICAgICAgICAgICBzcGFue1xyXG4gICAgICAgICAgICAgICAgICAgICBmb250LXdlaWdodDo3MDA7XHJcbiAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5jbGllbnR7XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6LjVyZW07XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ZmxleDtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgICAgICBwYWRkaW5nOi4zcmVtIDFyZW07XHJcbiAgICAgICAgICAgLmRldGFpbHN7XHJcbiAgICAgICAgICAgICAgIGgye1xyXG4gICAgICAgICAgICAgICAgICAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICAgICAgICAgICAgICAgZm9udC1zaXplOnJlbSgxOHB4KTtcclxuICAgICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OjQwMDtcclxuICAgICAgICAgICAgICAgICAgIHNwYW57XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6NjAwO1xyXG4gICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgIHB7XHJcbiAgICAgICAgICAgICAgICAgICBmb250LXNpemU6cmVtKDEwcHgpO1xyXG4gICAgICAgICAgICAgICAgICAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgfVxyXG4gICAgICAgICAgIGlvbi1idXR0b257XHJcbiAgICAgICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czoyMHB4O1xyXG4gICAgICAgICAgICAgICAtLXBhZGRpbmctc3RhcnQ6MS4ycmVtO1xyXG4gICAgICAgICAgICAgICAtLXBhZGRpbmctZW5kOjEuMnJlbTtcclxuICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5hc3NpZ25lZHtcclxuICAgICAgICAgICAgcGFkZGluZzouM3JlbSAxcmVtO1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOjEuMnJlbTtcclxuICAgICAgICAgICAgaW9uLXRleHR7XHJcbiAgICAgICAgICAgICAgICBwe1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTpyZW0oMTBweCk7XHJcblxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC5waWxvdHtcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk6ZmxleDtcclxuICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi10b3A6LjVyZW07XHJcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgLmxlZnR7XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTpmbGV4O1xyXG4gICAgICAgICAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgcHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luLWxlZnQ6Ljc1cmVtO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6cmVtKDE0cHgpO1xyXG5cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgICAgICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czoyMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIC0tcGFkZGluZy1zdGFydDoxLjJyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgLS1wYWRkaW5nLWVuZDoxLjJyZW07XHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIC52ZWhpY2xle1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDouNXJlbTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbi1ib3R0b206LjVyZW07XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5OmZsZXg7XHJcbiAgICAgICAgICAgICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgcHtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tbGVmdDouNzVyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udC1zaXplOnJlbSgxNHB4KTtcclxuXHJcbiAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgXHJcbiAgICB9XHJcbn1cclxuIl19 */");

/***/ }),

/***/ "./src/app/orders/manage/manage.page.ts":
/*!**********************************************!*\
  !*** ./src/app/orders/manage/manage.page.ts ***!
  \**********************************************/
/*! exports provided: ManagePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ManagePage", function() { return ManagePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _services_data_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../services/data.service */ "./src/app/services/data.service.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _capacitor_community_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @capacitor-community/http */ "./node_modules/@capacitor-community/http/dist/esm/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_call_number_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/call-number/ngx */ "./node_modules/@ionic-native/call-number/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");










const { Haptics, Http } = _capacitor_core__WEBPACK_IMPORTED_MODULE_9__["Plugins"];
let ManagePage = class ManagePage {
    constructor(translate, callNumber, loadingController, dataService, storage) {
        this.translate = translate;
        this.callNumber = callNumber;
        this.loadingController = loadingController;
        this.dataService = dataService;
        this.storage = storage;
        this.searchOrders = "";
    }
    hapticsImpact(style = _capacitor_core__WEBPACK_IMPORTED_MODULE_9__["HapticsImpactStyle"].Heavy) {
        // Native StatusBar available
        if (_capacitor_core__WEBPACK_IMPORTED_MODULE_9__["Capacitor"].getPlatform() != 'web') {
            Haptics.impact({
                style: style
            });
        }
    }
    hapticsImpactLight() {
        this.hapticsImpact(_capacitor_core__WEBPACK_IMPORTED_MODULE_9__["HapticsImpactStyle"].Light);
    }
    hapticsImpactHeavy() {
        this.hapticsImpact(_capacitor_core__WEBPACK_IMPORTED_MODULE_9__["HapticsImpactStyle"].Heavy);
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.fetchOrders();
    }
    call(num) {
        this.hapticsImpactHeavy();
        // let tel_number = num;
        // window.open(`tel:${tel_number}`, '_system')
        this.callNumber.callNumber(num, true)
            .then(res => console.log('Launched dialer!', res))
            .catch(err => console.log('Error launching dialer', err));
    }
    presentLoading() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.loader = yield this.loadingController.create({
                cssClass: 'my-custom-class',
                message: this.translate.instant('wait'),
            });
            yield this.loader.present();
            const { role, data } = yield this.loader.onDidDismiss();
            console.log('Loading dismissed!');
        });
    }
    hideLoader() {
        if (this.loader != null) {
            this.loader.dismiss();
            this.loader = null;
        }
    }
    fetchOrders() {
        this.presentLoading();
        this.storage.get('USER_INFO').then(res => {
            const doGet = () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                const ret = yield Http.request({
                    method: 'GET',
                    url: `${_environments_environment__WEBPACK_IMPORTED_MODULE_3__["SERVER_URL"]}/api/orders`,
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res.token
                    }
                });
                return ret;
            });
            doGet().then(res => {
                this.hideLoader();
                this.orders = res['data'];
                // console.log(this.orders);
                this.dataService.orders = this.orders;
                this.filterOrders();
            });
        });
    }
    filterOrders() {
        this.orders = this.dataService.filterOrders(this.searchOrders);
    }
    date(date) {
        let dateOutput = new Date(date).toLocaleDateString('en-gb', {
            month: 'short',
            day: 'numeric',
            hour: 'numeric',
            minute: 'numeric'
        });
        return dateOutput;
    }
};
ManagePage.ctorParameters = () => [
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateService"] },
    { type: _ionic_native_call_number_ngx__WEBPACK_IMPORTED_MODULE_6__["CallNumber"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _services_data_service__WEBPACK_IMPORTED_MODULE_2__["DataService"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_7__["Storage"] }
];
ManagePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-manage',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./manage.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/manage/manage.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./manage.page.scss */ "./src/app/orders/manage/manage.page.scss")).default]
    })
], ManagePage);



/***/ })

}]);
//# sourceMappingURL=orders-manage-manage-module-es2015.js.map