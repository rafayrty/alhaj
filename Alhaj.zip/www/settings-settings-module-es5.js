(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["settings-settings-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/settings.page.html":
    /*!***********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/settings/settings.page.html ***!
      \***********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppSettingsSettingsPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{'SETTINGS.title' | translate}}</ion-title>\n    <!-- <ion-buttons slot=\"end\">\n      <ion-button (click)=\"settings()\">Settings</ion-button>\n    </ion-buttons> -->\n\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n\n  <div class=\"settings\">\n    <ion-segment dir=\"ltr\" style=\"    margin-top: 2rem;\" (ionChange)=\"changeLang()\" [(ngModel)]=\"selectedLang\">\n      <ion-segment-button value=\"en\">\n        <ion-label>EN</ion-label>\n      </ion-segment-button>\n      <ion-segment-button value=\"ar\">\n        <ion-label>AR</ion-label>\n      </ion-segment-button>\n    </ion-segment>\n    <ion-grid>\n\n    <ion-row class=\"ion-align-items-center ion-justify-content-center\" >\n        <ion-col size=\"12\">\n\n            <div class=\"orderButton\" (click)=\"settingsBTN($event,'settings/pilots')\" >\n<div class=\"orderButtonCard\">\n              <img src=\"/assets/images/pilots.svg\" alt=\"\">\n                    \n                    <ion-text>\n                        <h3 color=\"dark\"> {{'SETTINGS.pilots' | translate}}</h3>\n                    </ion-text>\n                </div>\n\n            </div>\n       \n\n\n\n            </ion-col>\n        <ion-col>\n<div class=\"orderButton\" (click)=\"settingsBTN($event,'settings/vehicles')\">\n    <div class=\"orderButtonCard\">\n\n        <img src=\"/assets/images/vehicles.svg\" alt=\"\">\n\n                \n        <ion-text>\n            <h3 color=\"dark\"> {{'SETTINGS.vehicles' | translate}}</h3>\n        </ion-text>\n    </div>\n        \n</div>\n\n\n        </ion-col>\n      </ion-row>\n    </ion-grid>\n\n</div>\n\n</ion-content>\n\n";
      /***/
    },

    /***/
    "./src/app/settings/settings-routing.module.ts":
    /*!*****************************************************!*\
      !*** ./src/app/settings/settings-routing.module.ts ***!
      \*****************************************************/

    /*! exports provided: SettingsPageRoutingModule */

    /***/
    function srcAppSettingsSettingsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SettingsPageRoutingModule", function () {
        return SettingsPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _settings_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./settings.page */
      "./src/app/settings/settings.page.ts");

      var routes = [{
        path: '',
        component: _settings_page__WEBPACK_IMPORTED_MODULE_3__["SettingsPage"]
      }, {
        path: 'pilots',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | pilots-pilots-module */
          "pilots-pilots-module").then(__webpack_require__.bind(null,
          /*! ./pilots/pilots.module */
          "./src/app/settings/pilots/pilots.module.ts")).then(function (m) {
            return m.PilotsPageModule;
          });
        }
      }, {
        path: 'vehicles',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | vehicles-vehicles-module */
          "vehicles-vehicles-module").then(__webpack_require__.bind(null,
          /*! ./vehicles/vehicles.module */
          "./src/app/settings/vehicles/vehicles.module.ts")).then(function (m) {
            return m.VehiclesPageModule;
          });
        }
      }];

      var SettingsPageRoutingModule = function SettingsPageRoutingModule() {
        _classCallCheck(this, SettingsPageRoutingModule);
      };

      SettingsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], SettingsPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/settings/settings.module.ts":
    /*!*********************************************!*\
      !*** ./src/app/settings/settings.module.ts ***!
      \*********************************************/

    /*! exports provided: SettingsPageModule */

    /***/
    function srcAppSettingsSettingsModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SettingsPageModule", function () {
        return SettingsPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _settings_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./settings-routing.module */
      "./src/app/settings/settings-routing.module.ts");
      /* harmony import */


      var _settings_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./settings.page */
      "./src/app/settings/settings.page.ts");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ngx-translate/core */
      "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js"); // add this


      var SettingsPageModule = function SettingsPageModule() {
        _classCallCheck(this, SettingsPageModule);
      };

      SettingsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"], _settings_routing_module__WEBPACK_IMPORTED_MODULE_5__["SettingsPageRoutingModule"]],
        declarations: [_settings_page__WEBPACK_IMPORTED_MODULE_6__["SettingsPage"]]
      })], SettingsPageModule);
      /***/
    },

    /***/
    "./src/app/settings/settings.page.scss":
    /*!*********************************************!*\
      !*** ./src/app/settings/settings.page.scss ***!
      \*********************************************/

    /*! exports provided: default */

    /***/
    function srcAppSettingsSettingsPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".settings {\n  max-width: 65%;\n  margin: 0 auto;\n}\n.settings ion-grid ion-col {\n  margin-top: 2rem;\n}\n.settings .orderButton .orderButtonCard {\n  box-shadow: 0px 10px 20px rgba(29, 98, 240, 0.06);\n  border: 2px solid var(--ion-color-secondary-tint);\n  padding: 2rem 2rem 0.8rem 2rem;\n  border-radius: 20px;\n  text-align: center;\n}\n.settings .orderButton .orderButtonCard img {\n  width: 220px;\n  height: 140px;\n  margin: 0 auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2V0dGluZ3Mvc2V0dGluZ3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtFQUNBLGNBQUE7QUFDSjtBQUNRO0VBQ0ksZ0JBQUE7QUFDWjtBQUlBO0VBQ0ksaURBQUE7RUFDQSxpREFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFFQSxrQkFBQTtBQUhKO0FBSUk7RUFFSSxZQUFBO0VBQ0EsYUFBQTtFQUNBLGNBQUE7QUFIUiIsImZpbGUiOiJzcmMvYXBwL3NldHRpbmdzL3NldHRpbmdzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zZXR0aW5nc3tcclxuICAgIG1heC13aWR0aDo2NSU7XHJcbiAgICBtYXJnaW46MCBhdXRvO1xyXG4gICAgaW9uLWdyaWR7XHJcbiAgICAgICAgaW9uLWNvbHtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDoycmVtO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5vcmRlckJ1dHRvbntcclxuICAgICAgICBcclxuLm9yZGVyQnV0dG9uQ2FyZHtcclxuICAgIGJveC1zaGFkb3c6IDBweCAxMHB4IDIwcHggcmdiYSgyOSwgOTgsIDI0MCwgMC4wNik7XHJcbiAgICBib3JkZXI6MnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zZWNvbmRhcnktdGludCk7XHJcbiAgICBwYWRkaW5nOjJyZW0gMnJlbSAuOHJlbSAycmVtO1xyXG4gICAgYm9yZGVyLXJhZGl1czoyMHB4O1xyXG4gXHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBpbWd7XHJcbiAgICAgICAgXHJcbiAgICAgICAgd2lkdGg6MjIwcHg7XHJcbiAgICAgICAgaGVpZ2h0OjE0MHB4O1xyXG4gICAgICAgIG1hcmdpbjowIGF1dG87XHJcbiAgICB9XHJcbn1cclxufVxyXG5cclxuICAgIFxyXG59XHJcbiJdfQ== */";
      /***/
    },

    /***/
    "./src/app/settings/settings.page.ts":
    /*!*******************************************!*\
      !*** ./src/app/settings/settings.page.ts ***!
      \*******************************************/

    /*! exports provided: SettingsPage */

    /***/
    function srcAppSettingsSettingsPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SettingsPage", function () {
        return SettingsPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _services_language_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../services/language.service */
      "./src/app/services/language.service.ts");
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @capacitor/core */
      "./node_modules/@capacitor/core/dist/esm/index.js");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ngx-translate/core */
      "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");

      var Haptics = _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Plugins"].Haptics;

      var SettingsPage = /*#__PURE__*/function () {
        function SettingsPage(translate, languageService, route, animationCtrl) {
          _classCallCheck(this, SettingsPage);

          this.translate = translate;
          this.languageService = languageService;
          this.route = route;
          this.animationCtrl = animationCtrl;
          this.selectedLang = localStorage.getItem('SELECTED_LANGUAGE');
        }

        _createClass(SettingsPage, [{
          key: "hapticsImpact",
          value: function hapticsImpact() {
            var style = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _capacitor_core__WEBPACK_IMPORTED_MODULE_5__["HapticsImpactStyle"].Heavy;

            // Native StatusBar available
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_5__["Capacitor"].getPlatform() != 'web') {
              Haptics.impact({
                style: style
              });
            }
          }
        }, {
          key: "hapticsImpactLight",
          value: function hapticsImpactLight() {
            this.hapticsImpact(_capacitor_core__WEBPACK_IMPORTED_MODULE_5__["HapticsImpactStyle"].Light);
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "changeLang",
          value: function changeLang() {
            this.hapticsImpactLight();
            this.languageService.setLanguage(this.selectedLang); // window.location.reload();
          }
        }, {
          key: "settingsBTN",
          value: function settingsBTN(e, route) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              var animation;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      animation = this.animationCtrl.create().addElement(e.target).duration(300).keyframes([{
                        offset: 0,
                        transform: 'scale(1)'
                      }, {
                        offset: 0.5,
                        transform: 'scale(0.8)'
                      }, {
                        offset: 1,
                        transform: 'scale(1)'
                      }]);
                      this.hapticsImpactLight();
                      _context.next = 4;
                      return animation.play().then(function (e) {
                        _this.route.navigate([route]);
                      });

                    case 4:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }]);

        return SettingsPage;
      }();

      SettingsPage.ctorParameters = function () {
        return [{
          type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_6__["TranslateService"]
        }, {
          type: _services_language_service__WEBPACK_IMPORTED_MODULE_4__["LanguageService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AnimationController"]
        }];
      };

      SettingsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-settings',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./settings.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/settings.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./settings.page.scss */
        "./src/app/settings/settings.page.scss"))["default"]]
      })], SettingsPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=settings-settings-module-es5.js.map