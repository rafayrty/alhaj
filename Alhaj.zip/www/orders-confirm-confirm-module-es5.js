(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["orders-confirm-confirm-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/confirm/confirm.page.html":
    /*!****************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/orders/confirm/confirm.page.html ***!
      \****************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppOrdersConfirmConfirmPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<app-menu title=\"{{ 'CONFIRM.title' | translate}}\" ></app-menu>\n<ion-content>\n<div class=\"confirm\">\n\n<ion-text class=\"done\">\n  <h6>{{ 'CONFIRM.done' | translate}}</h6>\n</ion-text>\n<ion-text class=\"sent\">\n  <h1>{{ 'CONFIRM.sent' | translate}}</h1>\n</ion-text>\n<ion-text class=\"notified\">\n  <p>{{ 'CONFIRM.notify' | translate}}</p>\n</ion-text>\n<div class=\"new\">\n  <ion-button color=\"light\" expand=\"block\" routerLink=\"/orders/create\">{{ 'CONFIRM.new' | translate}}</ion-button>\n</div>\n\n</div>\n\n\n\n\n\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/orders/confirm/confirm-routing.module.ts":
    /*!**********************************************************!*\
      !*** ./src/app/orders/confirm/confirm-routing.module.ts ***!
      \**********************************************************/

    /*! exports provided: ConfirmPageRoutingModule */

    /***/
    function srcAppOrdersConfirmConfirmRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ConfirmPageRoutingModule", function () {
        return ConfirmPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _confirm_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./confirm.page */
      "./src/app/orders/confirm/confirm.page.ts");

      var routes = [{
        path: '',
        component: _confirm_page__WEBPACK_IMPORTED_MODULE_3__["ConfirmPage"]
      }];

      var ConfirmPageRoutingModule = function ConfirmPageRoutingModule() {
        _classCallCheck(this, ConfirmPageRoutingModule);
      };

      ConfirmPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ConfirmPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/orders/confirm/confirm.module.ts":
    /*!**************************************************!*\
      !*** ./src/app/orders/confirm/confirm.module.ts ***!
      \**************************************************/

    /*! exports provided: ConfirmPageModule */

    /***/
    function srcAppOrdersConfirmConfirmModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ConfirmPageModule", function () {
        return ConfirmPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _confirm_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./confirm-routing.module */
      "./src/app/orders/confirm/confirm-routing.module.ts");
      /* harmony import */


      var _confirm_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./confirm.page */
      "./src/app/orders/confirm/confirm.page.ts");
      /* harmony import */


      var _components_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../components.module */
      "./src/app/components.module.ts");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @ngx-translate/core */
      "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js"); // add this


      var ConfirmPageModule = function ConfirmPageModule() {
        _classCallCheck(this, ConfirmPageModule);
      };

      ConfirmPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _components_module__WEBPACK_IMPORTED_MODULE_7__["ComponentsModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"], _confirm_routing_module__WEBPACK_IMPORTED_MODULE_5__["ConfirmPageRoutingModule"]],
        declarations: [_confirm_page__WEBPACK_IMPORTED_MODULE_6__["ConfirmPage"]]
      })], ConfirmPageModule);
      /***/
    },

    /***/
    "./src/app/orders/confirm/confirm.page.scss":
    /*!**************************************************!*\
      !*** ./src/app/orders/confirm/confirm.page.scss ***!
      \**************************************************/

    /*! exports provided: default */

    /***/
    function srcAppOrdersConfirmConfirmPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content {\n  position: relative;\n}\n\n.confirm {\n  max-width: 88%;\n  width: 100%;\n  text-align: center;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -62%);\n}\n\n.confirm .done h6 {\n  text-transform: capitalize;\n  color: var(--ion-color-medium);\n  margin-bottom: 0;\n  padding-bottom: 0;\n}\n\n.confirm .sent h1 {\n  text-transform: capitalize;\n  font-size: 2.125rem;\n  font-weight: 700;\n  margin-top: 0.5rem;\n}\n\n.confirm .new {\n  margin-top: 4.5rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvb3JkZXJzL2NvbmZpcm0vY29uZmlybS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0E7RUFDSSxrQkFBQTtBQUZKOztBQUlBO0VBQ0ksY0FBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtBQURKOztBQUlTO0VBQ0ksMEJBQUE7RUFDQSw4QkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFGYjs7QUFNUTtFQUNJLDBCQUFBO0VBQ0EsbUJBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FBSlo7O0FBT0k7RUFDSSxrQkFBQTtBQUxSIiwiZmlsZSI6InNyYy9hcHAvb3JkZXJzL2NvbmZpcm0vY29uZmlybS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAZnVuY3Rpb24gcmVtKCRzaXplKSB7XHJcbiAgICBAcmV0dXJuICRzaXplIC8gMTZweCAqIDFyZW07XHJcbiAgfVxyXG5pb24tY29udGVudHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG4uY29uZmlybXtcclxuICAgIG1heC13aWR0aDo4OCU7XHJcbiAgICB3aWR0aDoxMDAlO1xyXG4gICAgdGV4dC1hbGlnbjpjZW50ZXI7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IDUwJTtcclxuICAgIGxlZnQ6IDUwJTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC02MiUpO1xyXG5cclxuICAgICAuZG9uZXtcclxuICAgICAgICAgaDZ7XHJcbiAgICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcclxuICAgICAgICAgICAgIGNvbG9yOnZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgICAgICAgICAgbWFyZ2luLWJvdHRvbTowO1xyXG4gICAgICAgICAgICAgcGFkZGluZy1ib3R0b206MDtcclxuICAgICAgICAgfVxyXG4gICAgIH1cclxuICAgIC5zZW50e1xyXG4gICAgICAgIGgxe1xyXG4gICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogY2FwaXRhbGl6ZTtcclxuICAgICAgICAgICAgZm9udC1zaXplOnJlbSgzNHB4KTtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6NzAwO1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOi41cmVtO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5uZXd7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogNC41cmVtO1xyXG4gICAgICAgIH1cclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/orders/confirm/confirm.page.ts":
    /*!************************************************!*\
      !*** ./src/app/orders/confirm/confirm.page.ts ***!
      \************************************************/

    /*! exports provided: ConfirmPage */

    /***/
    function srcAppOrdersConfirmConfirmPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ConfirmPage", function () {
        return ConfirmPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var ConfirmPage = /*#__PURE__*/function () {
        function ConfirmPage() {
          _classCallCheck(this, ConfirmPage);
        }

        _createClass(ConfirmPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return ConfirmPage;
      }();

      ConfirmPage.ctorParameters = function () {
        return [];
      };

      ConfirmPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-confirm',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./confirm.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/confirm/confirm.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./confirm.page.scss */
        "./src/app/orders/confirm/confirm.page.scss"))["default"]]
      })], ConfirmPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=orders-confirm-confirm-module-es5.js.map