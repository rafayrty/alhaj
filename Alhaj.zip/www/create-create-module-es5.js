(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["create-create-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/pilots/create/create.page.html":
    /*!***********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/settings/pilots/create/create.page.html ***!
      \***********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppSettingsPilotsCreateCreatePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{'SETTINGS.PILOTS.new' | translate}}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"insert()\">{{'done' | translate}}</ion-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<div class=\"create\">\n<ion-text color=\"medium\">\n  <h6>{{'SETTINGS.PILOTS.INPUTS.photo' | translate}}</h6>\n</ion-text>\n<div class=\"photo\">\n<div class=\"image\" *ngIf=\"!image\" (click)=\"openCamera()\">\n\n\n  <svg width=\"160\" height=\"160\" viewBox=\"0 0 160 160\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n    <rect width=\"160\" height=\"160\" rx=\"80\" fill=\"#F2F2F2\"/>\n    <path d=\"M68.2757 93H91.7243C94.5702 93 96 91.5821 96 88.7735V74.4987C96 71.6901 94.5702 70.2858 91.7243 70.2858H88.5515C87.4894 70.2858 87.1489 70.0676 86.5498 69.3859L85.4468 68.1589C84.766 67.409 84.0715 67 82.6689 67H77.2357C75.8332 67 75.1387 67.409 74.4579 68.1589L73.3685 69.3859C72.7694 70.054 72.4289 70.2858 71.3668 70.2858H68.2757C65.4298 70.2858 64 71.6901 64 74.4987V88.7735C64 91.5821 65.4298 93 68.2757 93ZM80 88.6371C75.8877 88.6371 72.5787 85.3241 72.5787 81.1793C72.5787 77.0346 75.8877 73.7216 80 73.7216C84.126 73.7216 87.4349 77.0346 87.4349 81.1793C87.4349 85.3241 84.126 88.6371 80 88.6371ZM89.7906 77.8526C88.8647 77.8526 88.1021 77.1028 88.1021 76.1757C88.1021 75.2349 88.8647 74.4851 89.7906 74.4851C90.7166 74.4851 91.4791 75.2349 91.4791 76.1757C91.4791 77.1028 90.7166 77.8526 89.7906 77.8526ZM80 86.5648C82.9685 86.5648 85.3787 84.1652 85.3787 81.1793C85.3787 78.1935 82.9685 75.7939 80 75.7939C77.0315 75.7939 74.6349 78.1935 74.6349 81.1793C74.6349 84.1652 77.0451 86.5648 80 86.5648Z\" fill=\"#BDBDBD\"/>\n    </svg>\n    \n\n</div>\n<div class=\"image\" style=\"text-align: center;\" *ngIf=\"image\" >\n<img style=\"width:160px;display:inline-block;height:160px;object-fit: cover;border-radius: 100px;\" [src]=\"image\">\n\n</div>\n</div>\n\n<div class=\"buttons\">\n<ion-button color=\"primary\" expand=\"block\" (click)=\"openCamera()\" fill=\"solid\">{{'SETTINGS.PILOTS.INPUTS.upload' | translate}}</ion-button>\n<!-- <ion-button color=\"danger\" expand=\"block\"  fill=\"outline\">Delete Photo</ion-button> -->\n\n</div>\n\n\n\n  \n</div>\n<div class=\"form\">\n  <ion-item lines=\"none\">\n    <ion-label color=\"medium\"  position=\"stacked\">{{'SETTINGS.PILOTS.INPUTS.name' | translate}}</ion-label>\n    <ion-input placeholder=\"{{'SETTINGS.PILOTS.INPUTS.name_placeholder' | translate}}\" autofocus=\"true\" [(ngModel)]=\"name\" name=\"name\"></ion-input>\n    <span class=\"error\" *ngIf=\"errors.length!=0 && errors.name\">{{errors.name[0]}}</span>\n\n  </ion-item>\n  <ion-item lines=\"none\">\n    <ion-label color=\"medium\"  position=\"stacked\">{{'SETTINGS.PILOTS.INPUTS.phone' | translate}}</ion-label>\n    <ion-input placeholder=\"{{'SETTINGS.PILOTS.INPUTS.phone_placeholder' | translate}}\" [(ngModel)]=\"phone\" name=\"phone\"></ion-input>\n    <span class=\"error\" *ngIf=\"errors.length!=0 && errors.phone\">{{errors.phone[0]}}</span>\n\n  </ion-item>\n  <ion-item lines=\"none\">\n    <ion-label color=\"medium\" position=\"stacked\">{{'SETTINGS.PILOTS.INPUTS.loginId' | translate}}</ion-label>\n    <ion-input placeholder=\"{{'SETTINGS.PILOTS.INPUTS.loginId_placeholder' | translate}}\"   [(ngModel)]=\"loginId\" name=\"loginId\"></ion-input>\n    <span class=\"error\" *ngIf=\"errors.length!=0 && errors.login_id\">{{errors.login_id[0]}}</span>\n\n  </ion-item>\n \n\n\n\n\n</div>\n\n\n</ion-content>\n";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/vehicles/create/create.page.html":
    /*!*************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/settings/vehicles/create/create.page.html ***!
      \*************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppSettingsVehiclesCreateCreatePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{'SETTINGS.VEHICLES.new' | translate}}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"insert()\">{{'done' | translate}}</ion-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<div class=\"create\">\n<ion-text color=\"medium\">\n  <h6>{{'SETTINGS.VEHICLES.INPUTS.photo' | translate}}</h6>\n</ion-text>\n<div class=\"photo\">\n<div class=\"image\" *ngIf=\"!image\" (click)=\"openCamera()\">\n\n\n  <svg width=\"160\" height=\"160\" viewBox=\"0 0 160 160\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n    <rect width=\"160\" height=\"160\" rx=\"80\" fill=\"#F2F2F2\"/>\n    <path d=\"M68.2757 93H91.7243C94.5702 93 96 91.5821 96 88.7735V74.4987C96 71.6901 94.5702 70.2858 91.7243 70.2858H88.5515C87.4894 70.2858 87.1489 70.0676 86.5498 69.3859L85.4468 68.1589C84.766 67.409 84.0715 67 82.6689 67H77.2357C75.8332 67 75.1387 67.409 74.4579 68.1589L73.3685 69.3859C72.7694 70.054 72.4289 70.2858 71.3668 70.2858H68.2757C65.4298 70.2858 64 71.6901 64 74.4987V88.7735C64 91.5821 65.4298 93 68.2757 93ZM80 88.6371C75.8877 88.6371 72.5787 85.3241 72.5787 81.1793C72.5787 77.0346 75.8877 73.7216 80 73.7216C84.126 73.7216 87.4349 77.0346 87.4349 81.1793C87.4349 85.3241 84.126 88.6371 80 88.6371ZM89.7906 77.8526C88.8647 77.8526 88.1021 77.1028 88.1021 76.1757C88.1021 75.2349 88.8647 74.4851 89.7906 74.4851C90.7166 74.4851 91.4791 75.2349 91.4791 76.1757C91.4791 77.1028 90.7166 77.8526 89.7906 77.8526ZM80 86.5648C82.9685 86.5648 85.3787 84.1652 85.3787 81.1793C85.3787 78.1935 82.9685 75.7939 80 75.7939C77.0315 75.7939 74.6349 78.1935 74.6349 81.1793C74.6349 84.1652 77.0451 86.5648 80 86.5648Z\" fill=\"#BDBDBD\"/>\n    </svg>\n    \n\n</div>\n<div class=\"image\" style=\"text-align: center;\" *ngIf=\"image\" >\n<img style=\"width:160px;display:inline-block;height:160px;object-fit: cover;border-radius: 100px;\" [src]=\"image\">\n\n</div>\n</div>\n\n<div class=\"buttons\">\n<ion-button color=\"primary\" expand=\"block\" (click)=\"openCamera()\" fill=\"solid\">{{'SETTINGS.VEHICLES.INPUTS.upload' | translate}}</ion-button>\n<!-- <ion-button color=\"danger\" expand=\"block\"  fill=\"outline\">Delete Photo</ion-button> -->\n\n</div>\n\n\n\n  \n</div>\n<div class=\"form\">\n  <ion-item lines=\"none\">\n    <ion-label color=\"medium\"  position=\"stacked\">{{'SETTINGS.VEHICLES.INPUTS.name' | translate}}</ion-label>\n    <ion-input placeholder=\"{{'SETTINGS.VEHICLES.INPUTS.name_placeholder' | translate}}\" autofocus=\"true\" [(ngModel)]=\"name\" name=\"name\"></ion-input>\n    <span class=\"error\" *ngIf=\"errors.length!=0 && errors.name\">{{errors.name[0]}}</span>\n\n  </ion-item>\n\n \n\n\n\n\n</div>\n\n\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/settings/pilots/create/create-routing.module.ts":
    /*!*****************************************************************!*\
      !*** ./src/app/settings/pilots/create/create-routing.module.ts ***!
      \*****************************************************************/

    /*! exports provided: CreatePageRoutingModule */

    /***/
    function srcAppSettingsPilotsCreateCreateRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CreatePageRoutingModule", function () {
        return CreatePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _create_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./create.page */
      "./src/app/settings/pilots/create/create.page.ts");

      var routes = [{
        path: '',
        component: _create_page__WEBPACK_IMPORTED_MODULE_3__["CreatePage"]
      }];

      var CreatePageRoutingModule = function CreatePageRoutingModule() {
        _classCallCheck(this, CreatePageRoutingModule);
      };

      CreatePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], CreatePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/settings/pilots/create/create.module.ts":
    /*!*********************************************************!*\
      !*** ./src/app/settings/pilots/create/create.module.ts ***!
      \*********************************************************/

    /*! exports provided: CreatePageModule */

    /***/
    function srcAppSettingsPilotsCreateCreateModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CreatePageModule", function () {
        return CreatePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _create_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./create-routing.module */
      "./src/app/settings/pilots/create/create-routing.module.ts");
      /* harmony import */


      var _create_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./create.page */
      "./src/app/settings/pilots/create/create.page.ts");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/common/http */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");

      var CreatePageModule = function CreatePageModule() {
        _classCallCheck(this, CreatePageModule);
      };

      CreatePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"], _create_routing_module__WEBPACK_IMPORTED_MODULE_5__["CreatePageRoutingModule"]],
        declarations: [_create_page__WEBPACK_IMPORTED_MODULE_6__["CreatePage"]]
      })], CreatePageModule);
      /***/
    },

    /***/
    "./src/app/settings/pilots/create/create.page.scss":
    /*!*********************************************************!*\
      !*** ./src/app/settings/pilots/create/create.page.scss ***!
      \*********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppSettingsPilotsCreateCreatePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".create {\n  max-width: 90%;\n  margin: 1.8rem auto;\n  text-transform: uppercase;\n}\n.create ion-text h6 {\n  font-weight: 400;\n  font-size: 0.8125rem;\n}\n.create .photo {\n  width: 100%;\n  margin: 0 auto;\n  text-align: center;\n}\n.create .buttons {\n  display: flex;\n  margin-top: 1.6rem;\n}\n.create .buttons ion-button {\n  text-transform: none;\n  width: 100%;\n  --font-size:rem(16px);\n  font-weight: 500;\n  --padding-top:1rem;\n  --padding-bottom:1rem;\n}\n.form {\n  max-width: 90%;\n  margin: 0 auto;\n}\n.form ion-item {\n  margin-top: 0.7rem;\n  --padding-start: 0;\n  --padding-end: 0;\n  --inner-padding-end: 0;\n}\n.form ion-item ion-label {\n  text-transform: uppercase;\n  padding-left: 0.5rem;\n  font-weight: 400;\n  font-size: 0.8rem;\n}\n.form ion-item ion-input, .form ion-item ion-textarea {\n  --padding-end:.5rem;\n  --padding-start:.5rem;\n  border: 1px solid var(--ion-color-medium-shade);\n  border-radius: 6px;\n  --padding-top:.8rem;\n  --padding-bottom:.8rem;\n  background: var(--ion-color-medium-tint);\n  transition: 0.3s ease-in;\n}\n.form ion-item ion-input:focus, .form ion-item ion-textarea:focus {\n  border: 1px solid var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2V0dGluZ3MvcGlsb3RzL2NyZWF0ZS9jcmVhdGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUlBO0VBQ0ksY0FBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7QUFISjtBQU1XO0VBQ0MsZ0JBQUE7RUFDQSxvQkFBQTtBQUpaO0FBUUk7RUFDSSxXQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBTlI7QUFRSTtFQUNJLGFBQUE7RUFDQSxrQkFBQTtBQU5SO0FBT1E7RUFDSSxvQkFBQTtFQUNBLFdBQUE7RUFDQSxxQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtBQUxaO0FBVUE7RUFDSSxjQUFBO0VBQ0EsY0FBQTtBQVBKO0FBUUk7RUFDSSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtBQU5SO0FBUUc7RUFDSSx5QkFBQTtFQUNBLG9CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQU5QO0FBU0c7RUFDQyxtQkFBQTtFQUNBLHFCQUFBO0VBRUcsK0NBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0Esc0JBQUE7RUFDQSx3Q0FBQTtFQUNBLHdCQUFBO0FBUlA7QUFTTztFQUNDLDBDQUFBO0FBUFIiLCJmaWxlIjoic3JjL2FwcC9zZXR0aW5ncy9waWxvdHMvY3JlYXRlL2NyZWF0ZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuQGZ1bmN0aW9uIHJlbSgkc2l6ZSkge1xyXG4gICAgQHJldHVybiAkc2l6ZSAvIDE2cHggKiAxcmVtO1xyXG4gIH1cclxuLmNyZWF0ZXtcclxuICAgIG1heC13aWR0aDo5MCU7XHJcbiAgICBtYXJnaW46MS44cmVtIGF1dG87XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgaW9uLXRleHR7XHJcbiBcclxuICAgICAgICAgICBoNntcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICAgICAgICAgICAgZm9udC1zaXplOnJlbSgxM3B4KTtcclxuICAgICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgLnBob3Rve1xyXG4gICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICAgbWFyZ2luOjAgYXV0bztcclxuICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICB9XHJcbiAgICAuYnV0dG9uc3tcclxuICAgICAgICBkaXNwbGF5OmZsZXg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDoxLjZyZW07XHJcbiAgICAgICAgaW9uLWJ1dHRvbntcclxuICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XHJcbiAgICAgICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgICAgICAgIC0tZm9udC1zaXplOnJlbSgxNnB4KTtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6NTAwO1xyXG4gICAgICAgICAgICAtLXBhZGRpbmctdG9wOjFyZW07XHJcbiAgICAgICAgICAgIC0tcGFkZGluZy1ib3R0b206MXJlbTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuXHJcbi5mb3Jte1xyXG4gICAgbWF4LXdpZHRoOjkwJTtcclxuICAgIG1hcmdpbjowIGF1dG87XHJcbiAgICBpb24taXRlbXtcclxuICAgICAgICBtYXJnaW4tdG9wOi43cmVtO1xyXG4gICAgICAgIC0tcGFkZGluZy1zdGFydDogMDtcclxuICAgICAgICAtLXBhZGRpbmctZW5kOiAwO1xyXG4gICAgICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDA7XHJcblxyXG4gICBpb24tbGFiZWx7XHJcbiAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgICAgcGFkZGluZy1sZWZ0Oi41cmVtO1xyXG4gICAgICAgZm9udC13ZWlnaHQ6NDAwO1xyXG4gICAgICAgZm9udC1zaXplOi44cmVtO1xyXG5cclxuICAgfVxyXG4gICBpb24taW5wdXQsaW9uLXRleHRhcmVhe1xyXG4gICAgLS1wYWRkaW5nLWVuZDouNXJlbTtcclxuICAgIC0tcGFkZGluZy1zdGFydDouNXJlbTtcclxuXHJcbiAgICAgICBib3JkZXI6MXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1tZWRpdW0tc2hhZGUpO1xyXG4gICAgICAgYm9yZGVyLXJhZGl1czo2cHg7XHJcbiAgICAgICAtLXBhZGRpbmctdG9wOi44cmVtO1xyXG4gICAgICAgLS1wYWRkaW5nLWJvdHRvbTouOHJlbTtcclxuICAgICAgIGJhY2tncm91bmQ6dmFyKC0taW9uLWNvbG9yLW1lZGl1bS10aW50KTtcclxuICAgICAgIHRyYW5zaXRpb246LjNzIGVhc2UtaW47XHJcbiAgICAgICAmOmZvY3Vze1xyXG4gICAgICAgIGJvcmRlcjoxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG5cclxuICAgICAgIH1cclxuICAgICAgICAgICAgICAgfVxyXG4gICAgfVxyXG5cclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/settings/pilots/create/create.page.ts":
    /*!*******************************************************!*\
      !*** ./src/app/settings/pilots/create/create.page.ts ***!
      \*******************************************************/

    /*! exports provided: CreatePage */

    /***/
    function srcAppSettingsPilotsCreateCreatePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CreatePage", function () {
        return CreatePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/platform-browser */
      "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
      /* harmony import */


      var _services_photo_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../../../services/photo.service */
      "./src/app/services/photo.service.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _capacitor_community_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @capacitor-community/http */
      "./node_modules/@capacitor-community/http/dist/esm/index.js");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../../../environments/environment */
      "./src/environments/environment.ts");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/common/http */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @ngx-translate/core */
      "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @capacitor/core */
      "./node_modules/@capacitor/core/dist/esm/index.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

      var Haptics = _capacitor_core__WEBPACK_IMPORTED_MODULE_10__["Plugins"].Haptics;

      var CreatePage = /*#__PURE__*/function () {
        function CreatePage(translate, router, http, storage, loadingController, sanitizer, photo) {
          _classCallCheck(this, CreatePage);

          this.translate = translate;
          this.router = router;
          this.http = http;
          this.storage = storage;
          this.loadingController = loadingController;
          this.sanitizer = sanitizer;
          this.photo = photo;
          this.name = "";
          this.phone = "";
          this.loginId = "";
          this.errors = [];
        }

        _createClass(CreatePage, [{
          key: "hapticsImpact",
          value: function hapticsImpact() {
            var style = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _capacitor_core__WEBPACK_IMPORTED_MODULE_10__["HapticsImpactStyle"].Heavy;

            // Native StatusBar available
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_10__["Capacitor"].getPlatform() != 'web') {
              Haptics.impact({
                style: style
              });
            }
          }
        }, {
          key: "hapticsImpactLight",
          value: function hapticsImpactLight() {
            this.hapticsImpact(_capacitor_core__WEBPACK_IMPORTED_MODULE_10__["HapticsImpactStyle"].Light);
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "openCamera",
          value: function openCamera() {
            var _this = this;

            this.photo.takePicture().then(function (res) {
              console.log(res);
              _this.image = _this.sanitizer.bypassSecurityTrustUrl("data:image/png;base64," + res.url);
              _this.file = res.upload;
              _this.format = res.format;
            });
          }
        }, {
          key: "presentLoading",
          value: function presentLoading() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _yield$this$loader$on, role, data;

              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.loadingController.create({
                        cssClass: 'my-custom-class',
                        message: this.translate.instant('wait')
                      });

                    case 2:
                      this.loader = _context.sent;
                      _context.next = 5;
                      return this.loader.present();

                    case 5:
                      _context.next = 7;
                      return this.loader.onDidDismiss();

                    case 7:
                      _yield$this$loader$on = _context.sent;
                      role = _yield$this$loader$on.role;
                      data = _yield$this$loader$on.data;
                      console.log('Loading dismissed!');

                    case 11:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "insert",
          value: function insert() {
            var _this2 = this;

            this.hapticsImpactLight();
            this.presentLoading();
            this.storage.get('USER_INFO').then(function (res) {
              var doPost = function doPost() {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
                  var ret;
                  return regeneratorRuntime.wrap(function _callee2$(_context2) {
                    while (1) {
                      switch (_context2.prev = _context2.next) {
                        case 0:
                          _context2.next = 2;
                          return _capacitor_community_http__WEBPACK_IMPORTED_MODULE_5__["Http"].request({
                            method: 'POST',
                            url: "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_7__["SERVER_URL"], "/api/users"),
                            headers: {
                              'Accept': 'application/json',
                              'Content-Type': 'application/json',
                              'Authorization': 'Bearer ' + res.token
                            },
                            data: {
                              name: this.name,
                              phone: this.phone,
                              login_id: this.loginId,
                              file: this.file,
                              format: this.format
                            }
                          });

                        case 2:
                          ret = _context2.sent;
                          return _context2.abrupt("return", ret);

                        case 4:
                        case "end":
                          return _context2.stop();
                      }
                    }
                  }, _callee2, this);
                }));
              };

              doPost().then(function (res) {
                _this2.hideLoader();

                if (res['status'] == 200) {
                  var navigationExtras = {
                    queryParams: {
                      reload: true
                    }
                  };

                  _this2.router.navigate(["/settings/pilots"], navigationExtras);
                } else if (res['status'] == 422) {
                  _this2.errors = res['data'].errors;
                } // this.pilots = res['data'];
                //   this.loading = false;

              });
            });
          }
        }, {
          key: "hideLoader",
          value: function hideLoader() {
            if (this.loader != null) {
              this.loader.dismiss();
              this.loader = null;
            }
          }
        }]);

        return CreatePage;
      }();

      CreatePage.ctorParameters = function () {
        return [{
          type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__["TranslateService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_11__["Router"]
        }, {
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_8__["HttpClient"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
        }, {
          type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"]
        }, {
          type: _services_photo_service__WEBPACK_IMPORTED_MODULE_3__["PhotoService"]
        }];
      };

      CreatePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-create',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./create.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/pilots/create/create.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./create.page.scss */
        "./src/app/settings/pilots/create/create.page.scss"))["default"]]
      })], CreatePage);
      /***/
    },

    /***/
    "./src/app/settings/vehicles/create/create-routing.module.ts":
    /*!*******************************************************************!*\
      !*** ./src/app/settings/vehicles/create/create-routing.module.ts ***!
      \*******************************************************************/

    /*! exports provided: CreatePageRoutingModule */

    /***/
    function srcAppSettingsVehiclesCreateCreateRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CreatePageRoutingModule", function () {
        return CreatePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _create_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./create.page */
      "./src/app/settings/vehicles/create/create.page.ts");

      var routes = [{
        path: '',
        component: _create_page__WEBPACK_IMPORTED_MODULE_3__["CreatePage"]
      }];

      var CreatePageRoutingModule = function CreatePageRoutingModule() {
        _classCallCheck(this, CreatePageRoutingModule);
      };

      CreatePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], CreatePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/settings/vehicles/create/create.module.ts":
    /*!***********************************************************!*\
      !*** ./src/app/settings/vehicles/create/create.module.ts ***!
      \***********************************************************/

    /*! exports provided: CreatePageModule */

    /***/
    function srcAppSettingsVehiclesCreateCreateModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CreatePageModule", function () {
        return CreatePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _create_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./create-routing.module */
      "./src/app/settings/vehicles/create/create-routing.module.ts");
      /* harmony import */


      var _create_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./create.page */
      "./src/app/settings/vehicles/create/create.page.ts");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/common/http */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @ngx-translate/core */
      "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js"); // add this


      var CreatePageModule = function CreatePageModule() {
        _classCallCheck(this, CreatePageModule);
      };

      CreatePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_7__["HttpClientModule"], _create_routing_module__WEBPACK_IMPORTED_MODULE_5__["CreatePageRoutingModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"]],
        declarations: [_create_page__WEBPACK_IMPORTED_MODULE_6__["CreatePage"]]
      })], CreatePageModule);
      /***/
    },

    /***/
    "./src/app/settings/vehicles/create/create.page.scss":
    /*!***********************************************************!*\
      !*** ./src/app/settings/vehicles/create/create.page.scss ***!
      \***********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppSettingsVehiclesCreateCreatePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".create {\n  max-width: 90%;\n  margin: 1.8rem auto;\n  text-transform: uppercase;\n}\n.create ion-text h6 {\n  font-weight: 400;\n  font-size: 0.8125rem;\n}\n.create .photo {\n  width: 100%;\n  margin: 0 auto;\n  text-align: center;\n}\n.create .buttons {\n  display: flex;\n  margin-top: 1.6rem;\n}\n.create .buttons ion-button {\n  text-transform: none;\n  width: 100%;\n  --font-size:rem(16px);\n  font-weight: 500;\n  --padding-top:1rem;\n  --padding-bottom:1rem;\n}\n.form {\n  max-width: 90%;\n  margin: 0 auto;\n}\n.form ion-item {\n  margin-top: 0.7rem;\n  --padding-start: 0;\n  --padding-end: 0;\n  --inner-padding-end: 0;\n}\n.form ion-item ion-label {\n  text-transform: uppercase;\n  padding-left: 0.5rem;\n  font-weight: 400;\n  font-size: 0.8rem;\n}\n.form ion-item ion-input, .form ion-item ion-textarea {\n  --padding-end:.5rem;\n  --padding-start:.5rem;\n  border: 1px solid var(--ion-color-medium-shade);\n  border-radius: 6px;\n  --padding-top:.8rem;\n  --padding-bottom:.8rem;\n  background: var(--ion-color-medium-tint);\n  transition: 0.3s ease-in;\n}\n.form ion-item ion-input:focus, .form ion-item ion-textarea:focus {\n  border: 1px solid var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2V0dGluZ3MvdmVoaWNsZXMvY3JlYXRlL2NyZWF0ZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBSUE7RUFDSSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBQUhKO0FBTVc7RUFDQyxnQkFBQTtFQUNBLG9CQUFBO0FBSlo7QUFRSTtFQUNJLFdBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFOUjtBQVFJO0VBQ0ksYUFBQTtFQUNBLGtCQUFBO0FBTlI7QUFPUTtFQUNJLG9CQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0FBTFo7QUFVQTtFQUNJLGNBQUE7RUFDQSxjQUFBO0FBUEo7QUFRSTtFQUNJLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLHNCQUFBO0FBTlI7QUFRRztFQUNJLHlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBTlA7QUFTRztFQUNDLG1CQUFBO0VBQ0EscUJBQUE7RUFFRywrQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLHdDQUFBO0VBQ0Esd0JBQUE7QUFSUDtBQVNPO0VBQ0MsMENBQUE7QUFQUiIsImZpbGUiOiJzcmMvYXBwL3NldHRpbmdzL3ZlaGljbGVzL2NyZWF0ZS9jcmVhdGUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbkBmdW5jdGlvbiByZW0oJHNpemUpIHtcclxuICAgIEByZXR1cm4gJHNpemUgLyAxNnB4ICogMXJlbTtcclxuICB9XHJcbi5jcmVhdGV7XHJcbiAgICBtYXgtd2lkdGg6OTAlO1xyXG4gICAgbWFyZ2luOjEuOHJlbSBhdXRvO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgIGlvbi10ZXh0e1xyXG4gXHJcbiAgICAgICAgICAgaDZ7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTpyZW0oMTNweCk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5waG90b3tcclxuICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgIG1hcmdpbjowIGF1dG87XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLmJ1dHRvbnN7XHJcbiAgICAgICAgZGlzcGxheTpmbGV4O1xyXG4gICAgICAgIG1hcmdpbi10b3A6MS42cmVtO1xyXG4gICAgICAgIGlvbi1idXR0b257XHJcbiAgICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xyXG4gICAgICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgICAgICAtLWZvbnQtc2l6ZTpyZW0oMTZweCk7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OjUwMDtcclxuICAgICAgICAgICAgLS1wYWRkaW5nLXRvcDoxcmVtO1xyXG4gICAgICAgICAgICAtLXBhZGRpbmctYm90dG9tOjFyZW07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4uZm9ybXtcclxuICAgIG1heC13aWR0aDo5MCU7XHJcbiAgICBtYXJnaW46MCBhdXRvO1xyXG4gICAgaW9uLWl0ZW17XHJcbiAgICAgICAgbWFyZ2luLXRvcDouN3JlbTtcclxuICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDA7XHJcbiAgICAgICAgLS1wYWRkaW5nLWVuZDogMDtcclxuICAgICAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xyXG5cclxuICAgaW9uLWxhYmVse1xyXG4gICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgIHBhZGRpbmctbGVmdDouNXJlbTtcclxuICAgICAgIGZvbnQtd2VpZ2h0OjQwMDtcclxuICAgICAgIGZvbnQtc2l6ZTouOHJlbTtcclxuXHJcbiAgIH1cclxuICAgaW9uLWlucHV0LGlvbi10ZXh0YXJlYXtcclxuICAgIC0tcGFkZGluZy1lbmQ6LjVyZW07XHJcbiAgICAtLXBhZGRpbmctc3RhcnQ6LjVyZW07XHJcblxyXG4gICAgICAgYm9yZGVyOjFweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXNoYWRlKTtcclxuICAgICAgIGJvcmRlci1yYWRpdXM6NnB4O1xyXG4gICAgICAgLS1wYWRkaW5nLXRvcDouOHJlbTtcclxuICAgICAgIC0tcGFkZGluZy1ib3R0b206LjhyZW07XHJcbiAgICAgICBiYWNrZ3JvdW5kOnZhcigtLWlvbi1jb2xvci1tZWRpdW0tdGludCk7XHJcbiAgICAgICB0cmFuc2l0aW9uOi4zcyBlYXNlLWluO1xyXG4gICAgICAgJjpmb2N1c3tcclxuICAgICAgICBib3JkZXI6MXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuXHJcbiAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH1cclxuICAgIH1cclxuXHJcbn0iXX0= */";
      /***/
    },

    /***/
    "./src/app/settings/vehicles/create/create.page.ts":
    /*!*********************************************************!*\
      !*** ./src/app/settings/vehicles/create/create.page.ts ***!
      \*********************************************************/

    /*! exports provided: CreatePage */

    /***/
    function srcAppSettingsVehiclesCreateCreatePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CreatePage", function () {
        return CreatePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/platform-browser */
      "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
      /* harmony import */


      var _services_photo_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../../../services/photo.service */
      "./src/app/services/photo.service.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _capacitor_community_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @capacitor-community/http */
      "./node_modules/@capacitor-community/http/dist/esm/index.js");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../../../environments/environment */
      "./src/environments/environment.ts");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/common/http */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @ngx-translate/core */
      "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @capacitor/core */
      "./node_modules/@capacitor/core/dist/esm/index.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

      var _capacitor_core__WEBP = _capacitor_core__WEBPACK_IMPORTED_MODULE_10__["Plugins"],
          Haptics = _capacitor_core__WEBP.Haptics,
          Http = _capacitor_core__WEBP.Http;

      var CreatePage = /*#__PURE__*/function () {
        function CreatePage(translate, router, http, storage, loadingController, sanitizer, photo) {
          _classCallCheck(this, CreatePage);

          this.translate = translate;
          this.router = router;
          this.http = http;
          this.storage = storage;
          this.loadingController = loadingController;
          this.sanitizer = sanitizer;
          this.photo = photo;
          this.name = "";
          this.errors = [];
        }

        _createClass(CreatePage, [{
          key: "hapticsImpact",
          value: function hapticsImpact() {
            var style = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _capacitor_core__WEBPACK_IMPORTED_MODULE_10__["HapticsImpactStyle"].Heavy;

            // Native StatusBar available
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_10__["Capacitor"].getPlatform() != 'web') {
              Haptics.impact({
                style: style
              });
            }
          }
        }, {
          key: "hapticsImpactLight",
          value: function hapticsImpactLight() {
            this.hapticsImpact(_capacitor_core__WEBPACK_IMPORTED_MODULE_10__["HapticsImpactStyle"].Light);
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "openCamera",
          value: function openCamera() {
            var _this3 = this;

            this.photo.takePicture().then(function (res) {
              console.log(res);
              _this3.image = _this3.sanitizer.bypassSecurityTrustUrl("data:image/png;base64," + res.url);
              _this3.file = res.upload;
              _this3.format = res.format;
            });
          }
        }, {
          key: "presentLoading",
          value: function presentLoading() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var _yield$this$loader$on2, role, data;

              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.loadingController.create({
                        cssClass: 'my-custom-class',
                        message: this.translate.instant('wait')
                      });

                    case 2:
                      this.loader = _context3.sent;
                      _context3.next = 5;
                      return this.loader.present();

                    case 5:
                      _context3.next = 7;
                      return this.loader.onDidDismiss();

                    case 7:
                      _yield$this$loader$on2 = _context3.sent;
                      role = _yield$this$loader$on2.role;
                      data = _yield$this$loader$on2.data;
                      console.log('Loading dismissed!');

                    case 11:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "insert",
          value: function insert() {
            var _this4 = this;

            this.hapticsImpactLight();
            this.presentLoading();
            this.storage.get('USER_INFO').then(function (res) {
              var doPost = function doPost() {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this4, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                  var ret;
                  return regeneratorRuntime.wrap(function _callee4$(_context4) {
                    while (1) {
                      switch (_context4.prev = _context4.next) {
                        case 0:
                          _context4.next = 2;
                          return Http.request({
                            method: 'POST',
                            url: "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_7__["SERVER_URL"], "/api/vehicles"),
                            headers: {
                              'Accept': 'application/json',
                              'Content-Type': 'application/json',
                              'Authorization': 'Bearer ' + res.token
                            },
                            data: {
                              name: this.name,
                              file: this.file,
                              format: this.format
                            }
                          });

                        case 2:
                          ret = _context4.sent;
                          return _context4.abrupt("return", ret);

                        case 4:
                        case "end":
                          return _context4.stop();
                      }
                    }
                  }, _callee4, this);
                }));
              };

              doPost().then(function (res) {
                _this4.hideLoader();

                if (res['status'] == 200) {
                  var navigationExtras = {
                    queryParams: {
                      reload: true
                    }
                  };

                  _this4.router.navigate(["/settings/vehicles"], navigationExtras);
                } else if (res['status'] == 422) {
                  _this4.errors = res['data'].errors;
                } // this.vehicles = res['data'];
                //   this.loading = false;

              });
            });
          }
        }, {
          key: "hideLoader",
          value: function hideLoader() {
            if (this.loader != null) {
              this.loader.dismiss();
              this.loader = null;
            }
          }
        }]);

        return CreatePage;
      }();

      CreatePage.ctorParameters = function () {
        return [{
          type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__["TranslateService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_11__["Router"]
        }, {
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_8__["HttpClient"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
        }, {
          type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"]
        }, {
          type: _services_photo_service__WEBPACK_IMPORTED_MODULE_3__["PhotoService"]
        }];
      };

      CreatePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-create',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./create.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/vehicles/create/create.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./create.page.scss */
        "./src/app/settings/vehicles/create/create.page.scss"))["default"]]
      })], CreatePage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=create-create-module-es5.js.map