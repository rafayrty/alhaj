export interface AuthStateModel {
    token: string | null;
    user: Array<any> | null;

  }
  