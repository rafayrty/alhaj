export const environment = {
  production: true
};

export const SERVER_URL = 'https://alhaj.nazadv.com/public';
//When Two Normal Orders Are Assigned Simultatenously
//When Two Vehicles are not available and order is assigned to them
//The Old Testing