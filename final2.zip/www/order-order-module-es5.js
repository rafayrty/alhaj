(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["order-order-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/order/order.page.html":
    /*!*****************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/order/order.page.html ***!
      \*****************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppOrderOrderPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>{{'HOME.title' | translate}}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"logOut()\">{{'logout' | translate}}</ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n\n</ion-header>\n\n<ion-content>\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\" pullFactor=\"0.5\" pullMin=\"100\" pullMax=\"200\">\n    <ion-refresher-content></ion-refresher-content>\n  </ion-refresher>\n<div class=\"order-empty\" [@inOutAnimation] *ngIf=\"!order\">\n  <h1>{{'ORDER.DONE.all' | translate}}</h1>\n<div id=\"svg\">\n\n  <svg  viewBox=\"0 0 219 187\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n    <rect width=\"219\" height=\"55\" rx=\"10\" fill=\"#F2F2F2\"/>\n    <rect y=\"66\" width=\"219\" height=\"55\" rx=\"10\" fill=\"#F2F2F2\"/>\n    <rect y=\"132\" width=\"219\" height=\"55\" rx=\"10\" fill=\"#F2F2F2\"/>\n    <circle cx=\"192.5\" cy=\"27.5\" r=\"10.5\" fill=\"white\"/>\n    <circle cx=\"192.5\" cy=\"93.5\" r=\"10.5\" fill=\"white\"/>\n    <circle cx=\"192.5\" cy=\"159.5\" r=\"10.5\" fill=\"white\"/>\n    <path d=\"M198.171 24L199 24.7222L192.654 32L189.549 28.8971L190.327 28.1199L192.598 30.3905L198.171 24Z\" fill=\"#E0E0E0\"/>\n    <path d=\"M187 28.897L187.778 28.1199L190.879 31.2202L190.102 31.9974L187 28.897Z\" fill=\"#E0E0E0\"/>\n    <path d=\"M196.451 24.7214L195.621 24L191.725 28.4764L192.555 29.1977L196.451 24.7214Z\" fill=\"#E0E0E0\"/>\n    <path d=\"M198.171 90L199 90.7222L192.654 98L189.549 94.8971L190.327 94.1199L192.598 96.3905L198.171 90Z\" fill=\"#E0E0E0\"/>\n    <path d=\"M187 94.897L187.778 94.1199L190.879 97.2202L190.102 97.9974L187 94.897Z\" fill=\"#E0E0E0\"/>\n    <path d=\"M196.451 90.7214L195.621 90L191.725 94.4764L192.555 95.1977L196.451 90.7214Z\" fill=\"#E0E0E0\"/>\n    <path d=\"M198.171 156L199 156.722L192.654 164L189.549 160.897L190.327 160.12L192.598 162.39L198.171 156Z\" fill=\"#E0E0E0\"/>\n    <path d=\"M187 160.897L187.778 160.12L190.879 163.22L190.102 163.997L187 160.897Z\" fill=\"#E0E0E0\"/>\n    <path d=\"M196.451 156.721L195.621 156L191.725 160.476L192.555 161.198L196.451 156.721Z\" fill=\"#E0E0E0\"/>\n    <rect x=\"16\" y=\"15\" width=\"115\" height=\"10\" fill=\"white\"/>\n    <rect x=\"16\" y=\"81\" width=\"115\" height=\"10\" fill=\"white\"/>\n    <rect x=\"16\" y=\"147\" width=\"115\" height=\"10\" fill=\"white\"/>\n    <rect x=\"16\" y=\"31\" width=\"64\" height=\"10\" fill=\"white\"/>\n    <rect x=\"16\" y=\"97\" width=\"64\" height=\"10\" fill=\"white\"/>\n    <rect x=\"16\" y=\"163\" width=\"64\" height=\"10\" fill=\"white\"/>\n    </svg>\n  </div>\n  <p>{{'ORDER.DONE.notification' | translate}}</p>\n\n</div>\n<div class=\"order-received\" [@inOutAnimation] *ngIf=\"order\">\n\n<div class=\"client\">\n\n<h3 class=\"client-name\">\n{{order.client}}\n</h3>\n<p>{{order.shipping}}</p>\n<ion-button color=\"success\" (click)=\"call(order.phone)\">{{'ORDER.call' | translate}}</ion-button>\n</div>\n<hr>\n<div class=\"total\">\n<ion-text color=\"medium\">\n  <h6>{{'ORDER.collectible' | translate}}</h6>\n</ion-text>\n<div class=\"collectible\">\n  <ion-chip color=\"success\" outline=\"true\">\n    <ion-label  >₪ {{order.price}}</ion-label>\n  </ion-chip>\n</div>\n\n</div>\n\n<ion-text class=\"order\" color=\"medium\">\n  <h6>{{'ORDER.details' | translate}}</h6>\n</ion-text>\n<div class=\"order-details\" *ngIf=\"order.details\">\n<p>{{order.details}}</p>\n\n</div>\n<div class=\"images\" *ngIf=\"order.image\">\n  <ion-thumbnail (click)=\"openViewer(order.image)\" height=\"65\" width=\"65\">\n    <img src=\"{{order.image}}\">\n  </ion-thumbnail>\n</div>\n</div>\n\n</ion-content>\n\n<ion-footer *ngIf=\"order\">\n  <ion-button  expand=\"block\" *ngIf=\"order.status=='Pending'\" (click)=\"updateStatus($event,'Shipped',order.id)\" > <ion-icon name=\"paper-plane-sharp\"></ion-icon> <span>{{'ORDER.shipped' | translate}}</span></ion-button>\n  <ion-button  expand=\"block\" *ngIf=\"order.status=='Shipped'\" (click)=\"updateStatus($event,'Delivered',order.id)\"  color=\"success\"> <ion-icon name=\"checkmark-done-outline\"></ion-icon> <span>{{'ORDER.delivered' | translate}} </span></ion-button>\n\n</ion-footer>\n\n";
      /***/
    },

    /***/
    "./src/app/order/order-routing.module.ts":
    /*!***********************************************!*\
      !*** ./src/app/order/order-routing.module.ts ***!
      \***********************************************/

    /*! exports provided: OrderPageRoutingModule */

    /***/
    function srcAppOrderOrderRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "OrderPageRoutingModule", function () {
        return OrderPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _order_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./order.page */
      "./src/app/order/order.page.ts");

      var routes = [{
        path: '',
        component: _order_page__WEBPACK_IMPORTED_MODULE_3__["OrderPage"]
      }];

      var OrderPageRoutingModule = function OrderPageRoutingModule() {
        _classCallCheck(this, OrderPageRoutingModule);
      };

      OrderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], OrderPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/order/order.module.ts":
    /*!***************************************!*\
      !*** ./src/app/order/order.module.ts ***!
      \***************************************/

    /*! exports provided: OrderPageModule */

    /***/
    function srcAppOrderOrderModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "OrderPageModule", function () {
        return OrderPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _order_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./order-routing.module */
      "./src/app/order/order-routing.module.ts");
      /* harmony import */


      var _order_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./order.page */
      "./src/app/order/order.page.ts");
      /* harmony import */


      var ngx_ionic_image_viewer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ngx-ionic-image-viewer */
      "./node_modules/ngx-ionic-image-viewer/__ivy_ngcc__/fesm2015/ngx-ionic-image-viewer.js");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @ngx-translate/core */
      "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js"); // add this


      var OrderPageModule = function OrderPageModule() {
        _classCallCheck(this, OrderPageModule);
      };

      OrderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], ngx_ionic_image_viewer__WEBPACK_IMPORTED_MODULE_7__["NgxIonicImageViewerModule"], _order_routing_module__WEBPACK_IMPORTED_MODULE_5__["OrderPageRoutingModule"], _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"]],
        declarations: [_order_page__WEBPACK_IMPORTED_MODULE_6__["OrderPage"]]
      })], OrderPageModule);
      /***/
    },

    /***/
    "./src/app/order/order.page.scss":
    /*!***************************************!*\
      !*** ./src/app/order/order.page.scss ***!
      \***************************************/

    /*! exports provided: default */

    /***/
    function srcAppOrderOrderPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "h1, h2, h3, h4, h5, h6, p {\n  margin: 0;\n  padding: 0;\n}\n\n.order-empty {\n  max-width: 88%;\n  width: 100%;\n  text-align: center;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -62%);\n}\n\n.order-empty h1 {\n  font-weight: 700;\n  font-size: 2.125rem;\n}\n\n.order-empty #svg {\n  max-width: 65%;\n  margin: 2rem auto;\n}\n\n.order-empty p {\n  font-size: 1.125rem;\n}\n\n.client {\n  margin: 1rem 0;\n  text-align: center;\n  line-height: 1.8;\n}\n\n.client .client-name {\n  font-size: 1.125rem;\n  color: var(--ion-color-primary);\n}\n\n.client p {\n  font-size: 0.875rem;\n  color: var(--ion-color-primary);\n}\n\n.client ion-button {\n  --padding-top:0rem;\n  --padding-bottom:0rem;\n  --padding-start:3rem;\n  --padding-end:3rem;\n  --border-radius:20px;\n  font-size: 0.875rem;\n}\n\nhr {\n  border-top: 1px solid var(--ion-color-medium-shade);\n}\n\n.total {\n  max-width: 90%;\n  margin: 0 auto;\n}\n\n.total ion-text {\n  margin-top: 0.5rem;\n  text-transform: uppercase;\n}\n\n.total ion-text h6 {\n  font-weight: 400;\n  font-size: 0.8125rem;\n}\n\n.total .collectible {\n  text-align: center;\n  margin: 0.5rem 0;\n}\n\n.total .collectible ion-chip {\n  padding: 1rem 1.6rem;\n  font-size: 0.875rem;\n  font-weight: 500;\n  border-width: 2px;\n}\n\n.order {\n  max-width: 90%;\n  margin: 0 auto;\n  margin-top: 0.5rem;\n  text-transform: uppercase;\n  display: block;\n}\n\n.order h6 {\n  font-weight: 400;\n  font-size: 0.8125rem;\n}\n\n.order-details {\n  max-width: 94%;\n  margin: 0 auto;\n  margin-top: 0.6rem;\n  border: 1px solid var(--ion-color-medium-shade);\n  padding: 1rem;\n  border-radius: 6px;\n}\n\n.images {\n  max-width: 90%;\n  margin: 1rem auto;\n}\n\n.images ion-thumbnail {\n  height: 65px;\n  width: 65px;\n}\n\n.images ion-thumbnail img {\n  display: block;\n  border: 1px solid var(--ion-color-primary);\n  border-radius: 6px;\n  box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.06);\n  height: 65px;\n  width: 65px;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n\nion-footer {\n  max-width: 92%;\n  margin: 0 auto;\n  margin-bottom: 1rem;\n}\n\nion-footer ion-button span {\n  margin-left: 0.8rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvb3JkZXIvb3JkZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBO0VBQ0ksU0FBQTtFQUNBLFVBQUE7QUFGSjs7QUFJQTtFQUNJLGNBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0NBQUE7QUFESjs7QUFHSTtFQUNJLGdCQUFBO0VBQ0EsbUJBQUE7QUFEUjs7QUFHSTtFQUNJLGNBQUE7RUFDQSxpQkFBQTtBQURSOztBQUdJO0VBQ0ksbUJBQUE7QUFEUjs7QUFPQTtFQUNJLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FBSko7O0FBS0k7RUFDSSxtQkFBQTtFQUNBLCtCQUFBO0FBSFI7O0FBTUk7RUFDSSxtQkFBQTtFQUNBLCtCQUFBO0FBSlI7O0FBTUk7RUFDSSxrQkFBQTtFQUNBLHFCQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLG9CQUFBO0VBQ0EsbUJBQUE7QUFKUjs7QUFRQTtFQUNJLG1EQUFBO0FBTEo7O0FBUUE7RUFDSSxjQUFBO0VBQ0EsY0FBQTtBQUxKOztBQU1JO0VBQ0ksa0JBQUE7RUFDQSx5QkFBQTtBQUpSOztBQUtRO0VBQ0ksZ0JBQUE7RUFDQSxvQkFBQTtBQUhaOztBQU1JO0VBQ0ksa0JBQUE7RUFDQSxnQkFBQTtBQUpSOztBQUtPO0VBQ0Msb0JBQUE7RUFDQyxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFIVDs7QUFRQTtFQUNJLGNBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7QUFMSjs7QUFNSTtFQUNJLGdCQUFBO0VBQ0Esb0JBQUE7QUFKUjs7QUFPQTtFQUNJLGNBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSwrQ0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtBQUpKOztBQU9BO0VBQ0ksY0FBQTtFQUNBLGlCQUFBO0FBSko7O0FBS0k7RUFDSSxZQUFBO0VBQ0EsV0FBQTtBQUhSOztBQUlRO0VBQ0ksY0FBQTtFQUNBLDBDQUFBO0VBQ0Esa0JBQUE7RUFDQSwyQ0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtBQUZaOztBQU9BO0VBQ0ksY0FBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtBQUpKOztBQU1RO0VBQ0ksbUJBQUE7QUFKWiIsImZpbGUiOiJzcmMvYXBwL29yZGVyL29yZGVyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBmdW5jdGlvbiByZW0oJHNpemUpIHtcclxuICAgIEByZXR1cm4gJHNpemUgLyAxNnB4ICogMXJlbTtcclxuICB9XHJcbmgxLGgyLGgzLGg0LGg1LGg2LHB7XHJcbiAgICBtYXJnaW46MDtcclxuICAgIHBhZGRpbmc6MDtcclxufVxyXG4ub3JkZXItZW1wdHl7XHJcbiAgICBtYXgtd2lkdGg6ODglO1xyXG4gICAgd2lkdGg6MTAwJTtcclxuICAgIHRleHQtYWxpZ246Y2VudGVyO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNjIlKTtcclxuXHJcbiAgICBoMXtcclxuICAgICAgICBmb250LXdlaWdodDogNzAwO1xyXG4gICAgICAgIGZvbnQtc2l6ZTpyZW0oMzRweCk7XHJcbiAgICB9XHJcbiAgICAjc3Zne1xyXG4gICAgICAgIG1heC13aWR0aDo2NSU7XHJcbiAgICAgICAgbWFyZ2luOjJyZW0gYXV0bztcclxuICAgIH1cclxuICAgIHB7XHJcbiAgICAgICAgZm9udC1zaXplOnJlbSgxOHB4KTtcclxuICAgIH1cclxuXHJcblxyXG59XHJcblxyXG4uY2xpZW50e1xyXG4gICAgbWFyZ2luOjFyZW0gMDtcclxuICAgIHRleHQtYWxpZ246Y2VudGVyO1xyXG4gICAgbGluZS1oZWlnaHQ6MS44O1xyXG4gICAgLmNsaWVudC1uYW1le1xyXG4gICAgICAgIGZvbnQtc2l6ZTpyZW0oMThweCk7XHJcbiAgICAgICAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG5cclxuICAgIH1cclxuICAgIHB7XHJcbiAgICAgICAgZm9udC1zaXplOnJlbSgxNHB4KTtcclxuICAgICAgICBjb2xvcjp2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICB9XHJcbiAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgIC0tcGFkZGluZy10b3A6MHJlbTtcclxuICAgICAgICAtLXBhZGRpbmctYm90dG9tOjByZW07XHJcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OjNyZW07XHJcbiAgICAgICAgLS1wYWRkaW5nLWVuZDozcmVtO1xyXG4gICAgICAgIC0tYm9yZGVyLXJhZGl1czoyMHB4O1xyXG4gICAgICAgIGZvbnQtc2l6ZTpyZW0oMTRweCk7XHJcbiAgICB9XHJcbn1cclxuXHJcbmhye1xyXG4gICAgYm9yZGVyLXRvcDoxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XHJcblxyXG59XHJcbi50b3RhbHtcclxuICAgIG1heC13aWR0aDo5MCU7XHJcbiAgICBtYXJnaW46MCBhdXRvO1xyXG4gICAgaW9uLXRleHR7XHJcbiAgICAgICAgbWFyZ2luLXRvcDouNXJlbTtcclxuICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgICAgIGg2e1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDo0MDA7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTpyZW0oMTNweCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmNvbGxlY3RpYmxle1xyXG4gICAgICAgIHRleHQtYWxpZ246Y2VudGVyO1xyXG4gICAgICAgIG1hcmdpbjouNXJlbSAwO1xyXG4gICAgICAgaW9uLWNoaXB7XHJcbiAgICAgICAgcGFkZGluZzogMXJlbSAxLjZyZW07XHJcbiAgICAgICAgIGZvbnQtc2l6ZTpyZW0oMTRweCk7XHJcbiAgICAgICAgIGZvbnQtd2VpZ2h0OjUwMDtcclxuICAgICAgICAgYm9yZGVyLXdpZHRoOjJweDtcclxuICAgICAgIH1cclxuICAgIH1cclxuICAgXHJcbn1cclxuLm9yZGVye1xyXG4gICAgbWF4LXdpZHRoOjkwJTtcclxuICAgIG1hcmdpbjowIGF1dG87XHJcbiAgICBtYXJnaW4tdG9wOi41cmVtO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgIGRpc3BsYXk6YmxvY2s7XHJcbiAgICBoNntcclxuICAgICAgICBmb250LXdlaWdodDo0MDA7XHJcbiAgICAgICAgZm9udC1zaXplOnJlbSgxM3B4KTtcclxuICAgIH1cclxufVxyXG4ub3JkZXItZGV0YWlsc3tcclxuICAgIG1heC13aWR0aDo5NCU7XHJcbiAgICBtYXJnaW46MCBhdXRvO1xyXG4gICAgbWFyZ2luLXRvcDouNnJlbTtcclxuICAgIGJvcmRlcjoxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XHJcbiAgICBwYWRkaW5nOjFyZW07XHJcbiAgICBib3JkZXItcmFkaXVzOjZweDtcclxuXHJcbn1cclxuLmltYWdlc3tcclxuICAgIG1heC13aWR0aDo5MCU7XHJcbiAgICBtYXJnaW46MXJlbSBhdXRvO1xyXG4gICAgaW9uLXRodW1ibmFpbHtcclxuICAgICAgICBoZWlnaHQ6NjVweDtcclxuICAgICAgICB3aWR0aDo2NXB4O1xyXG4gICAgICAgIGltZ3tcclxuICAgICAgICAgICAgZGlzcGxheTpibG9jaztcclxuICAgICAgICAgICAgYm9yZGVyOjFweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6NnB4O1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiAwcHggNHB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMDYpO1xyXG4gICAgICAgICAgICBoZWlnaHQ6NjVweDtcclxuICAgICAgICAgICAgd2lkdGg6NjVweDtcclxuICAgICAgICAgICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxufVxyXG5pb24tZm9vdGVye1xyXG4gICAgbWF4LXdpZHRoOjkyJTtcclxuICAgIG1hcmdpbjowIGF1dG87XHJcbiAgICBtYXJnaW4tYm90dG9tOjFyZW07XHJcbiAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgIHNwYW57XHJcbiAgICAgICAgICAgIG1hcmdpbi1sZWZ0Oi44cmVtO1xyXG5cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "./src/app/order/order.page.ts":
    /*!*************************************!*\
      !*** ./src/app/order/order.page.ts ***!
      \*************************************/

    /*! exports provided: OrderPage */

    /***/
    function srcAppOrderOrderPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "OrderPage", function () {
        return OrderPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_storage_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/storage.service */
      "./src/app/services/storage.service.ts");
      /* harmony import */


      var _angular_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/animations */
      "./node_modules/@angular/animations/__ivy_ngcc__/fesm2015/animations.js");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../environments/environment */
      "./src/environments/environment.ts");
      /* harmony import */


      var _ionic_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/storage */
      "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var ngx_ionic_image_viewer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ngx-ionic-image-viewer */
      "./node_modules/ngx-ionic-image-viewer/__ivy_ngcc__/fesm2015/ngx-ionic-image-viewer.js");
      /* harmony import */


      var _capacitor_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @capacitor/core */
      "./node_modules/@capacitor/core/dist/esm/index.js");
      /* harmony import */


      var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @ngx-translate/core */
      "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");

      var PushNotifications = _capacitor_core__WEBPACK_IMPORTED_MODULE_8__["Plugins"].PushNotifications;
      var _capacitor_core__WEBP = _capacitor_core__WEBPACK_IMPORTED_MODULE_8__["Plugins"],
          Http = _capacitor_core__WEBP.Http,
          Haptics = _capacitor_core__WEBP.Haptics;

      var OrderPage = /*#__PURE__*/function () {
        function OrderPage(loadingController, translate, modalController, alertController, store, storage) {
          _classCallCheck(this, OrderPage);

          this.loadingController = loadingController;
          this.translate = translate;
          this.modalController = modalController;
          this.alertController = alertController;
          this.store = store;
          this.storage = storage;
        }

        _createClass(OrderPage, [{
          key: "presentLoading",
          value: function presentLoading() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _yield$this$loader$on, role, data;

              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.loadingController.create({
                        cssClass: 'my-custom-class',
                        message: this.translate.instant('wait')
                      });

                    case 2:
                      this.loader = _context.sent;
                      _context.next = 5;
                      return this.loader.present();

                    case 5:
                      _context.next = 7;
                      return this.loader.onDidDismiss();

                    case 7:
                      _yield$this$loader$on = _context.sent;
                      role = _yield$this$loader$on.role;
                      data = _yield$this$loader$on.data;
                      console.log('Loading dismissed!');

                    case 11:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "hideLoader",
          value: function hideLoader() {
            if (this.loader != null) {
              this.loader.dismiss();
              this.loader = null;
            }
          }
        }, {
          key: "doRefresh",
          value: function doRefresh(event) {
            this.fetchOrder();
            setTimeout(function () {
              event.target.complete();
            }, 2000);
          }
        }, {
          key: "hapticsNotification",
          value: function hapticsNotification() {
            var type = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _capacitor_core__WEBPACK_IMPORTED_MODULE_8__["HapticsNotificationType"].SUCCESS;

            // Native StatusBar available
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_8__["Capacitor"].getPlatform() != 'web') {
              Haptics.notification({
                type: type
              });
            }
          }
        }, {
          key: "hapticsImpact",
          value: function hapticsImpact() {
            var style = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : _capacitor_core__WEBPACK_IMPORTED_MODULE_8__["HapticsImpactStyle"].Heavy;

            // Native StatusBar available
            if (_capacitor_core__WEBPACK_IMPORTED_MODULE_8__["Capacitor"].getPlatform() != 'web') {
              Haptics.impact({
                style: style
              });
            }
          }
        }, {
          key: "hapticsImpactLight",
          value: function hapticsImpactLight() {
            this.hapticsImpact(_capacitor_core__WEBPACK_IMPORTED_MODULE_8__["HapticsImpactStyle"].Light);
          }
        }, {
          key: "hapticsImpactHeavy",
          value: function hapticsImpactHeavy() {
            this.hapticsImpact(_capacitor_core__WEBPACK_IMPORTED_MODULE_8__["HapticsImpactStyle"].Heavy);
          }
        }, {
          key: "openViewer",
          value: function openViewer(src) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var modal;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.modalController.create({
                        component: ngx_ionic_image_viewer__WEBPACK_IMPORTED_MODULE_7__["ViewerModalComponent"],
                        componentProps: {
                          src: src
                        },
                        cssClass: 'ion-img-viewer',
                        keyboardClose: true,
                        showBackdrop: true
                      });

                    case 2:
                      modal = _context2.sent;
                      _context2.next = 5;
                      return modal.present();

                    case 5:
                      return _context2.abrupt("return", _context2.sent);

                    case 6:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "presentAlert",
          value: function presentAlert(title, body) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var alert;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.alertController.create({
                        cssClass: 'my-custom-class',
                        header: title,
                        message: body,
                        buttons: ['OK']
                      });

                    case 2:
                      alert = _context3.sent;
                      _context3.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "ionViewWillEnter",
          value: function ionViewWillEnter() {
            var _this = this;

            this.fetchOrder();
            var self = this;
            PushNotifications.addListener('pushNotificationActionPerformed', function (notification) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
                var data;
                return regeneratorRuntime.wrap(function _callee4$(_context4) {
                  while (1) {
                    switch (_context4.prev = _context4.next) {
                      case 0:
                        data = notification.notification.data;

                        if (data.role != "Manager") {
                          window.location.reload();
                        }

                      case 2:
                      case "end":
                        return _context4.stop();
                    }
                  }
                }, _callee4);
              }));
            }); // Show us the notification payload if the app is open on our device

            PushNotifications.addListener('pushNotificationReceived', function (notification) {
              _this.hapticsImpactHeavy();

              window.location.reload();
            });
          }
        }, {
          key: "logOut",
          value: function logOut() {
            var _this2 = this;

            this.hapticsImpactLight();
            this.presentLoading();
            this.storage.get('USER_INFO').then(function (res) {
              var doGet = function doGet() {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
                  var ret;
                  return regeneratorRuntime.wrap(function _callee5$(_context5) {
                    while (1) {
                      switch (_context5.prev = _context5.next) {
                        case 0:
                          _context5.next = 2;
                          return Http.request({
                            method: 'POST',
                            url: "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["SERVER_URL"], "/api/users/status"),
                            headers: {
                              'Accept': 'application/json',
                              'Content-Type': 'application/json',
                              'Authorization': 'Bearer ' + res.token
                            },
                            data: {
                              status: "Logged Out"
                            }
                          });

                        case 2:
                          ret = _context5.sent;
                          return _context5.abrupt("return", ret);

                        case 4:
                        case "end":
                          return _context5.stop();
                      }
                    }
                  }, _callee5);
                }));
              };

              doGet().then(function (res) {
                _this2.store.logout();

                _this2.hideLoader();
              });
            }); //  this.route.navigateByUrl('/login');
          }
        }, {
          key: "call",
          value: function call(num) {
            this.hapticsImpactHeavy();
            var tel_number = num;
            window.open("tel:".concat(tel_number), '_system');
          }
        }, {
          key: "confirmStatus",
          value: function confirmStatus(e, status, id) {
            var _this3 = this;

            e.target.setAttribute('disabled', 'disabled');
            this.storage.get('USER_INFO').then(function (res) {
              var doGet = function doGet() {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this3, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
                  var ret;
                  return regeneratorRuntime.wrap(function _callee6$(_context6) {
                    while (1) {
                      switch (_context6.prev = _context6.next) {
                        case 0:
                          _context6.next = 2;
                          return Http.request({
                            method: 'POST',
                            url: "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["SERVER_URL"], "/api/orders/status/").concat(id),
                            headers: {
                              'Accept': 'application/json',
                              'Content-Type': 'application/json',
                              'Authorization': 'Bearer ' + res.token
                            },
                            data: {
                              status: status
                            }
                          });

                        case 2:
                          ret = _context6.sent;
                          console.log(ret);
                          return _context6.abrupt("return", ret);

                        case 5:
                        case "end":
                          return _context6.stop();
                      }
                    }
                  }, _callee6);
                }));
              };

              doGet().then(function (res) {
                if (res) {
                  if (status == 'Shipped') {
                    e.target.innerHTML = "<ion-icon name=\"paper-plane-sharp\"></ion-icon> <span>".concat(_this3.translate.instant('ORDER.shipped'), "</span>");
                    e.target.removeAttribute('disabled');
                  } else {
                    e.target.innerHTML = "<ion-icon name=\"checkmark-done-outline\"></ion-icon> <span>".concat(_this3.translate.instant('ORDER.delivered'), "</span>");
                    e.target.removeAttribute('disabled');
                  }
                }

                if (res.data) {
                  _this3.order = res.data;
                } else {
                  _this3.order = false;
                }
              });
            });
          }
        }, {
          key: "updateStatus",
          value: function updateStatus(e, status, id) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
              var _this4 = this;

              var msg, alert;
              return regeneratorRuntime.wrap(function _callee7$(_context7) {
                while (1) {
                  switch (_context7.prev = _context7.next) {
                    case 0:
                      this.hapticsImpactLight();
                      msg = "";

                      if (status == "Shipped") {
                        msg = this.translate.instant('ALERTS.shipped');
                      } else if (status == "Delivered") {
                        msg = this.translate.instant('ALERTS.delivered');
                      }

                      _context7.next = 5;
                      return this.alertController.create({
                        cssClass: 'my-custom-class',
                        header: this.translate.instant('ALERTS.title'),
                        message: msg,
                        buttons: [{
                          text: this.translate.instant('ALERTS.cancel'),
                          role: 'cancel',
                          cssClass: 'secondary',
                          handler: function handler(blah) {
                            console.log('Confirm Cancel: blah');
                          }
                        }, {
                          text: this.translate.instant('ALERTS.confirm'),
                          handler: function handler() {
                            _this4.hapticsImpactLight();

                            _this4.confirmStatus(e, status, id);
                          }
                        }]
                      });

                    case 5:
                      alert = _context7.sent;
                      _context7.next = 8;
                      return alert.present();

                    case 8:
                    case "end":
                      return _context7.stop();
                  }
                }
              }, _callee7, this);
            }));
          }
        }, {
          key: "pushOrder",
          value: function pushOrder() {
            var _this5 = this;

            this.storage.get('USER_INFO').then(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this5, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
                var ret;
                return regeneratorRuntime.wrap(function _callee8$(_context8) {
                  while (1) {
                    switch (_context8.prev = _context8.next) {
                      case 0:
                        _context8.next = 2;
                        return Http.request({
                          method: 'GET',
                          url: "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["SERVER_URL"], "/api/orders/user/").concat(res.user.id),
                          headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + res.token
                          }
                        });

                      case 2:
                        ret = _context8.sent;
                        this.order = ret.data;
                        console.log(this.order);
                        return _context8.abrupt("return", ret);

                      case 6:
                      case "end":
                        return _context8.stop();
                    }
                  }
                }, _callee8, this);
              }));
            });
          }
        }, {
          key: "fetchOrder",
          value: function fetchOrder() {
            var _this6 = this;

            this.storage.get('USER_INFO').then(function (res) {
              var doGet = function doGet() {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this6, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
                  var ret;
                  return regeneratorRuntime.wrap(function _callee9$(_context9) {
                    while (1) {
                      switch (_context9.prev = _context9.next) {
                        case 0:
                          _context9.next = 2;
                          return Http.request({
                            method: 'GET',
                            url: "".concat(_environments_environment__WEBPACK_IMPORTED_MODULE_4__["SERVER_URL"], "/api/orders/user/").concat(res.user.id),
                            headers: {
                              'Accept': 'application/json',
                              'Content-Type': 'application/json',
                              'Authorization': 'Bearer ' + res.token
                            }
                          });

                        case 2:
                          ret = _context9.sent;
                          return _context9.abrupt("return", ret);

                        case 4:
                        case "end":
                          return _context9.stop();
                      }
                    }
                  }, _callee9);
                }));
              };

              doGet().then(function (res) {
                if (res.data) {
                  _this6.hapticsNotification(_capacitor_core__WEBPACK_IMPORTED_MODULE_8__["HapticsNotificationType"].SUCCESS);

                  var audio = new Audio('/assets/sound.mp3');
                  audio.play();
                  _this6.order = res.data;
                  console.log(_this6.order);
                } else {
                  _this6.order = false;
                }
              });
            });
          }
        }]);

        return OrderPage;
      }();

      OrderPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"]
        }, {
          type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__["TranslateService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"]
        }, {
          type: _services_storage_service__WEBPACK_IMPORTED_MODULE_2__["StorageService"]
        }, {
          type: _ionic_storage__WEBPACK_IMPORTED_MODULE_5__["Storage"]
        }];
      };

      OrderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-order',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./order.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/order/order.page.html"))["default"],
        animations: [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["trigger"])('inOutAnimation', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["transition"])(':enter', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["style"])({
          opacity: 0
        }), Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["animate"])('.3s ease-out', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["style"])({
          opacity: 1
        }))]), Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["transition"])(':leave', [Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["style"])({
          opacity: 1
        }), Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["animate"])('.3s ease-in', Object(_angular_animations__WEBPACK_IMPORTED_MODULE_3__["style"])({
          opacity: 0
        }))])])],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./order.page.scss */
        "./src/app/order/order.page.scss"))["default"]]
      })], OrderPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=order-order-module-es5.js.map