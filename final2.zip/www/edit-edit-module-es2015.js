(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-edit-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/pilots/edit/edit.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/settings/pilots/edit/edit.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{'SETTINGS.PILOTS.edit' | translate}}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"edit()\">{{'done' | translate}}</ion-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<div class=\"create\">\n<ion-text color=\"medium\">\n  <h6>{{'SETTINGS.PILOTS.INPUTS.photo' | translate}}</h6>\n</ion-text>\n<div class=\"photo\">\n<div class=\"image\" *ngIf=\"!pilot.image\" (click)=\"openCamera()\">\n\n\n  <svg width=\"160\" height=\"160\" viewBox=\"0 0 160 160\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n    <rect width=\"160\" height=\"160\" rx=\"80\" fill=\"#F2F2F2\"/>\n    <path d=\"M68.2757 93H91.7243C94.5702 93 96 91.5821 96 88.7735V74.4987C96 71.6901 94.5702 70.2858 91.7243 70.2858H88.5515C87.4894 70.2858 87.1489 70.0676 86.5498 69.3859L85.4468 68.1589C84.766 67.409 84.0715 67 82.6689 67H77.2357C75.8332 67 75.1387 67.409 74.4579 68.1589L73.3685 69.3859C72.7694 70.054 72.4289 70.2858 71.3668 70.2858H68.2757C65.4298 70.2858 64 71.6901 64 74.4987V88.7735C64 91.5821 65.4298 93 68.2757 93ZM80 88.6371C75.8877 88.6371 72.5787 85.3241 72.5787 81.1793C72.5787 77.0346 75.8877 73.7216 80 73.7216C84.126 73.7216 87.4349 77.0346 87.4349 81.1793C87.4349 85.3241 84.126 88.6371 80 88.6371ZM89.7906 77.8526C88.8647 77.8526 88.1021 77.1028 88.1021 76.1757C88.1021 75.2349 88.8647 74.4851 89.7906 74.4851C90.7166 74.4851 91.4791 75.2349 91.4791 76.1757C91.4791 77.1028 90.7166 77.8526 89.7906 77.8526ZM80 86.5648C82.9685 86.5648 85.3787 84.1652 85.3787 81.1793C85.3787 78.1935 82.9685 75.7939 80 75.7939C77.0315 75.7939 74.6349 78.1935 74.6349 81.1793C74.6349 84.1652 77.0451 86.5648 80 86.5648Z\" fill=\"#BDBDBD\"/>\n    </svg>\n    \n\n</div>\n<div class=\"image\" style=\"text-align: center;\" *ngIf=\"pilot.image\" (click)=\"openViewer(pilot.image)\">\n<img style=\"width:160px;display:inline-block;height:160px;object-fit: cover;border-radius: 100px;\" [src]=\"pilot.image\">\n\n</div>\n</div>\n\n<div class=\"buttons\">\n<ion-button color=\"primary\" expand=\"block\" (click)=\"openCamera()\" fill=\"solid\">{{'SETTINGS.PILOTS.INPUTS.upload' | translate}}</ion-button>\n<!-- <ion-button color=\"danger\" expand=\"block\"  fill=\"outline\">Delete Photo</ion-button> -->\n\n</div>\n\n\n\n  \n</div>\n<div class=\"form\">\n  <ion-item lines=\"none\">\n    <ion-label color=\"medium\"  position=\"stacked\">{{'SETTINGS.PILOTS.INPUTS.name' | translate}}</ion-label>\n    <ion-input placeholder=\"{{'SETTINGS.PILOTS.INPUTS.name_placeholder' | translate}}\" autofocus=\"true\" [(ngModel)]=\"pilot.name\" name=\"name\"></ion-input>\n    <span class=\"error\" *ngIf=\"errors.length!=0 && errors.name\">{{errors.name[0]}}</span>\n\n  </ion-item>\n  <ion-item lines=\"none\">\n    <ion-label color=\"medium\"  position=\"stacked\">{{'SETTINGS.PILOTS.INPUTS.phone' | translate}}</ion-label>\n    <ion-input placeholder=\"{{'SETTINGS.PILOTS.INPUTS.phone_placeholder' | translate}}\" [(ngModel)]=\"pilot.phone\" name=\"phone\"></ion-input>\n    <span class=\"error\" *ngIf=\"errors.length!=0 && errors.phone\">{{errors.phone[0]}}</span>\n\n  </ion-item>\n  <ion-item lines=\"none\">\n    <ion-label color=\"medium\" position=\"stacked\">{{'SETTINGS.PILOTS.INPUTS.loginId' | translate}}</ion-label>\n    <ion-input placeholder=\"{{'SETTINGS.PILOTS.INPUTS.loginId_placeholder' | translate}}\"   [(ngModel)]=\"pilot.login_id\" name=\"loginId\"></ion-input>\n    <span class=\"error\" *ngIf=\"errors.length!=0 && errors.login_id\">{{errors.login_id[0]}}</span>\n\n  </ion-item>\n \n\n\n\n\n</div>\n\n\n</ion-content>\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/vehicles/edit/edit.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/settings/vehicles/edit/edit.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/home\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{'SETTINGS.VEHICLES.edit' | translate}}</ion-title>\n    <ion-buttons slot=\"end\">\n      <ion-button (click)=\"edit()\">{{'done' | translate}}</ion-button>\n    </ion-buttons>\n\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n<div class=\"create\">\n<ion-text color=\"medium\">\n  <h6>{{'SETTINGS.VEHICLES.INPUTS.photo' | translate}}</h6>\n</ion-text>\n<div class=\"photo\">\n<div class=\"image\" *ngIf=\"!vehicle.image\" (click)=\"openCamera()\">\n\n\n  <svg width=\"160\" height=\"160\" viewBox=\"0 0 160 160\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n    <rect width=\"160\" height=\"160\" rx=\"80\" fill=\"#F2F2F2\"/>\n    <path d=\"M68.2757 93H91.7243C94.5702 93 96 91.5821 96 88.7735V74.4987C96 71.6901 94.5702 70.2858 91.7243 70.2858H88.5515C87.4894 70.2858 87.1489 70.0676 86.5498 69.3859L85.4468 68.1589C84.766 67.409 84.0715 67 82.6689 67H77.2357C75.8332 67 75.1387 67.409 74.4579 68.1589L73.3685 69.3859C72.7694 70.054 72.4289 70.2858 71.3668 70.2858H68.2757C65.4298 70.2858 64 71.6901 64 74.4987V88.7735C64 91.5821 65.4298 93 68.2757 93ZM80 88.6371C75.8877 88.6371 72.5787 85.3241 72.5787 81.1793C72.5787 77.0346 75.8877 73.7216 80 73.7216C84.126 73.7216 87.4349 77.0346 87.4349 81.1793C87.4349 85.3241 84.126 88.6371 80 88.6371ZM89.7906 77.8526C88.8647 77.8526 88.1021 77.1028 88.1021 76.1757C88.1021 75.2349 88.8647 74.4851 89.7906 74.4851C90.7166 74.4851 91.4791 75.2349 91.4791 76.1757C91.4791 77.1028 90.7166 77.8526 89.7906 77.8526ZM80 86.5648C82.9685 86.5648 85.3787 84.1652 85.3787 81.1793C85.3787 78.1935 82.9685 75.7939 80 75.7939C77.0315 75.7939 74.6349 78.1935 74.6349 81.1793C74.6349 84.1652 77.0451 86.5648 80 86.5648Z\" fill=\"#BDBDBD\"/>\n    </svg>\n    \n\n</div>\n<div class=\"image\" style=\"text-align: center;\" *ngIf=\"vehicle.image\" >\n<img style=\"width:160px;display:inline-block;height:160px;object-fit: cover;border-radius: 100px;\" [src]=\"vehicle.image\">\n\n</div>\n</div>\n\n<div class=\"buttons\">\n<ion-button color=\"primary\" expand=\"block\" (click)=\"openCamera()\" fill=\"solid\">{{'SETTINGS.VEHICLES.INPUTS.upload' | translate}}</ion-button>\n<!-- <ion-button color=\"danger\" expand=\"block\"  fill=\"outline\">Delete Photo</ion-button> -->\n\n</div>\n\n\n\n  \n</div>\n<div class=\"form\">\n  <ion-item lines=\"none\">\n    <ion-label color=\"medium\"  position=\"stacked\">{{'SETTINGS.VEHICLES.INPUTS.name' | translate}}</ion-label>\n    <ion-input placeholder=\"{{'SETTINGS.VEHICLES.INPUTS.name_placeholder' | translate}}\" autofocus=\"true\" [(ngModel)]=\"vehicle.name\" name=\"name\"></ion-input>\n    <span class=\"error\" *ngIf=\"errors.length!=0 && errors.name\">{{errors.name[0]}}</span>\n\n  </ion-item>\n\n\n \n\n\n\n\n</div>\n\n\n</ion-content>\n\n");

/***/ }),

/***/ "./src/app/settings/pilots/edit/edit-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/settings/pilots/edit/edit-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: EditPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditPageRoutingModule", function() { return EditPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _edit_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit.page */ "./src/app/settings/pilots/edit/edit.page.ts");




const routes = [
    {
        path: '',
        component: _edit_page__WEBPACK_IMPORTED_MODULE_3__["EditPage"]
    }
];
let EditPageRoutingModule = class EditPageRoutingModule {
};
EditPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditPageRoutingModule);



/***/ }),

/***/ "./src/app/settings/pilots/edit/edit.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/settings/pilots/edit/edit.module.ts ***!
  \*****************************************************/
/*! exports provided: EditPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditPageModule", function() { return EditPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _edit_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./edit-routing.module */ "./src/app/settings/pilots/edit/edit-routing.module.ts");
/* harmony import */ var _edit_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit.page */ "./src/app/settings/pilots/edit/edit.page.ts");
/* harmony import */ var ngx_ionic_image_viewer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-ionic-image-viewer */ "./node_modules/ngx-ionic-image-viewer/__ivy_ngcc__/fesm2015/ngx-ionic-image-viewer.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");








 // add this
let EditPageModule = class EditPageModule {
};
EditPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _edit_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditPageRoutingModule"],
            ngx_ionic_image_viewer__WEBPACK_IMPORTED_MODULE_7__["NgxIonicImageViewerModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"]
        ],
        declarations: [_edit_page__WEBPACK_IMPORTED_MODULE_6__["EditPage"]]
    })
], EditPageModule);



/***/ }),

/***/ "./src/app/settings/pilots/edit/edit.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/settings/pilots/edit/edit.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".create {\n  max-width: 90%;\n  margin: 1.8rem auto;\n  text-transform: uppercase;\n}\n.create ion-text h6 {\n  font-weight: 400;\n  font-size: 0.8125rem;\n}\n.create .photo {\n  width: 100%;\n  margin: 0 auto;\n  text-align: center;\n}\n.create .buttons {\n  display: flex;\n  margin-top: 1.6rem;\n}\n.create .buttons ion-button {\n  text-transform: none;\n  width: 100%;\n  --font-size:rem(16px);\n  font-weight: 500;\n  --padding-top:1rem;\n  --padding-bottom:1rem;\n}\n.form {\n  max-width: 90%;\n  margin: 0 auto;\n}\n.form ion-item {\n  margin-top: 0.7rem;\n  --padding-start: 0;\n  --padding-end: 0;\n  --inner-padding-end: 0;\n}\n.form ion-item ion-label {\n  text-transform: uppercase;\n  padding-left: 0.5rem;\n  font-weight: 400;\n  font-size: 0.8rem;\n}\n.form ion-item ion-input, .form ion-item ion-textarea {\n  --padding-end:.5rem;\n  --padding-start:.5rem;\n  border: 1px solid var(--ion-color-medium-shade);\n  border-radius: 6px;\n  --padding-top:.8rem;\n  --padding-bottom:.8rem;\n  background: var(--ion-color-medium-tint);\n  transition: 0.3s ease-in;\n}\n.form ion-item ion-input:focus, .form ion-item ion-textarea:focus {\n  border: 1px solid var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2V0dGluZ3MvcGlsb3RzL2VkaXQvZWRpdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBSUE7RUFDSSxjQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtBQUhKO0FBTVc7RUFDQyxnQkFBQTtFQUNBLG9CQUFBO0FBSlo7QUFRSTtFQUNJLFdBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFOUjtBQVFJO0VBQ0ksYUFBQTtFQUNBLGtCQUFBO0FBTlI7QUFPUTtFQUNJLG9CQUFBO0VBQ0EsV0FBQTtFQUNBLHFCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLHFCQUFBO0FBTFo7QUFVQTtFQUNJLGNBQUE7RUFDQSxjQUFBO0FBUEo7QUFRSTtFQUNJLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLHNCQUFBO0FBTlI7QUFRRztFQUNJLHlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FBTlA7QUFTRztFQUNDLG1CQUFBO0VBQ0EscUJBQUE7RUFFRywrQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxzQkFBQTtFQUNBLHdDQUFBO0VBQ0Esd0JBQUE7QUFSUDtBQVNPO0VBQ0MsMENBQUE7QUFQUiIsImZpbGUiOiJzcmMvYXBwL3NldHRpbmdzL3BpbG90cy9lZGl0L2VkaXQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbkBmdW5jdGlvbiByZW0oJHNpemUpIHtcclxuICAgIEByZXR1cm4gJHNpemUgLyAxNnB4ICogMXJlbTtcclxuICB9XHJcbi5jcmVhdGV7XHJcbiAgICBtYXgtd2lkdGg6OTAlO1xyXG4gICAgbWFyZ2luOjEuOHJlbSBhdXRvO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgIGlvbi10ZXh0e1xyXG4gXHJcbiAgICAgICAgICAgaDZ7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA0MDA7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTpyZW0oMTNweCk7XHJcbiAgICAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC5waG90b3tcclxuICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgIG1hcmdpbjowIGF1dG87XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLmJ1dHRvbnN7XHJcbiAgICAgICAgZGlzcGxheTpmbGV4O1xyXG4gICAgICAgIG1hcmdpbi10b3A6MS42cmVtO1xyXG4gICAgICAgIGlvbi1idXR0b257XHJcbiAgICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xyXG4gICAgICAgICAgICB3aWR0aDoxMDAlO1xyXG4gICAgICAgICAgICAtLWZvbnQtc2l6ZTpyZW0oMTZweCk7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OjUwMDtcclxuICAgICAgICAgICAgLS1wYWRkaW5nLXRvcDoxcmVtO1xyXG4gICAgICAgICAgICAtLXBhZGRpbmctYm90dG9tOjFyZW07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcblxyXG4uZm9ybXtcclxuICAgIG1heC13aWR0aDo5MCU7XHJcbiAgICBtYXJnaW46MCBhdXRvO1xyXG4gICAgaW9uLWl0ZW17XHJcbiAgICAgICAgbWFyZ2luLXRvcDouN3JlbTtcclxuICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDA7XHJcbiAgICAgICAgLS1wYWRkaW5nLWVuZDogMDtcclxuICAgICAgICAtLWlubmVyLXBhZGRpbmctZW5kOiAwO1xyXG5cclxuICAgaW9uLWxhYmVse1xyXG4gICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgIHBhZGRpbmctbGVmdDouNXJlbTtcclxuICAgICAgIGZvbnQtd2VpZ2h0OjQwMDtcclxuICAgICAgIGZvbnQtc2l6ZTouOHJlbTtcclxuXHJcbiAgIH1cclxuICAgaW9uLWlucHV0LGlvbi10ZXh0YXJlYXtcclxuICAgIC0tcGFkZGluZy1lbmQ6LjVyZW07XHJcbiAgICAtLXBhZGRpbmctc3RhcnQ6LjVyZW07XHJcblxyXG4gICAgICAgYm9yZGVyOjFweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItbWVkaXVtLXNoYWRlKTtcclxuICAgICAgIGJvcmRlci1yYWRpdXM6NnB4O1xyXG4gICAgICAgLS1wYWRkaW5nLXRvcDouOHJlbTtcclxuICAgICAgIC0tcGFkZGluZy1ib3R0b206LjhyZW07XHJcbiAgICAgICBiYWNrZ3JvdW5kOnZhcigtLWlvbi1jb2xvci1tZWRpdW0tdGludCk7XHJcbiAgICAgICB0cmFuc2l0aW9uOi4zcyBlYXNlLWluO1xyXG4gICAgICAgJjpmb2N1c3tcclxuICAgICAgICBib3JkZXI6MXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuXHJcbiAgICAgICB9XHJcbiAgICAgICAgICAgICAgIH1cclxuICAgIH1cclxuXHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/settings/pilots/edit/edit.page.ts":
/*!***************************************************!*\
  !*** ./src/app/settings/pilots/edit/edit.page.ts ***!
  \***************************************************/
/*! exports provided: EditPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditPage", function() { return EditPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _services_photo_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/photo.service */ "./src/app/services/photo.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _capacitor_community_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor-community/http */ "./node_modules/@capacitor-community/http/dist/esm/index.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");
/* harmony import */ var ngx_ionic_image_viewer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ngx-ionic-image-viewer */ "./node_modules/ngx-ionic-image-viewer/__ivy_ngcc__/fesm2015/ngx-ionic-image-viewer.js");












const { Haptics, Http } = _capacitor_core__WEBPACK_IMPORTED_MODULE_10__["Plugins"];
let EditPage = class EditPage {
    constructor(translate, modalController, router, active, storage, loadingController, sanitizer, photo) {
        this.translate = translate;
        this.modalController = modalController;
        this.router = router;
        this.active = active;
        this.storage = storage;
        this.loadingController = loadingController;
        this.sanitizer = sanitizer;
        this.photo = photo;
        this.errors = [];
        this.pilot = { image: '' };
    }
    hapticsImpact(style = _capacitor_core__WEBPACK_IMPORTED_MODULE_10__["HapticsImpactStyle"].Heavy) {
        // Native StatusBar available
        if (_capacitor_core__WEBPACK_IMPORTED_MODULE_10__["Capacitor"].getPlatform() != 'web') {
            Haptics.impact({
                style: style
            });
        }
    }
    hapticsImpactLight() {
        this.hapticsImpact(_capacitor_core__WEBPACK_IMPORTED_MODULE_10__["HapticsImpactStyle"].Light);
    }
    ionViewWillEnter() {
        this.presentLoading();
        const id = this.active.snapshot.paramMap.get('id');
        this.pilotId = id;
        this.fetchPilot(id);
    }
    fetchPilot(id) {
        this.storage.get('USER_INFO').then(res => {
            const doGet = () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                const ret = yield Http.request({
                    method: 'GET',
                    url: `${_environments_environment__WEBPACK_IMPORTED_MODULE_7__["SERVER_URL"]}/api/users/${id}`,
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res.token
                    }
                });
                return ret;
            });
            doGet().then(res => {
                this.pilot = res['data'];
                this.hideLoader();
            });
        });
    }
    openViewer(src) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: ngx_ionic_image_viewer__WEBPACK_IMPORTED_MODULE_11__["ViewerModalComponent"],
                componentProps: {
                    src: src
                },
                cssClass: 'ion-img-viewer',
                keyboardClose: true,
                showBackdrop: true
            });
            return yield modal.present();
        });
    }
    openCamera() {
        this.photo.takePicture().then(res => {
            console.log(res);
            this.pilot.image = this.sanitizer.bypassSecurityTrustUrl("data:image/png;base64," + res.url);
            this.file = res.upload;
            this.format = res.format;
        });
    }
    presentLoading() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.loader = yield this.loadingController.create({
                cssClass: 'my-custom-class',
                message: this.translate.instant('wait'),
            });
            yield this.loader.present();
            const { role, data } = yield this.loader.onDidDismiss();
            console.log('Loading dismissed!');
        });
    }
    edit() {
        this.errors = [];
        this.hapticsImpactLight();
        this.presentLoading();
        let data;
        if (this.file) {
            data = {
                name: this.pilot.name,
                phone: this.pilot.phone,
                file: this.file,
                format: this.format,
                login_id: this.pilot.login_id,
            };
        }
        else {
            data = {
                name: this.pilot.name,
                phone: this.pilot.phone,
                login_id: this.pilot.login_id,
            };
        }
        this.storage.get('USER_INFO').then(res => {
            const doPost = () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                const ret = yield Http.request({
                    method: 'POST',
                    url: `${_environments_environment__WEBPACK_IMPORTED_MODULE_7__["SERVER_URL"]}/api/users/update/${this.pilotId}`,
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res.token
                    },
                    data: data
                });
                return ret;
            });
            doPost().then(res => {
                this.hideLoader();
                if (res['status'] == 200) {
                    let navigationExtras = {
                        queryParams: {
                            reload: true,
                        }
                    };
                    this.router.navigate(["/settings/pilots"], navigationExtras);
                }
                else if (res['status'] == 422) {
                    this.errors = res['data']['errors'];
                    console.log(this.errors);
                }
                // this.pilots = res['data'];
                //   this.loading = false;
            });
        });
    }
    hideLoader() {
        if (this.loader != null) {
            this.loader.dismiss();
            this.loader = null;
        }
    }
};
EditPage.ctorParameters = () => [
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__["TranslateService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"] },
    { type: _services_photo_service__WEBPACK_IMPORTED_MODULE_3__["PhotoService"] }
];
EditPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-edit',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./edit.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/pilots/edit/edit.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./edit.page.scss */ "./src/app/settings/pilots/edit/edit.page.scss")).default]
    })
], EditPage);



/***/ }),

/***/ "./src/app/settings/vehicles/edit/edit-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/settings/vehicles/edit/edit-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: EditPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditPageRoutingModule", function() { return EditPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _edit_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit.page */ "./src/app/settings/vehicles/edit/edit.page.ts");




const routes = [
    {
        path: '',
        component: _edit_page__WEBPACK_IMPORTED_MODULE_3__["EditPage"]
    }
];
let EditPageRoutingModule = class EditPageRoutingModule {
};
EditPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditPageRoutingModule);



/***/ }),

/***/ "./src/app/settings/vehicles/edit/edit.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/settings/vehicles/edit/edit.module.ts ***!
  \*******************************************************/
/*! exports provided: EditPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditPageModule", function() { return EditPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _edit_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./edit-routing.module */ "./src/app/settings/vehicles/edit/edit-routing.module.ts");
/* harmony import */ var _edit_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit.page */ "./src/app/settings/vehicles/edit/edit.page.ts");
/* harmony import */ var ngx_ionic_image_viewer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ngx-ionic-image-viewer */ "./node_modules/ngx-ionic-image-viewer/__ivy_ngcc__/fesm2015/ngx-ionic-image-viewer.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");








 // add this
let EditPageModule = class EditPageModule {
};
EditPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _edit_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditPageRoutingModule"],
            ngx_ionic_image_viewer__WEBPACK_IMPORTED_MODULE_7__["NgxIonicImageViewerModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_8__["TranslateModule"]
        ],
        declarations: [_edit_page__WEBPACK_IMPORTED_MODULE_6__["EditPage"]]
    })
], EditPageModule);



/***/ }),

/***/ "./src/app/settings/vehicles/edit/edit.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/settings/vehicles/edit/edit.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".create {\n  max-width: 90%;\n  margin: 1.8rem auto;\n  text-transform: uppercase;\n}\n.create ion-text h6 {\n  font-weight: 400;\n  font-size: 0.8125rem;\n}\n.create .photo {\n  width: 100%;\n  margin: 0 auto;\n  text-align: center;\n}\n.create .buttons {\n  display: flex;\n  margin-top: 1.6rem;\n}\n.create .buttons ion-button {\n  text-transform: none;\n  width: 100%;\n  --font-size:rem(16px);\n  font-weight: 500;\n  --padding-top:1rem;\n  --padding-bottom:1rem;\n}\n.form {\n  max-width: 90%;\n  margin: 0 auto;\n}\n.form ion-item {\n  margin-top: 0.7rem;\n  --padding-start: 0;\n  --padding-end: 0;\n  --inner-padding-end: 0;\n}\n.form ion-item ion-label {\n  text-transform: uppercase;\n  padding-left: 0.5rem;\n  font-weight: 400;\n  font-size: 0.8rem;\n}\n.form ion-item ion-input, .form ion-item ion-textarea {\n  --padding-end:.5rem;\n  --padding-start:.5rem;\n  border: 1px solid var(--ion-color-medium-shade);\n  border-radius: 6px;\n  --padding-top:.8rem;\n  --padding-bottom:.8rem;\n  background: var(--ion-color-medium-tint);\n  transition: 0.3s ease-in;\n}\n.form ion-item ion-input:focus, .form ion-item ion-textarea:focus {\n  border: 1px solid var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2V0dGluZ3MvdmVoaWNsZXMvZWRpdC9lZGl0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJQTtFQUNJLGNBQUE7RUFDQSxtQkFBQTtFQUNBLHlCQUFBO0FBSEo7QUFNVztFQUNDLGdCQUFBO0VBQ0Esb0JBQUE7QUFKWjtBQVFJO0VBQ0ksV0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQU5SO0FBUUk7RUFDSSxhQUFBO0VBQ0Esa0JBQUE7QUFOUjtBQU9RO0VBQ0ksb0JBQUE7RUFDQSxXQUFBO0VBQ0EscUJBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7QUFMWjtBQVVBO0VBQ0ksY0FBQTtFQUNBLGNBQUE7QUFQSjtBQVFJO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esc0JBQUE7QUFOUjtBQVFHO0VBQ0kseUJBQUE7RUFDQSxvQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFOUDtBQVNHO0VBQ0MsbUJBQUE7RUFDQSxxQkFBQTtFQUVHLCtDQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLHNCQUFBO0VBQ0Esd0NBQUE7RUFDQSx3QkFBQTtBQVJQO0FBU087RUFDQywwQ0FBQTtBQVBSIiwiZmlsZSI6InNyYy9hcHAvc2V0dGluZ3MvdmVoaWNsZXMvZWRpdC9lZGl0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5AZnVuY3Rpb24gcmVtKCRzaXplKSB7XHJcbiAgICBAcmV0dXJuICRzaXplIC8gMTZweCAqIDFyZW07XHJcbiAgfVxyXG4uY3JlYXRle1xyXG4gICAgbWF4LXdpZHRoOjkwJTtcclxuICAgIG1hcmdpbjoxLjhyZW0gYXV0bztcclxuICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICBpb24tdGV4dHtcclxuIFxyXG4gICAgICAgICAgIGg2e1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgICAgICAgICBmb250LXNpemU6cmVtKDEzcHgpO1xyXG4gICAgICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAucGhvdG97XHJcbiAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICBtYXJnaW46MCBhdXRvO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIH1cclxuICAgIC5idXR0b25ze1xyXG4gICAgICAgIGRpc3BsYXk6ZmxleDtcclxuICAgICAgICBtYXJnaW4tdG9wOjEuNnJlbTtcclxuICAgICAgICBpb24tYnV0dG9ue1xyXG4gICAgICAgICAgICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcclxuICAgICAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgICAgICAgLS1mb250LXNpemU6cmVtKDE2cHgpO1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDo1MDA7XHJcbiAgICAgICAgICAgIC0tcGFkZGluZy10b3A6MXJlbTtcclxuICAgICAgICAgICAgLS1wYWRkaW5nLWJvdHRvbToxcmVtO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5cclxuLmZvcm17XHJcbiAgICBtYXgtd2lkdGg6OTAlO1xyXG4gICAgbWFyZ2luOjAgYXV0bztcclxuICAgIGlvbi1pdGVte1xyXG4gICAgICAgIG1hcmdpbi10b3A6LjdyZW07XHJcbiAgICAgICAgLS1wYWRkaW5nLXN0YXJ0OiAwO1xyXG4gICAgICAgIC0tcGFkZGluZy1lbmQ6IDA7XHJcbiAgICAgICAgLS1pbm5lci1wYWRkaW5nLWVuZDogMDtcclxuXHJcbiAgIGlvbi1sYWJlbHtcclxuICAgICAgIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcbiAgICAgICBwYWRkaW5nLWxlZnQ6LjVyZW07XHJcbiAgICAgICBmb250LXdlaWdodDo0MDA7XHJcbiAgICAgICBmb250LXNpemU6LjhyZW07XHJcblxyXG4gICB9XHJcbiAgIGlvbi1pbnB1dCxpb24tdGV4dGFyZWF7XHJcbiAgICAtLXBhZGRpbmctZW5kOi41cmVtO1xyXG4gICAgLS1wYWRkaW5nLXN0YXJ0Oi41cmVtO1xyXG5cclxuICAgICAgIGJvcmRlcjoxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLW1lZGl1bS1zaGFkZSk7XHJcbiAgICAgICBib3JkZXItcmFkaXVzOjZweDtcclxuICAgICAgIC0tcGFkZGluZy10b3A6LjhyZW07XHJcbiAgICAgICAtLXBhZGRpbmctYm90dG9tOi44cmVtO1xyXG4gICAgICAgYmFja2dyb3VuZDp2YXIoLS1pb24tY29sb3ItbWVkaXVtLXRpbnQpO1xyXG4gICAgICAgdHJhbnNpdGlvbjouM3MgZWFzZS1pbjtcclxuICAgICAgICY6Zm9jdXN7XHJcbiAgICAgICAgYm9yZGVyOjFweCBzb2xpZCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcblxyXG4gICAgICAgfVxyXG4gICAgICAgICAgICAgICB9XHJcbiAgICB9XHJcblxyXG59Il19 */");

/***/ }),

/***/ "./src/app/settings/vehicles/edit/edit.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/settings/vehicles/edit/edit.page.ts ***!
  \*****************************************************/
/*! exports provided: EditPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditPage", function() { return EditPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _services_photo_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../services/photo.service */ "./src/app/services/photo.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _capacitor_community_http__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @capacitor-community/http */ "./node_modules/@capacitor-community/http/dist/esm/index.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../../../environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/__ivy_ngcc__/fesm2015/ngx-translate-core.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");











const { Haptics, Http } = _capacitor_core__WEBPACK_IMPORTED_MODULE_10__["Plugins"];
let EditPage = class EditPage {
    constructor(translate, router, active, storage, loadingController, sanitizer, photo) {
        this.translate = translate;
        this.router = router;
        this.active = active;
        this.storage = storage;
        this.loadingController = loadingController;
        this.sanitizer = sanitizer;
        this.photo = photo;
        this.errors = [];
        this.vehicle = { image: '' };
    }
    hapticsImpact(style = _capacitor_core__WEBPACK_IMPORTED_MODULE_10__["HapticsImpactStyle"].Heavy) {
        // Native StatusBar available
        if (_capacitor_core__WEBPACK_IMPORTED_MODULE_10__["Capacitor"].getPlatform() != 'web') {
            Haptics.impact({
                style: style
            });
        }
    }
    hapticsImpactLight() {
        this.hapticsImpact(_capacitor_core__WEBPACK_IMPORTED_MODULE_10__["HapticsImpactStyle"].Light);
    }
    ionViewWillEnter() {
        this.presentLoading();
        const id = this.active.snapshot.paramMap.get('id');
        this.vehicleId = id;
        this.fetchVehicle(id);
    }
    fetchVehicle(id) {
        this.storage.get('USER_INFO').then(res => {
            const doGet = () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                const ret = yield Http.request({
                    method: 'GET',
                    url: `${_environments_environment__WEBPACK_IMPORTED_MODULE_7__["SERVER_URL"]}/api/vehicles/${id}`,
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res.token
                    }
                });
                return ret;
            });
            doGet().then(res => {
                this.vehicle = res['data'];
                this.hideLoader();
            });
        });
    }
    openCamera() {
        this.photo.takePicture().then(res => {
            console.log(res);
            this.vehicle.image = this.sanitizer.bypassSecurityTrustUrl("data:image/png;base64," + res.url);
            this.file = res.upload;
            this.format = res.format;
        });
    }
    presentLoading() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.loader = yield this.loadingController.create({
                cssClass: 'my-custom-class',
                message: this.translate.instant('wait'),
            });
            yield this.loader.present();
            const { role, data } = yield this.loader.onDidDismiss();
            console.log('Loading dismissed!');
        });
    }
    edit() {
        this.errors = [];
        this.hapticsImpactLight();
        this.presentLoading();
        let data;
        if (this.file) {
            data = {
                name: this.vehicle.name,
                file: this.file,
                format: this.format,
            };
        }
        else {
            data = {
                name: this.vehicle.name,
            };
        }
        this.storage.get('USER_INFO').then(res => {
            const doPost = () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                const ret = yield Http.request({
                    method: 'POST',
                    url: `${_environments_environment__WEBPACK_IMPORTED_MODULE_7__["SERVER_URL"]}/api/vehicles/update/${this.vehicleId}`,
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                        'Authorization': 'Bearer ' + res.token
                    },
                    data: data
                });
                return ret;
            });
            doPost().then(res => {
                this.hideLoader();
                if (res['status'] == 200) {
                    let navigationExtras = {
                        queryParams: {
                            reload: true,
                        }
                    };
                    this.router.navigate(["/settings/vehicles"], navigationExtras);
                }
                else if (res['status'] == 422) {
                    this.errors = res['data']['errors'];
                    console.log(this.errors);
                }
                // this.vehicles = res['data'];
                //   this.loading = false;
            });
        });
    }
    hideLoader() {
        if (this.loader != null) {
            this.loader.dismiss();
            this.loader = null;
        }
    }
};
EditPage.ctorParameters = () => [
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_9__["TranslateService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_8__["ActivatedRoute"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_6__["Storage"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["DomSanitizer"] },
    { type: _services_photo_service__WEBPACK_IMPORTED_MODULE_3__["PhotoService"] }
];
EditPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-edit',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./edit.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/vehicles/edit/edit.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./edit.page.scss */ "./src/app/settings/vehicles/edit/edit.page.scss")).default]
    })
], EditPage);



/***/ })

}]);
//# sourceMappingURL=edit-edit-module-es2015.js.map