import { Injectable } from "@angular/core";
import { Router, CanActivate, ActivatedRouteSnapshot } from "@angular/router";
import { StorageService } from '../services/storage.service';

@Injectable({
  providedIn: "root"
})
export class AuthGuard implements CanActivate {
  constructor(private storage:StorageService,private router: Router) {}

  canActivate(route: ActivatedRouteSnapshot): boolean {
  //   if (this.storage.ifLoggedIn()) {

  //     return true;
  // }else {
  //     this.router.navigate(['/login']);
  //     return false;
  // }
 return this.storage.ifLoggedIn();
    
  }
}